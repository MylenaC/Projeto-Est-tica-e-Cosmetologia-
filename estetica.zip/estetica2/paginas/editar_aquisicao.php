<?php
if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    // Utilizando prepared statement para evitar SQL Injection
    $sqlSelect = "SELECT * FROM aquisicao WHERE id=?";
    $stmt = $conexao->prepare($sqlSelect);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $user_data = $resultado->fetch_assoc();
        $nome = isset($user_data['nome']) ? $user_data['nome'] : '';
        $email = isset($user_data['email']) ? $user_data['email'] : '';
        $material = isset($user_data['material']) ? $user_data['material'] : '';
        $mensagem = isset($user_data['mensagem']) ? $user_data['mensagem'] : '';
        $data_aquisicao = isset($user_data['data_aquisicao']) ? $user_data['data_aquisicao'] : '';
        $nome_fornecedor = isset($user_data['nome_fornecedor']) ? $user_data['nome_fornecedor'] : '';
        $quantidade_produto = isset($user_data['quantidade_produto']) ? $user_data['quantidade_produto'] : '';
        $valor_produto = isset($user_data['valor_produto']) ? $user_data['valor_produto'] : '';
        $departamento_responsavel = isset($user_data['departamento_responsavel']) ? $user_data['departamento_responsavel'] : 'ADM Fasiclin';
        $cod_prof = isset($user_data['cod_prof']) ? $user_data['cod_prof'] : '';
        $valor_disponivel_caixa = isset($user_data['valor_disponivel_caixa']) ? $user_data['valor_disponivel_caixa'] : '';
        $status_aquisicao_produto = isset($user_data['status_aquisicao_produto']) ? $user_data['status_aquisicao_produto'] : '';
    } else {
        // Se não encontrar o registro, redireciona para listar_aquisicao.php
        header('Location: listar_aquisicao.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="PT-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Aquisição de Materiais</title>
<style>
/* Estilos CSS podem ser adicionados aqui */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f4f4f4;
}
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
.form-group {
  margin-bottom: 20px;
}
label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}
input[type="text"],
input[type="email"],
input[type="date"],
input[type="number"],
select,
textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
select {
  appearance: none;
  -webkit-appearance: none;
  background: url('down-arrow.png') no-repeat right center;
  background-size: 20px;
}
textarea {
  resize: vertical;
}
button {
  padding: 10px 20px;
  background-color: rgb(11, 87, 1);
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

#submit {
      position: relative;
      top: 10px;
      right: 10px;
      background-color: rgb(11, 87, 1);
      color: #ffffff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s ease;
  }
  
.botao-registro {
    position: absolute;
    top: 10px;
    left: 15px;
    background-color: rgb(11, 87, 1);
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.botao-estilizado {
    position: absolute;
    top: 10px;
    right: 15px;
    left: 90%;
    background-color: rgb(11, 87, 1);
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

h1 {
    color: rgb(11, 87, 1);
    text-align: center;
}
</style>
</head>
<body>
<div class="container">

    <a href="../pagina_inicial/Inicio.html">
        <button class="botao-estilizado">Voltar</button>
    </a>
    
    <a href="./listar_aquisicao.php">
        <button class="botao-registro">Registro de Aquisição</button>
    </a>

    <h1>Aquisição de materiais</h1>
    <p>Preencha o formulário abaixo para requisição de materiais para Clínica.</p>
    <form action="salvar_aquisicao.php" method="post">

        <input type="hidden" name="id" value="<?php echo $id; ?>">

        <div class="form-group">
            <label for="nome">Nome completo:</label>
            <input type="text" id="nome" name="nome" class="inputUser" value="<?php echo htmlspecialchars($nome); ?>" placeholder="Nome completo" required>
        </div>
        <div class="form-group">
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" class="inputUser" value="<?php echo htmlspecialchars($email); ?>">
        </div>
        <div class="form-group">
            <label for="material">Material desejado:</label>
            <select id="material" name="material" required>
                <option value="" disabled>Selecione o(s) materiais desejados.</option>
                <option value="agulha" <?php echo ($material == 'agulha') ? 'selected' : ''; ?>>Agulha</option>
                <option value="Mascara" <?php echo ($material == 'Mascara') ? 'selected' : ''; ?>>Máscaras</option>
                <option value="Luvas" <?php echo ($material == 'Luvas') ? 'selected' : ''; ?>>Luvas</option>
                <option value="Outros" <?php echo ($material == 'Outros') ? 'selected' : ''; ?>>Outros</option>
            </select>
        </div>
        <div class="form-group">
            <label for="mensagem">Descrição do pedido:</label>
            <textarea id="mensagem" name="mensagem" rows="4"><?php echo htmlspecialchars($mensagem); ?></textarea>
        </div>
        <!-- Novos campos adicionados -->
        <div class="form-group">
            <label for="data_aquisicao">Data de aquisição:</label>
            <input type="date" id="data_aquisicao" name="data_aquisicao" value="<?php echo $data_aquisicao; ?>">
        </div>
        <div class="form-group">
            <label for="nome_fornecedor">Nome do Fornecedor:</label>
            <input type="text" id="nome_fornecedor" name="nome_fornecedor" value="<?php echo htmlspecialchars($nome_fornecedor); ?>" placeholder="Se disponível">
        </div>
        <div class="form-group">
            <label for="quantidade_produto">Quantidade do Produto:</label>
            <input type="number" id="quantidade_produto" name="quantidade_produto" value="<?php echo $quantidade_produto; ?>">
        </div>
        <div class="form-group">
            <label for="valor_produto">Valor do Produto:</label>
            <input type="text" id="valor_produto" name="valor_produto" value="<?php echo htmlspecialchars($valor_produto); ?>">
        </div>
        <div class="form-group">
            <label for="departamento_responsavel">Departamento Responsável:</label>
            <input type="text" id="departamento_responsavel" name="departamento_responsavel" value="<?php echo $departamento_responsavel; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="cod_prof">Cod Prof:</label>
            <input type="text" id="cod_prof" name="cod_prof" value="<?php echo $cod_prof; ?>">
        </div>
        <div class="form-group">
            <label for="valor_disponivel_caixa">Valor disponível em caixa:</label>
            <input type="text" id="valor_disponivel_caixa" name="valor_disponivel_caixa" value="<?php echo htmlspecialchars($valor_disponivel_caixa); ?>">
        </div>
        <div class="form-group">
            <label for="status_aquisicao_produto">Status da aquisição do Produto:</label>
            <select id="status_aquisicao_produto" name="status_aquisicao_produto" required>
                <option value="" disabled>Selecione o status da aquisição do produto</option>
                <option value="Em andamento" <?php echo ($status_aquisicao_produto == 'Em andamento') ? 'selected' : ''; ?>>Em andamento</option>
                <option value="Concluído" <?php echo ($status_aquisicao_produto == 'Concluído') ? 'selected' : ''; ?>>Concluído</option>
                <option value="Cancelado" <?php echo ($status_aquisicao_produto == 'Cancelado') ? 'selected' : ''; ?>>Cancelado</option>
            </select>
        </div>
        <!-- Fim dos novos campos -->
        <center>
        <input type="submit" name="update" id="submit" value="Enviar">
        </center>
    </form>

</div>
</body>
</html>
