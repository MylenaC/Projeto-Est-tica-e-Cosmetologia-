<?php
include_once('../conexao.php');

if (isset($_POST['update'])) {
    try {
        // Capturar e imprimir dados do POST para depuração
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";

        // Atribuir valores dos campos do formulário a variáveis
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $material = $_POST['material'];
        $mensagem = $_POST['mensagem'];
        $data_aquisicao = $_POST['data_aquisicao'];
        $nome_fornecedor = $_POST['nome_fornecedor'];
        $quantidade_produto = $_POST['quantidade_produto'];
        $valor_produto = $_POST['valor_produto'];
        $departamento_responsavel = $_POST['departamento_responsavel'];
        $cod_prof = $_POST['cod_prof'];
        $valor_disponivel_caixa = $_POST['valor_disponivel_caixa'];
        $status_aquisicao_produto = $_POST['status_aquisicao_produto'];

        // Construir a consulta SQL de atualização
        $sqlUpdate = "UPDATE aquisicao SET 
            nome='$nome', 
            email='$email', 
            material='$material', 
            mensagem='$mensagem', 
            data_aquisicao='$data_aquisicao', 
            nome_fornecedor='$nome_fornecedor', 
            quantidade_produto='$quantidade_produto', 
            valor_produto='$valor_produto', 
            departamento_responsavel='$departamento_responsavel', 
            cod_prof='$cod_prof', 
            valor_disponivel_caixa='$valor_disponivel_caixa', 
            status_aquisicao_produto='$status_aquisicao_produto'
            WHERE id='$id'";

        // Debug: Imprimir SQL para verificar a construção
        echo "SQL: $sqlUpdate<br>";

        // Executar a consulta SQL
        $resultado = $conexao->query($sqlUpdate);

        // Verificar se a consulta foi bem-sucedida
        if ($resultado) {
            header('Location: listar_aquisicao.php');
            exit();
        } else {
            throw new Exception("Erro ao atualizar o registro: " . $conexao->error);
        }
    } catch (Exception $e) {
        echo "Erro: " . $e->getMessage();
    }
}
?>
