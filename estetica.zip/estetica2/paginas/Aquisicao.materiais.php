<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "banco";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se todos os campos esperados estão presentes no array $_POST
$expected_fields = [
    'nome', 'email', 'material', 'mensagem', 'data_aquisicao', 
    'nome_fornecedor', 'quantidade_produto', 'valor_produto', 
    'cod_prof', 'valor_disponivel_caixa', 
    'status_aquisicao_produto'
];

foreach ($expected_fields as $field) {
    if (!isset($_POST[$field])) {
        die("Erro: campo '$field' não encontrado no formulário.");
    }
}

// Recebe os dados do formulário
$nome = $_POST['nome'];
$email = $_POST['email'];
$material = $_POST['material'];
$mensagem = $_POST['mensagem'];
$data_aquisicao = $_POST['data_aquisicao'];
$nome_fornecedor = $_POST['nome_fornecedor'];
$quantidade_produto = $_POST['quantidade_produto'];
$valor_produto = $_POST['valor_produto'];
$departamento_responsavel = "ADM Fasiclin";  // Valor fixo para departamento responsável
$cod_prof = $_POST['cod_prof'];
$valor_disponivel_caixa = $_POST['valor_disponivel_caixa'];
$status_aquisicao_produto = $_POST['status_aquisicao_produto'];

// Prepara e executa a inserção
$sql = "INSERT INTO aquisicao (nome, email, material, mensagem, data_aquisicao, nome_fornecedor, quantidade_produto, valor_produto, departamento_responsavel, cod_prof, valor_disponivel_caixa, status_aquisicao_produto) 
        VALUES ('$nome', '$email', '$material', '$mensagem', '$data_aquisicao', '$nome_fornecedor', '$quantidade_produto', '$valor_produto', '$departamento_responsavel', '$cod_prof', '$valor_disponivel_caixa', '$status_aquisicao_produto')";

if ($conn->query($sql) === TRUE) {
    header("Location: listar_aquisicao.php"); // Substitua "nova_pagina.php" pela URL para onde deseja redirecionar
    exit(); // Certifique-se de chamar exit() após header() para garantir que o script pare de executar
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
}


$conn->close();

?>