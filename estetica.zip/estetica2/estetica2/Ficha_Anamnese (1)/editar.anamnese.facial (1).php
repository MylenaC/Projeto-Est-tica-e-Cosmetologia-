<?php

    if(!empty($_GET['id']))
    {
        include_once('../conexao.php');

        $id = $_GET['id'];

        $sqlSelect = "SELECT * FROM anamnese_facial WHERE id=$id";

        $resultado = $conexao->query($sqlSelect);

        if($resultado->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($resultado))
            {
                $nome_completo = isset($user_data['nome_completo']) ? $user_data['nome_completo'] : '';
                $data_nascimento = isset($user_data['data_nascimento']) ? $user_data['data_nascimento'] : '';
                $idade = isset($user_data['idade']) ? $user_data['idade'] : '';
                $endereco = isset($user_data['endereco']) ? $user_data['endereco'] : '';
                $cep = isset($user_data['cep']) ? $user_data['cep'] : '';
                $bairro = isset($user_data['bairro']) ? $user_data['bairro'] : '';
                $cidade = isset($user_data['cidade']) ? $user_data['cidade'] : '';
                $estado = isset($user_data['estado']) ? $user_data['estado'] : '';
                $telefone_residencial = isset($user_data['telefone_residencial']) ? $user_data['telefone_residencial'] : '';
                $telefone_comercial = isset($user_data['telefone_comercial']) ? $user_data['telefone_comercial'] : '';
                $celular = isset($user_data['celular']) ? $user_data['celular'] : '';
                $escolaridade = isset($user_data['escolaridade']) ? $user_data['escolaridade'] : '';
                $escolaridade_completa = isset($user_data['escolaridade_completa']) ? $user_data['escolaridade_completa'] : '';
                $profissao = isset($user_data['profissao']) ? $user_data['profissao'] : '';
                $estado_civil = isset($user_data['estado_civil']) ? $user_data['estado_civil'] : '';
                $exposicao_ao_sol = isset($user_data['exposicao_ao_sol']) ? $user_data['exposicao_ao_sol'] : '';
                $filtro_solar = isset($user_data['filtro_solar']) ? $user_data['filtro_solar'] : '';
                $frequencia_filtro_solar = isset($user_data['frequencia_filtro_solar']) ? $user_data['frequencia_filtro_solar'] : '';
                $usa_chapeu = isset($user_data['usa_chapeu']) ? $user_data['usa_chapeu'] : '';
                $usa_cosmeticos = isset($user_data['usa_cosmeticos']) ? $user_data['usa_cosmeticos'] : '';
                $cosmeticos_capilares = isset($user_data['cosmeticos_capilares']) ? $user_data['cosmeticos_capilares'] : '';
                $usa_isotretinoina = isset($user_data['usa_isotretinoina']) ? $user_data['usa_isotretinoina'] : '';
                $usa_fotossensibilizantes = isset($user_data['usa_fotossensibilizantes']) ? $user_data['usa_fotossensibilizantes'] : '';
                $fotossensibilizantes = isset($user_data['fotossensibilizantes']) ? $user_data['fotossensibilizantes'] : '';
                $usa_lentes = isset($user_data['usa_lentes']) ? $user_data['usa_lentes'] : '';
                $tabagismo = isset($user_data['tabagismo']) ? $user_data['tabagismo'] : '';
                $quantidade_cigarros = isset($user_data['quantidade_cigarros']) ? $user_data['quantidade_cigarros'] : '';
                $ingere_bebida = isset($user_data['ingere_bebida']) ? $user_data['ingere_bebida'] : '';
                $frequencia_bebida = isset($user_data['frequencia_bebida']) ? $user_data['frequencia_bebida'] : '';
                $qualidade_sono = isset($user_data['qualidade_sono']) ? $user_data['qualidade_sono'] : '';
                $horas_sono = isset($user_data['horas_sono']) ? $user_data['horas_sono'] : '';
                $ingestao_agua_dia = isset($user_data['ingestao_agua_dia']) ? $user_data['ingestao_agua_dia'] : '';
                $alimentacao = isset($user_data['alimentacao']) ? $user_data['alimentacao'] : '';
                $faz_dieta = isset($user_data['faz_dieta']) ? $user_data['faz_dieta'] : '';
                $patologia_de_pele = isset($user_data['patologia_de_pele']) ? $user_data['patologia_de_pele'] : '';
                $patologia = isset($user_data['patologia']) ? $user_data['patologia'] : '';
                $outra_patologia = isset($user_data['outra_patologia']) ? $user_data['outra_patologia'] : '';
                $faz_procedimento_estetico = isset($user_data['faz_procedimento_estetico']) ? $user_data['faz_procedimento_estetico'] : '';
                $alteracoes_tireoide = isset($user_data['alteracoes_tireoide']) ? $user_data['alteracoes_tireoide'] : '';
                $hipotireoidismo = isset($user_data['hipotireoidismo']) ? $user_data['hipotireoidismo'] : '';
                $hipertiroidismo = isset($user_data['hipertiroidismo']) ? $user_data['hipertiroidismo'] : '';
                $toma_medicacao = isset($user_data['toma_medicacao']) ? $user_data['toma_medicacao'] : '';
                $medicacao = isset($user_data['medicacao']) ? $user_data['medicacao'] : '';
                $tempo_medicacao = isset($user_data['tempo_medicacao']) ? $user_data['tempo_medicacao'] : '';
                $usa_suplemento_oral = isset($user_data['usa_suplemento_oral']) ? $user_data['usa_suplemento_oral'] :'';
                $suplemento_oral = isset($user_data['suplemento_oral']) ? $user_data['suplemento_oral'] : '';
                $tem_antecedentes_oncologicos = isset($user_data['tem_antecedentes_oncologicos']) ? $user_data['tem_antecedentes_oncologicos'] : '';
                $antecedentes_oncologicos = isset($user_data['antecedentes_oncologicos']) ? $user_data['antecedentes_oncologicos'] : '';
                $tem_diabetes = isset($user_data['tem_diabetes']) ? $user_data['tem_diabetes'] : '';
                $fez_cirurgia_plastica_estetica = isset($user_data['fez_cirurgia_plastica_estetica']) ? $user_data['fez_cirurgia_plastica_estetica'] : '';
                $cirurgia_plastica_estetica = isset($user_data['cirurgia_plastica_estetica']) ? $user_data['cirurgia_plastica_estetica'] : '';
                $queixa_alopecia = isset($user_data['queixa_alopecia']) ? $user_data['queixa_alopecia'] : '';
                $alopecia_acomete_corpo = isset($user_data['alopecia_acomete_corpo']) ? $user_data['alopecia_acomete_corpo'] : '';
                $partes_acometidas = isset($user_data['partes_acometidas']) ? $user_data['partes_acometidas'] : '';
                $tempo_disfuncao = isset($user_data['tempo_disfuncao']) ? $user_data['tempo_disfuncao'] : '';
                $estado_disfuncao = isset($user_data['estado_disfuncao']) ? $user_data['estado_disfuncao'] : '';
                $experiencia = isset($user_data['experiencia']) ? $user_data['experiencia'] : '';
                $assinatura = isset($user_data['assinatura']) ? $user_data['assinatura'] : '';
                $assinatura_paciente = isset($user_data['assinatura_paciente']) ? $user_data['assinatura_paciente'] : '';
                $data_assinatura_paciente = isset($user_data['data_assinatura_paciente']) ? $user_data['data_assinatura_paciente'] : '';
                $nome_profissional = isset($user_data['nome_profissional']) ? $user_data['nome_profissional'] : '';
                $data_assinatura_profissional = isset($user_data['data_assinatura_profissional']) ? $user_data['data_assinatura_profissional'] : '';

                
            }
        }
        else
        {
            header('Location: listar.anamnese.facial');
            exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento

        }
    }


?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha Anamnese Facial</title>
    <link rel="stylesheet" href="../css/Ficha.anamnese.css">

    <style>
            /* Estilo para o fundo */
    .background {
        background-color: #ffffff; /* Cor de fundo */
    }

    /* Estilo para o menu */
    header {
        background-color: rgb(76, 115, 55); /* Cor de fundo do cabeçalho */
        padding: 20px 0; /* Espaçamento interno no cabeçalho */
        text-align: center; /* Alinhamento centralizado do texto */
    }

    .links {
        list-style-type: none; /* Remove marcadores de lista */
        margin: 0; /* Remove margem externa */
        padding: 0; /* Remove preenchimento interno */
    }

    .links li {
        display: inline; /* Exibe os itens de menu em linha */
        margin-right: 20px; /* Espaçamento entre os itens do menu */
    }

    .links li a {
        text-decoration: none; /* Remove sublinhado dos links */
        color: #fff; /* Cor do texto */
        font-weight: bold; /* Texto em negrito */
        transition: color 0.3s; /* Transição de cor suave */
    }

    .links li a:hover {
        color: #8dd090; /* Cor do texto ao passar o mouse sobre o link */
    }

    .container2 {
        text-align: center; /* Centraliza o conteúdo dentro do contêiner */
    }

    .container2 img {
        display: inline-block; /* Permite a aplicação de margens automáticas */
        margin: 0 auto; /* Centraliza a imagem horizontalmente */
    } 

    .botao-estilizado2 {
    position: absolute; /* Posição absoluta */
    top: 10px; /* Distância do topo */
    left: 10px; /* Distância da direita */
    background-color: rgb(13, 55, 8);
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

    #update {
        background-color: rgb(11, 87, 1); /* Cor de fundo do botão */
        color: #fff; /* Cor do texto do botão */
        padding: 10px 20px; /* Espaçamento interno do botão */
        font-size: 18px; /* Tamanho da fonte do botão */
        border: none; /* Remove a borda padrão do botão */
        border-radius: 8px; /* Borda arredondada */
        cursor: pointer; /* Altera o cursor ao passar sobre o botão */
        transition: background-color 0.3s ease; /* Adiciona uma transição suave na mudança de cor de fundo */
        align-items: center;
    }
    
    #update:hover {
        background-color: #45a049; /* Cor de fundo do botão ao passar o mouse */
    }

    input[type="text"],
    input[type="number"] {
        width: 205px;
        padding: 3px;
        border: 1px solid #ccc;
        border-radius: 2px;
        margin-right: 1%;
    }


    </style>
    
</head>
<body>

    <a href="../Ficha_Anamnese/listar.anamnese.facial.php">
        <button class="botao-estilizado2">Anamnese Facial</button>
    </a>
   

    <div class="background">
        <header>
            <ul class="links">
                <li><a href="#dados-pessoais">Dados pessoais</a></li>
                <li><a href="#habitos-diarios">Hábitos diários</a></li>
                <li><a href="#historico-clinico-e-avaliacao-cutanea">Histórico clínico e avaliação cutânea</a></li>
                <li><a href="#termo-de-responsabilidade">Termo de Responsabilidade</a></li>
            </ul>
        </header>

        <a href="/estetica2/pagina_inicial/ficha.html">
            <button class="botao-estilizado">Voltar</button>
        </a>


       
        <div class="container">
        <form action="salvar.anamnese.facial.php" method="post" class="consent-form">
            <h1>FICHA DE ANAMNESE FACIAL</h1>
    
    
        </div>
    
        <h2 id="dados-pessoais">DADOS PESSOAIS</h2>
    
        <div class="form-group">

         <input type="hidden" name="id" value="<?php echo $id; ?>">

            <label>Nome:</label>
            <input type="text" name="nome_completo" id="nome_completo" class="inputUser" value="<?php echo $nome_completo ?>" placeholder="Nome completo">  
    
            <label>Data de Nascimento:</label>
            <input type="date" name="data_nascimento" id="data_nascimento" class="inputUser" value="<?php echo $data_nascimento ?>">
    
            <label>Idade:</label>
            <input type="number" name="idade" id="idade" class="inputUser" value="<?php echo $idade ?>">
    
            <label>Endereço:</label>
            <input type="text" name="endereco" id="endereco" class="inputUser" value="<?php echo $endereco ?>">
       
            <label for="text">Estado</label>
            <select name="estado">
            <option value="<?php echo $estado ?>"><?php echo $estado ?></option>
            <option value="AC">AC</option>
            <option value="AL">AL</option>
            <option value="AP">AP</option>
            <option value="AM">AM</option>
            <option value="BA">BA</option>
            <option value="BA">CE</option>
            <option value="CE">ES</option>
            <option value="GO">GO</option>
            <option value="MA">MA</option>
            <option value="MT">MT</option>
            <option value="MS">MS</option>
            <option value="MG">MG</option>
            <option value="PA">PA</option>
            <option value="PB">PB</option>
            <option value="PR">PR</option>
            <option value="PE">PE</option>
            <option value="PI">PI</option>
            <option value="RJ">RJ</option>
            <option value="RN">RN</option>
            <option value="RS">RS</option>
            <option value="RO">RO</option>
            <option value="RR">RR</option>
            <option value="SC">SC</option>
            <option value="SP">SP</option>
            <option value="SE">SE</option>
            <option value="TO">TO</option>
            <option value="DF">DF</option>
        </select>

        </div>
    
        <div class="form-group">

            <label>CEP:</label>
            <input type="text" id="cep" name="cep" id="cep" class="inputUser" value="<?php echo $cep ?>">
    
            <label>Bairro:</label>
            <input type="text" name="bairro" id="bairro" class="inputUser" value="<?php echo $bairro ?>">
    
            <label>Cidade:</label>
            <input type="text" name="cidade" id="cidade" class="inputUser" value="<?php echo $cidade ?>">
    
            <label>Tel.Res.</label>
            <input type="text" id="telefone_residencial" name="telefone_residencial" id="telefone_residencial" class="inputUser" value="<?php echo $telefone_residencial ?>">
    
            <label>Tel.Com.</label>
            <input type="text" id="telefone_comercial" name="telefone_comercial" id="telefone_comercial" class="inputUser" value="<?php echo $telefone_comercial ?>">

    
        </div>
    
    
        <div class="form-group">
                
            <label>Cel.</label>
            <input type="text" id="celular" name="celular" id="celular" class="inputUser" value="<?php echo $celular ?>">
    
            <label>Escolaridade:</label>
            <select name="escolaridade">
                <option value="<?php echo $escolaridade ?>"><?php echo $escolaridade ?></option>
                <option value="Ensino Fundamental">Ensino Fundamental</option>
                <option value="Ensino Médio">Ensino Médio</option>
                <option value="Curso Técnico">Curso Técnico</option>
                <option value="Universidade">Universidade</option>
                <option value="Pós-Graduação">Pós-Graduação</option>
                <option value="Mestrado">Mestrado</option>
                <option value="Doutorado">Doutorado</option>
                <option value="Pós-Doutorado">Pós-Doutorado</option>
            </select>

            <input type="radio" name="escolaridade_completa" id="escolaridade_completa" value="1" <?php echo ($escolaridade_completa == '1') ? 'checked' : ''; ?>>
            <label>Completo</label>
    
            <input type="radio" name="escolaridade_completa" id="escolaridade_completa" value="0" <?php echo ($escolaridade_completa == '0') ? 'checked' : ''; ?>>
            <label>Incompleto</label>
        
            <label>Profissão:</label>
            <input type="text" name="profissao" id="profissao" class="inputUser" value="<?php echo $profissao ?>">
    
            <label>Estado Civil:</label>
            <input type="text" name="estado_civil" id="estado_civil" class="inputUser" value="<?php echo $estado_civil ?>">
    
        </div>
    
    
    <div class="container">
        <h1>HÁBITOS DIÁRIOS</h1>
    </div>
    
            <div class="container3">
                <div class="elemento">
                    <label>Exposição ao sol:</label>
                    <input type="radio" name="exposicao_ao_sol" value="1" id="exposicao_ao_sol"<?php echo ($exposicao_ao_sol == '1') ? 'checked' : ''; ?>> Sim
                    <input type="radio" name="exposicao_ao_sol" value="0" id="exposicao_ao_sol"<?php echo ($exposicao_ao_sol == '0') ? 'checked' : ''; ?>> Não
                </div>
    
                <div class="elemento">
                    <label>Filtro solar:</label>
                    <input type="radio" name="filtro_solar" value="1" id="filtro_solar" <?php echo ($filtro_solar == '1') ? 'checked' : ''; ?>> Sim
                    <input type="radio" name="filtro_solar" value="0" id="filtro_solar" <?php echo ($filtro_solar == '0') ? 'checked' : ''; ?>> Não
                </div>
    
                <div class="elemento">
                    <label><span>Frequência:</span></label>
                    <input type="text" name="frequencia_filtro_solar" id="frequencia_filtro_solar" class="inputUser" value="<?php echo $frequencia_filtro_solar ?>">
                </div>
                
            </div>
    
            <div class="container3">
    
            <div class="elemento">
                <label>Faz uso de chapéu ou bonés diariamente?</label>
                <input type="radio" name="usa_chapeu" id="usa_chapeu" value="1" <?php echo ($usa_chapeu == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_chapeu" id="usa_chapeu" value="0" <?php echo ($usa_chapeu == '0') ? 'checked' : ''; ?>> Não
            </div>
            
            <div class="elemento">
                <label>Utilização de cosméticos capilares:</label>
                <input type="radio" name="usa_cosmeticos" id="usa_cosmeticos" value="1" <?php echo ($usa_cosmeticos == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_cosmeticos" id="usa_cosmeticos" value="0" <?php echo ($usa_cosmeticos == '0') ? 'checked' : ''; ?>> Não
            </div>
    
            <div class="elemento">
                <label>Qual (is):</label>
                <input type="text" name="cosmeticos_capilares" id="cosmeticos_capilares" class="inputUser" value="<?php echo $cosmeticos_capilares ?>">
            </div>
    
            </div>
    
            <div class="container3">
    
            <div class="elemento">
                <label>Uso de isotretinoína ou derivado da vitamina A tópica ou oral</label>
                <br>
                <input type="radio" name="usa_isotretinoina" id="usa_isotretinoina" value="1" <?php echo ($usa_isotretinoina == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_isotretinoina" id="usa_isotretinoina" value="0" <?php echo ($usa_isotretinoina == '0') ? 'checked' : ''; ?>> Não
            </br>
            </div>
    
            <div class="elemento">
                <label>Utilização de cosméticos fotossensibilizantes:</label>
                <input type="radio" name="usa_fotossensibilizantes" id="usa_fotossensibilizantes" value="1" <?php echo ($usa_fotossensibilizantes == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_fotossensibilizantes" id="usa_fotossensibilizantes" value="0" <?php echo ($usa_fotossensibilizantes == '0') ? 'checked' : ''; ?>> Não
            </div>
    
            <div class="elemento">
                <label>Qual:</label>
                <input type="text" name="fotossensibilizantes" id="fotossensibilizantes" class="inputUser" value="<?php echo $fotossensibilizantes ?>">
            </div>

            </div>
    
            <div class="container3">
    
            <div class="elemento">
                <label>Usa lentes de contato:</label>
                <input type="radio" name="usa_lentes" id="usa_lentes" value="1" <?php echo ($usa_lentes == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_lentes"  id="usa_lentes" value="0" <?php echo ($usa_lentes == '0') ? 'checked' : ''; ?>> Não
            </div>
    
            <div class="elemento">
                <label>Tabagismo:</label>
                <input type="radio" name="tabagismo" id="tabagismo" value="1" <?php echo ($tabagismo == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="tabagismo" id="tabagismo" value="0" <?php echo ($tabagismo == '0') ? 'checked' : ''; ?>> Não
            </div>
    
            <div class="elemento">
                <label>Quantidade de cigarros/dia:</label>
                <input type="text" name="quantidade_cigarros" id="quantidade_cigarros" class="inputUser" value="<?php echo $quantidade_cigarros ?>">
            </div>

            </div>
    
            <div class="container3">
    
            <div class="elemento">
                <label>Ingere bebida alcoólica:</label>
                <input type="radio" name="ingere_bebida" id="ingere_bebida" value="1" <?php echo ($ingere_bebida == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="ingere_bebida" id="ingere_bebida" value="0" <?php echo ($ingere_bebida == '0') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label>Frequência:</label>
                <input type="text" name="frequencia_bebida" id="frequencia_bebida" class="inputUser" value="<?php echo $frequencia_bebida ?>">
            </div>
    
            <div class="elemento">
                <label>Qualidade do sono:</label>
                <input type="radio" name="qualidade_sono" id="qualidade_sono" value="Boa" <?php echo ($qualidade_sono == 'Boa') ? 'checked' : ''; ?>> Boa
                <input type="radio" name="qualidade_sono" id="qualidade_sono" value="Regular" <?php echo ($qualidade_sono == 'Regular') ? 'checked' : ''; ?>> Regular
                <input type="radio" name="qualidade_sono" id="qualidade_sono" value="Péssima" <?php echo ($qualidade_sono == 'Péssima') ? 'checked' : ''; ?> > Péssima
            </div>
    
            </div>
    
            <div class="container3">

    
            <div class="elemento">
                <label>Quantas horas / noite:</label>
                <input type="text" name="horas_sono" id="horas_sono" class="inputUser" value="<?php echo $horas_sono ?>">
            </div>

            <div class="elemento">
                <label>Ingestão de água (copos / dia):</label>
                <input type="text" name="ingestao_agua_dia" id="ingestao_agua_dia" class="inputUser" value="<?php echo $ingestao_agua_dia ?>">
            </div>
    
            <div class="elemento">
                <label>Alimentação:</label>
                <input type="radio" name="alimentacao" id="alimentacao" value="Boa" <?php echo ($qualidade_sono == 'Boa') ? 'checked' : ''; ?>> Boa
                <input type="radio" name="alimentacao" id="alimentacao" value="Regular" <?php echo ($qualidade_sono == 'Regular') ? 'checked' : ''; ?>> Regular
                <input type="radio" name="alimentacao" id="alimentacao" value="Péssima" <?php echo ($qualidade_sono == 'Péssima') ? 'checked' : ''; ?>> Péssima
            </div>
    
            </div>
    
            <div class="container3">
    
            <div class="elemento">
                <label>Está fazendo algum tipo de dieta alimentar rigorosa?</label>
                <input type="radio" name="faz_dieta" id="faz_dieta" value="1" <?php echo ($faz_dieta == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="faz_dieta" id="faz_dieta" value="0" <?php echo ($faz_dieta == '0') ? 'checked' : ''; ?>> Não
            </div>
            </div>
                        
    
        <div class="container">
            <h1>HISTÓRICO CLÍNICO E AVALIAÇÃO CUTÂNEA</h1>
    
        </div>
                <div class="container3">
    
                    <div class="elemento">
        
                        <label>Alguma patologia de pele:</label>
                        <input type="radio" name="patologia_de_pele" id="patologia_de_pele" value="1" <?php echo ($patologia_de_pele == '1') ? 'checked' : ''; ?>> Sim
                        <input type="radio" name="patologia_de_pele" id="patologia_de_pele" value="0" <?php echo ($patologia_de_pele == '0') ? 'checked' : ''; ?>> Não
                    </div>
                    
                    <div class="elemento">
                        <label>Qual:</label>
                        <input type="radio" name="patologia" id="patologia" value="Acne" <?php echo ($patologia == 'Acne') ? 'checked' : ''; ?>> Acne
        
                        <input type="radio" name="patologia" id="patologia" value="Psoríase" <?php echo ($patologia == 'Psoríase') ? 'checked' : ''; ?>> Psoríase
        
                        <input type="radio" name="patologia" id="patologia" value="Vitiligo" <?php echo ($patologia == 'Vitiligo') ? 'checked' : ''; ?>> Vitiligo

                        <input type="radio" name="patologia" id="patologia" value="Nenhuma" <?php echo ($patologia == 'Nenhuma') ? 'checked' : ''; ?>> Nenhuma

                    </div>
        
                    <div class="elemento">
                        <label>Outra:</label>
                        <input type="text" name="outra_patologia" id="outra_patologia" class="inputUser" value="<?php echo $outra_patologia ?>">
                    </div>
        
                    </div>
    
    
                    <div class="container3">
    
                        <div class="elemento">
            
                            <label>Está realizando algum procedimento estético facial atualmente?</label>
                            <br>
                            <input type="radio" name="faz_procedimento_estetico" id="faz_procedimento_estetico" value="1" <?php echo ($faz_procedimento_estetico == '1') ? 'checked' : ''; ?>> Sim
                            <input type="radio" name="faz_procedimento_estetico" id="faz_procedimento_estetico" value="0" <?php echo ($faz_procedimento_estetico == '0') ? 'checked' : ''; ?>> Não
                            </br>
                        </div>
                        
                        <div class="elemento">
    
                            <label>Alterações na tireoide:</label>
                            <input type="radio" name="alteracoes_tireoide" id="alteracoes_tireoide" value="1" <?php echo ($alteracoes_tireoide == '1') ? 'checked' : ''; ?>> Sim
                            <input type="radio" name="alteracoes_tireoide" id="alteracoes_tireoide" value="0" <?php echo ($alteracoes_tireoide == '0') ? 'checked' : ''; ?>> Não
    
                        </div>
            
                        <div class="elemento">
    
                            <label>Hipotiroidismo:</label>
                            <input type="radio" name="hipotireoidismo" id="hipotireoidismo" value="1" <?php echo ($hipotireoidismo == '1') ? 'checked' : ''; ?>> Sim
                            <input type="radio" name="hipotireoidismo" id="hipotireoidismo" value="0" <?php echo ($hipotireoidismo == '0') ? 'checked' : ''; ?>> Não
    
                        </div>
            
                        </div>
    
    
                        <div class="container3">
    
                            <div class="elemento">
                
                                <label>Hipertiroidismo:</label>
                                <input type="radio" name="hipertiroidismo" id="hipertiroidismo" value="1" <?php echo ($hipertiroidismo == '1') ? 'checked' : ''; ?>> Sim
                              <input type="radio" name="hipertiroidismo" id="hipertiroidismo" value="0" <?php echo ($hipertiroidismo == '0') ? 'checked' : ''; ?>> Não
        
                            </div>
                            
                            <div class="elemento">
        
                                <label>Toma medicação?</label>
                                <input type="radio" name="toma_medicacao" id="toma_medicacao" value="1" <?php echo ($toma_medicacao == '1') ? 'checked' : ''; ?>> Sim
                                <input type="radio" name="toma_medicacao" id="toma_medicacao" value="0" <?php echo ($toma_medicacao == '0') ? 'checked' : ''; ?>> Não
        
                            </div>
                
                            <div class="elemento">
        
                                <label>Qual?</label>
                                <input type="text" name="medicacao" id="medicacao" class="inputUser" value="<?php echo $medicacao ?>">
        
                            </div>
                
                            </div>
    
    
                            <div class="container3">
    
                                <div class="elemento">
                    
                                    <label>há quanto tempo?</label>
                                    <input type="text" name="tempo_medicacao" id="tempo_medicacao" class="inputUser" value="<?php echo $tempo_medicacao ?>">
            
                                </div>
                                
                                <div class="elemento">
            
                                    <label>Usa algum suplemento oral?</label>
                                    <input type="radio" name="usa_suplemento_oral" id="usa_suplemento_oral" value="1" <?php echo ($usa_suplemento_oral == '1') ? 'checked' : ''; ?>> Sim
                                    <input type="radio" name="usa_suplemento_oral" id="usa_suplemento_oral" value="0" <?php echo ($usa_suplemento_oral == '0') ? 'checked' : ''; ?>> Não
            
                                </div>
                    
                                <div class="elemento">
            
                                    <label>Qual?</label>
                                    <input type="text" name="suplemento_oral" id="suplemento_oral" class="inputUser" value="<?php echo $suplemento_oral ?>">
            
                                </div>
                    
                                </div>
    
    
                                <div class="container3">
    
                                    <div class="elemento">
                        
                                        <label>Antecedentes oncológicos:</label>
                                        <input type="radio" name="tem_antecedentes_oncologicos" id="tem_antecedentes_oncologicos" value="1" <?php echo ($tem_antecedentes_oncologicos == '1') ? 'checked' : ''; ?>> Sim
                                        <input type="radio" name="tem_antecedentes_oncologicos" id="tem_antecedentes_oncologicos" value="0" <?php echo ($tem_antecedentes_oncologicos == '0') ? 'checked' : ''; ?>> Não
                
                                    </div>
                                    
                                    <div class="elemento">
                
                                        <label>Qual:</label>
                                        <input type="text" name="antecedentes_oncologicos" id="antecedentes_oncologicos" class="inputUser" value="<?php echo $antecedentes_oncologicos ?>">
                
                                    </div>
                        
                                    <div class="elemento">
                
                                        <label>Tem diabetes?</label>
                                        <input type="radio" name="tem_diabetes" id="tem_diabetes" value="1" <?php echo ($tem_diabetes == '1') ? 'checked' : ''; ?>> Sim
                                        <input type="radio" name="tem_diabetes" id="tem_diabetes" value="0" <?php echo ($tem_diabetes == '0') ? 'checked' : ''; ?>> Não
                
                                    </div>
                        
                                    </div>
                                    
    
                                    <div class="container3">
    
                                        <div class="elemento">
                            
                                            <label>Cirurgia Plástica Estética:</label>
                                            <input type="radio" name="fez_cirurgia_plastica_estetica" id="fez_cirurgia_plastica_estetica" value="1" <?php echo ($fez_cirurgia_plastica_estetica == '1') ? 'checked' : ''; ?>> Sim
                                            <input type="radio" name="fez_cirurgia_plastica_estetica" id="fez_cirurgia_plastica_estetica" value="0" <?php echo ($fez_cirurgia_plastica_estetica == '0') ? 'checked' : ''; ?>> Não
                    
                                        </div>
                                        
                                        <div class="elemento">
                    
                                            <label>Qual:</label>
                                            <input type="text" name="cirurgia_plastica_estetica" id="cirurgia_plastica_estetica" class="inputUser" value="<?php echo $cirurgia_plastica_estetica ?>">
                    
                                        </div>
                            
                                        <div class="elemento">
                    
                                            <label>Com relação a alopecia;</label>
                                            <label>Qual a queixa principal?</label>
                                            <input type="text" name="queixa_alopecia" id="queixa_alopecia" class="inputUser" value="<?php echo $queixa_alopecia ?>">
                    
                                        </div>
                            
                                        </div>
    
    
                                        <div class="container3">
    
                                            <div class="elemento">
                                
                                                <label>A doença acomete outras partes do corpo?</label>
                                                <input type="radio" name="alopecia_acomete_corpo" id="alopecia_acomete_corpo" value="1" <?php echo ($alopecia_acomete_corpo == '1') ? 'checked' : ''; ?>> Sim
                                        
                                                <input type="radio" name="alopecia_acomete_corpo" id="alopecia_acomete_corpo" value="0" <?php echo ($alopecia_acomete_corpo == '0') ? 'checked' : ''; ?>> Não
                                            
    
                                            </div>
                                            
                                            <div class="elemento">
                        
                                                <label>Quais?</label>
                                                <input type="text" name="partes_acometidas" id="partes_acometidas" class="inputUser" value="<?php echo $partes_acometidas ?>">
                        
                                            </div>
                                
                                            <div class="elemento">
                        
                                                <label>Há quanto tempo começou a disfunção?</label>
                                                <input type="text" name="tempo_disfuncao" id="tempo_disfuncao" class="inputUser" value="<?php echo $tempo_disfuncao ?>">
                        
                                            </div>
                                
                                            </div>
    
    
                                            <div class="container3">
    
                                                <div class="elemento">
                                    
                                                    <label>A disfunção está:</label>
                                                    <input type="radio" name="estado_disfuncao" id="estado_disfuncao" value="Estavel" <?php echo ($estado_disfuncao == 'estavel') ? 'checked' : ''; ?>> Estável
                                                    <input type="radio" name="estado_disfuncao" id="estado_disfuncao" value="Aumentando" <?php echo ($estado_disfuncao == 'aumentando') ? 'checked' : ''; ?>> Aumentando
                                                    <input type="radio" name="estado_disfuncao" id="estado_disfuncao" value="Diminuindo" <?php echo ($estado_disfuncao == 'diminuindo') ? 'checked' : ''; ?>> Diminuindo
                                                
                                                </div>
    
                                            </div>

            <p></p>
            <div class="container2">
            <img src="../imagens/MEDIDAS-removebg-preview.png">
        
        </div>

        <div class="campo">
        <br>
        <h2>
        <label for="experiencia"><strong>Relatório: </strong></label>
        <textarea rows="6" style="width: 26em" name="experiencia" id="experiencia" class="inputUser"><?php echo htmlspecialchars ($experiencia); ?></textarea>
        </h2>
        </div>
        
    
        <h2>TERMO DE RESPONSABILIDADE</h2>
        <p>Eu <input type="text" name= assinatura id="assinatura" class="inputUser" value="<?php echo $assinatura ?>">, comprometo-me a seguir todas as orientações e a seguir minha prescrição domiciliar. As declarações acima são verdadeiras, não cabendo ao profissional a responsabilidade por informações por mim omitidas.</p>
        <div class="form-group">
            <center>       
            <label>Assinatura do paciente</label>
            <input type="text" name="assinatura_paciente" id="assinatura_paciente" class="inputUser" value="<?php echo $assinatura_paciente ?>">
            <label>Data</label>
            <input type="date" name="data_assinatura_paciente" id="data_assinatura_paciente" class="inputUser" value="<?php echo $data_assinatura_paciente ?>">
        </div>
            </center>
    
        <div class="form-group">
            <center>
            <label>Nome e Assinatura do Profissional</label>
            <input type="text" name="nome_profissional" id="nome_profissional" class="inputUser" value="<?php echo $nome_profissional ?>">
            <br></br>
            <label>Data</label>
            <input type="date" name="data_assinatura_profissional" id="data_assinatura_profissional" class="inputUser" value="<?php echo $data_assinatura_profissional ?>">
        </center>
        </div>

        <br></br>
    

    </div>

    <center>        
        <input type="submit" name="update" id="update">
    </center>


    </div>

    </form>


<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

<script>
     $('#celular').mask('(00) 00000-0000');
     $('#telefone_residencial').mask('(00) 0000-0000');
     $('#telefone_comercial').mask('(00) 0000-0000');
     $('#cep').mask('00000-000');
     $('#cpf').mask('000.000.000-00', {reverse: true});
     $('#date_time').mask('00/00/0000 00:00:00');
</script>

</body>
</html>