<?php
include_once('../conexao.php');

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_data = $_POST;
    
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    // Recupera os dados do formulário
    $nome_completo = $user_data['nome_completo'] ?? null;
    $data_nascimento = $user_data['data_nascimento'] ?? null;
    $idade = $user_data['idade'] ?? null;
    $endereco = $user_data['endereco'] ?? null;
    $cep = $user_data['cep'] ?? null;
    $bairro = $user_data['bairro'] ?? null;
    $cidade = $user_data['cidade'] ?? null;
    $estado = $user_data['estado'] ?? null;
    $telefone_residencial = $user_data['telefone_residencial'] ?? null;
    $telefone_comercial = $user_data['telefone_comercial'] ?? null;
    $celular = $user_data['celular'] ?? null;
    $escolaridade = $user_data['escolaridade'] ?? null;
    $escolaridade_completa = $user_data['escolaridade_completa'] ?? null;
    $profissao = $user_data['profissao'] ?? null;
    $estado_civil = $user_data['estado_civil'] ?? null;
    $filtro_solar = $user_data['filtro_solar'] ?? null;
    $frequencia = $user_data['frequencia'] ?? null;
    $usa_chapeu_ou_bone = $user_data['usa_chapeu_ou_bone'] ?? null;
    $usa_cosmeticos_capilares = $user_data['usa_cosmeticos_capilares'] ?? null;
    $exposicao_ao_sol = $user_data['exposicao_ao_sol'] ?? null;
    $cosmeticos_capilares = $user_data['cosmeticos_capilares'] ?? null;
    $usa_isotretinoina_ou_derivado = $user_data['usa_isotretinoina_ou_derivado'] ?? null;
    $usa_cosmeticos_fotossensibilizantes = $user_data['usa_cosmeticos_fotossensibilizantes'] ?? null;
    $cosmeticos_fotossensibilizantes = $user_data['cosmeticos_fotossensibilizantes'] ?? null;
    $usa_lentes_de_contato = $user_data['usa_lentes_de_contato'] ?? null;
    $tabagismo = $user_data['tabagismo'] ?? null;
    $quantidade_cigarros_dia = $user_data['quantidade_cigarros_dia'] ?? null;
    $ingere_bebida_alcoolica = $user_data['ingere_bebida_alcoolica'] ?? null;
    $frequencia_bebida_alcoolica = $user_data['frequencia_bebida_alcoolica'] ?? null;
    $qualidade_de_sono = $user_data['qualidade_de_sono'] ?? null;
    $horas_de_sono = $user_data['horas_de_sono'] ?? null;
    $quantidade_ingestao_agua_diaria = $user_data['quantidade_ingestao_agua_diaria'] ?? null;
    $alimentacao = $user_data['alimentacao'] ?? null;
    $faz_dieta_alimentar_rigorosa = $user_data['faz_dieta_alimentar_rigorosa'] ?? null;
    $possui_patologia_de_pele = $user_data['possui_patologia_de_pele'] ?? null;
    $patologia_de_pele = $user_data['patologia_de_pele'] ?? null;
    $outra_patologia = $user_data['outra_patologia'] ?? null;
    $faz_procedimento_estetico_facial = $user_data['faz_procedimento_estetico_facial'] ?? null;
    $possui_alteracoes_tireoide = $user_data['possui_alteracoes_tireoide'] ?? null;
    $hipotireoidismo = $user_data['hipotireoidismo'] ?? null;
    $possui_hipertireoidismo = $user_data['possui_hipertireoidismo'] ?? null;
    $toma_medicacao = $user_data['toma_medicacao'] ?? null;
    $medicacao = $user_data['medicacao'] ?? null;
    $tempo_de_medicacao = $user_data['tempo_de_medicacao'] ?? null;
    $usa_suplemento_oral = $user_data['usa_suplemento_oral'] ?? null;
    $suplemento_oral = $user_data['suplemento_oral'] ?? null;
    $possui_antecedentes_oncologicos = $user_data['possui_antecedentes_oncologicos'] ?? null;
    $antecedentes_oncologicos = $user_data['antecedentes_oncologicos'] ?? null;
    $possui_diabetes = $user_data['possui_diabetes'] ?? null;
    $possui_cirurgia_plastica_estetica = $user_data['possui_cirurgia_plastica_estetica'] ?? null;
    $plastica_estetica = $user_data['plastica_estetica'] ?? null;
    $queixa_principal_alopecia = $user_data['queixa_principal_alopecia'] ?? null;
    $alopecia_acomete_partes_do_corpo = $user_data['alopecia_acomete_partes_do_corpo'] ?? null;
    $partes_afetadas_alopecia = $user_data['partes_afetadas_alopecia'] ?? null;
    $tempo_disfuncao = $user_data['tempo_disfuncao'] ?? null;
    $tipo_disfuncao = $user_data['tipo_disfuncao'] ?? null;
    $condicao_cabelo = $user_data['condicao_cabelo'] ?? null;
    $alteracoes_couro_cabeludo = $user_data['alteracoes_couro_cabeludo'] ?? null;
    $teve_crises_couro_cabeludo = $user_data['teve_crises_couro_cabeludo'] ?? null;
    $crises_couro_cabeludo = $user_data['crises_couro_cabeludo'] ?? null;
    $periodo_crises = $user_data['periodo_crises'] ?? null;
    // Prepara a instrução SQL para atualizar os dados no banco
    
    
    $sql = "UPDATE anamnese_capilar SET 
    nome_completo = '$nome_completo',
    data_nascimento = '$data_nascimento',
    idade = '$idade',
    endereco = '$endereco',
    cep = '$cep',
    bairro = '$bairro',
    cidade = '$cidade',
    estado = '$estado',
    telefone_residencial = '$telefone_residencial',
    telefone_comercial = '$telefone_comercial',
    celular = '$celular',
    escolaridade = '$escolaridade',
    escolaridade_completa = '$escolaridade_completa',
    profissao = '$profissao',
    estado_civil = '$estado_civil',
    filtro_solar = '$filtro_solar',
    frequencia = '$frequencia',
    usa_chapeu_ou_bone = '$usa_chapeu_ou_bone',
    usa_cosmeticos_capilares = '$usa_cosmeticos_capilares',
    exposicao_ao_sol = '$exposicao_ao_sol',
    cosmeticos_capilares = '$cosmeticos_capilares',
    usa_isotretinoina_ou_derivado = '$usa_isotretinoina_ou_derivado',
    usa_cosmeticos_fotossensibilizantes = '$usa_cosmeticos_fotossensibilizantes',
    cosmeticos_fotossensibilizantes = '$cosmeticos_fotossensibilizantes',
    usa_lentes_de_contato = '$usa_lentes_de_contato',
    tabagismo = '$tabagismo',
    quantidade_cigarros_dia = '$quantidade_cigarros_dia',
    ingere_bebida_alcoolica = '$ingere_bebida_alcoolica',
    frequencia_bebida_alcoolica = '$frequencia_bebida_alcoolica',
    qualidade_de_sono = '$qualidade_de_sono',
    horas_de_sono = '$horas_de_sono',
    quantidade_ingestao_agua_diaria = '$quantidade_ingestao_agua_diaria',
    alimentacao = '$alimentacao',
    faz_dieta_alimentar_rigorosa = '$faz_dieta_alimentar_rigorosa',
    possui_patologia_de_pele = '$possui_patologia_de_pele',
    patologia_de_pele = '$patologia_de_pele',
    outra_patologia = '$outra_patologia',
    faz_procedimento_estetico_facial = '$faz_procedimento_estetico_facial',
    possui_alteracoes_tireoide = '$possui_alteracoes_tireoide',
    hipotireoidismo = '$hipotireoidismo',
    possui_hipertireoidismo = '$possui_hipertireoidismo',
    toma_medicacao = '$toma_medicacao',
    medicacao = '$medicacao',
    tempo_de_medicacao = '$tempo_de_medicacao',
    usa_suplemento_oral = '$usa_suplemento_oral',
    suplemento_oral = '$suplemento_oral',
    possui_antecedentes_oncologicos = '$possui_antecedentes_oncologicos',
    antecedentes_oncologicos = '$antecedentes_oncologicos',
    possui_diabetes = '$possui_diabetes',
    possui_cirurgia_plastica_estetica = '$possui_cirurgia_plastica_estetica',
    plastica_estetica = '$plastica_estetica',
    queixa_principal_alopecia = '$queixa_principal_alopecia',
    alopecia_acomete_partes_do_corpo = '$alopecia_acomete_partes_do_corpo',
    partes_afetadas_alopecia = '$partes_afetadas_alopecia',
    tempo_disfuncao = '$tempo_disfuncao',
    tipo_disfuncao = '$tipo_disfuncao',
    condicao_cabelo = '$condicao_cabelo',
    alteracoes_couro_cabeludo = '$alteracoes_couro_cabeludo',
    teve_crises_couro_cabeludo = '$teve_crises_couro_cabeludo',
    crises_couro_cabeludo = '$crises_couro_cabeludo',
    periodo_crises = '$periodo_crises'
    WHERE id = '$id'";

$resultado = mysqli_query($conexao, $sql);

    // Executa a atualização no banco de dados
    if ($resultado) {
        // Redireciona para a página de listagem com uma mensagem de sucesso
        header("Location: listar.anamnese.capilar.php?message=Registro atualizado com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar o registro: " . $conexao->error;
    }

    // Fecha a conexão
    $conexao->close();
} else {
    echo "Método de requisição inválido.";
}
?>
