<?php
if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];
    $sqlSelect = "SELECT * FROM anamnese_capilar WHERE id=$id";
    $resultado = $conexao->query($sqlSelect);
   

    if ($resultado->num_rows > 0) {
        $user_data = $resultado->fetch_assoc();

        if ($user_data) {

            $nome_completo = $user_data['nome_completo'] ?? null;
            $data_nascimento = $user_data['data_nascimento'] ?? null;
            $idade = $user_data['idade'] ?? null;
            $endereco = $user_data['endereco'] ?? null;
            $cep = $user_data['cep'] ?? null;
            $bairro = $user_data['bairro'] ?? null;
            $cidade = $user_data['cidade'] ?? null;
            $estado = $user_data['estado'] ?? null;
            $telefone_residencial = $user_data['telefone_residencial'] ?? null;
            $telefone_comercial = $user_data['telefone_comercial'] ?? null;
            $celular = $user_data['celular'] ?? null;
            $escolaridade = $user_data['escolaridade'] ?? null;
            $escolaridade_completa = $user_data['escolaridade_completa'] ?? null;
            $profissao = $user_data['profissao'] ?? null;
            $estado_civil = $user_data['estado_civil'] ?? null;
            $filtro_solar = $user_data['filtro_solar'] ?? null;
            $frequencia = $user_data['frequencia'] ?? null;
            $usa_chapeu_ou_bone = $user_data['usa_chapeu_ou_bone'] ?? null;
            $usa_cosmeticos_capilares = $user_data['usa_cosmeticos_capilares'] ?? null;
            $exposicao_ao_sol = $user_data['exposicao_ao_sol'] ?? null;
            $cosmeticos_capilares = $user_data['cosmeticos_capilares'] ?? null;
            $usa_isotretinoina_ou_derivado = $user_data['usa_isotretinoina_ou_derivado'] ?? null;
            $usa_cosmeticos_fotossensibilizantes = $user_data['usa_cosmeticos_fotossensibilizantes'] ?? null;
            $cosmeticos_fotossensibilizantes = $user_data['cosmeticos_fotossensibilizantes'] ?? null;
            $usa_lentes_de_contato = $user_data['usa_lentes_de_contato'] ?? null;
            $tabagismo = $user_data['tabagismo'] ?? null;
            $quantidade_cigarros_dia = $user_data['quantidade_cigarros_dia'] ?? null;
            $ingere_bebida_alcoolica = $user_data['ingere_bebida_alcoolica'] ?? null;
            $frequencia_bebida_alcoolica = $user_data['frequencia_bebida_alcoolica'] ?? null;
            $qualidade_de_sono = $user_data['qualidade_de_sono'] ?? null;
            $horas_de_sono = $user_data['horas_de_sono'] ?? null;
            $quantidade_ingestao_agua_diaria = $user_data['quantidade_ingestao_agua_diaria'] ?? null;
            $alimentacao = $user_data['alimentacao'] ?? null;
            $faz_dieta_alimentar_rigorosa = $user_data['faz_dieta_alimentar_rigorosa'] ?? null;
            $possui_patologia_de_pele = $user_data['possui_patologia_de_pele'] ?? null;
            $patologia_de_pele = $user_data['patologia_de_pele'] ?? null;
            $outra_patologia = $user_data['outra_patologia'] ?? null;
            $faz_procedimento_estetico_facial = $user_data['faz_procedimento_estetico_facial'] ?? null;
            $possui_alteracoes_tireoide = $user_data['possui_alteracoes_tireoide'] ?? null;
            $hipotireoidismo = $user_data['hipotireoidismo'] ?? null;
            $possui_hipertireoidismo = $user_data['possui_hipertireoidismo'] ?? null;
            $toma_medicacao = $user_data['toma_medicacao'] ?? null;
            $medicacao = $user_data['medicacao'] ?? null;
            $tempo_de_medicacao = $user_data['tempo_de_medicacao'] ?? null;
            $usa_suplemento_oral = $user_data['usa_suplemento_oral'] ?? null;
            $suplemento_oral = $user_data['suplemento_oral'] ?? null;
            $possui_antecedentes_oncologicos = $user_data['possui_antecedentes_oncologicos'] ?? null;
            $antecedentes_oncologicos = $user_data['antecedentes_oncologicos'] ?? null;
            $possui_diabetes = $user_data['possui_diabetes'] ?? null;
            $possui_cirurgia_plastica_estetica = $user_data['possui_cirurgia_plastica_estetica'] ?? null;
            $plastica_estetica = $user_data['plastica_estetica'] ?? null;
            $queixa_principal_alopecia = $user_data['queixa_principal_alopecia'] ?? null;
            $alopecia_acomete_partes_do_corpo = $user_data['alopecia_acomete_partes_do_corpo'] ?? null;
            $partes_afetadas_alopecia = $user_data['partes_afetadas_alopecia'] ?? null;
            $tempo_disfuncao = $user_data['tempo_disfuncao'] ?? null;
            $tipo_disfuncao = $user_data['tipo_disfuncao'] ?? null;
            $condicao_cabelo = $user_data['condicao_cabelo'] ?? null;
            $alteracoes_couro_cabeludo = $user_data['alteracoes_couro_cabeludo'] ?? null;
            $teve_crises_couro_cabeludo = $user_data['teve_crises_couro_cabeludo'] ?? null;
            $crises_couro_cabeludo = $user_data['crises_couro_cabeludo'] ?? null;
            $periodo_crises = $user_data['periodo_crises'] ?? null;
        }
    } else {
        header('Location: listar.anamnese.capilar.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento

    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha Anamnese Capilar</title>
    <link rel="stylesheet" href="../css/Ficha.anamnese.css">
</head>

<style>
    /* Estilo para o fundo */
    .background {
        background-color: #ffffff;
        /* Cor de fundo */
    }

    /* Estilo para o menu */
    header {
        background-color: rgb(76, 115, 55);
        /* Cor de fundo do cabeçalho */
        padding: 20px 0;
        /* Espaçamento interno no cabeçalho */
        text-align: center;
        /* Alinhamento centralizado do texto */
    }

    .links {
        list-style-type: none;
        /* Remove marcadores de lista */
        margin: 0;
        /* Remove margem externa */
        padding: 0;
        /* Remove preenchimento interno */
    }

    .links li {
        display: inline;
        /* Exibe os itens de menu em linha */
        margin-right: 20px;
        /* Espaçamento entre os itens do menu */
    }

    .links li a {
        text-decoration: none;
        /* Remove sublinhado dos links */
        color: #fff;
        /* Cor do texto */
        font-weight: bold;
        /* Texto em negrito */
        transition: color 0.3s;
        /* Transição de cor suave */
    }

    .links li a:hover {
        color: #8dd090;
        /* Cor do texto ao passar o mouse sobre o link */
    }

    .container2 {
        text-align: center;
        /* Centraliza o conteúdo dentro do contêiner */
    }

    .container2 img {
        display: inline-block;
        /* Permite a aplicação de margens automáticas */
        margin: 0 auto;
        /* Centraliza a imagem horizontalmente */
    }

    .botao-estilizado2 {
        position: absolute;
        /* Posição absoluta */
        top: 10px;
        /* Distância do topo */
        left: 10px;
        /* Distância da direita */
        background-color: rgb(13, 55, 8);
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    #update {
        background-color: rgb(11, 87, 1);
        /* Cor de fundo do botão */
        color: #fff;
        /* Cor do texto do botão */
        padding: 10px 20px;
        /* Espaçamento interno do botão */
        font-size: 18px;
        /* Tamanho da fonte do botão */
        border: none;
        /* Remove a borda padrão do botão */
        border-radius: 8px;
        /* Borda arredondada */
        cursor: pointer;
        /* Altera o cursor ao passar sobre o botão */
        transition: background-color 0.3s ease;
        /* Adiciona uma transição suave na mudança de cor de fundo */
        align-items: center;
    }

    #update:hover {
        background-color: #45a049;
        /* Cor de fundo do botão ao passar o mouse */
    }
</style>

<body>

    <a href="listar.anamnese.capilar.php">
        <button class="botao-estilizado2">Anamnese Capilar</button>
    </a>


    <div class="background">
        <header>
            <ul class="links">
                <li><a href="#dados-pessoais">Dados pessoais</a></li>
                <li><a href="#habitos-diarios">Hábitos diários</a></li>
                <li><a href="#historico-clinico-e-avaliacao-cutanea">Histórico clínico e avaliação cutânea</a></li>
                <li><a href="#termo-de-responsabilidade">Termo de Responsabilidade</a></li>
            </ul>
        </header>

        <a href="/estetica2/pagina_inicial/ficha.html">
            <button class="botao-estilizado">Voltar</button>
        </a>


        <div class="container">
            <h1>FICHA DE ANAMNESE CAPILAR</h1>
        </div>

        <form action="salvar.anamnese.capilar.php" method="POST">


            <div class="input-container">
            </div>

            <h2 id="dados-pessoais">DADOS PESSOAIS</h2>

            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $id; ?>">

                <label>Nome:</label>
                <input required type="text" name="nome_completo" id="nome_completo" class="inputUser" value="<?php echo $nome_completo ?>" placeholder="Nome completo">

                <label>Data de Nascimento:</label>
                <input required type="date" name="data_nascimento" id="data_nacimento" class="inputUser" value="<?php echo $data_nascimento ?>">

                <label>Idade:</label>
                <input required type="number" name="idade" id="idade" class="inputUser" value="<?php echo $idade ?>">

                <label>Endereço:</label>
                <input required type="text" name="endereco" id="endereco" class="inputUser" value="<?php echo $endereco ?>">
                <!-- <input required type="text" name="endereco"> -->

                <label for="text">Estado </label>
                <select name="estado">
                    <option value="<?php echo $estado ?>"><?php echo $estado ?></option>
                    <option value="AC">AC</option>
                    <option value="AL">AL</option>
                    <option value="AP">AP</option>
                    <option value="AM">AM</option>
                    <option value="BA">BA</option>
                    <option value="BA">CE</option>
                    <option value="CE">ES</option>
                    <option value="GO">GO</option>
                    <option value="MA">MA</option>
                    <option value="MT">MT </option>
                    <option value="MS">MS</option>
                    <option value="MG">MG</option>
                    <option value="PA">PA</option>
                    <option value="PB">PB</option>
                    <option value="PR">PR</option>
                    <option value="PE">PE</option>
                    <option value="PI">PI</option>
                    <option value="RJ">RJ</option>
                    <option value="RN">RN</option>
                    <option value="RS">RS</option>
                    <option value="RO">RO</option>
                    <option value="RR">RR</option>
                    <option value="SC">SC</option>
                    <option value="SP">SP</option>
                    <option value="SE">SE</option>
                    <option value="TO">TO</option>
                    <option value="DF">DF</option>
                </select>

            </div>

            <div class="form-group">
                <?php
                function selected($value, $selected)
                {
                    return $value == $selected ? ' selected="selected"' : '';
                }
                ?>

                <label>CEP:</label>
                <input required type="text" name="cep" id="cep" class="inputUser" value="<?php echo $cep ?>">

                <label>Bairro:</label>
                <input required type="text" name="bairro" id="bairro" class="inputUser" value="<?php echo $bairro ?>">

                <label>Cidade:</label>
                <input required type="text" name="cidade" id="cidade" class="inputUser" value="<?php echo $cidade ?>">



            </div>


            <div class="form-group">


                <label>Tel.Res.</label>
                <input required type="text" name="telefone_residencial" id="telefone_residencial" class="inputUser" value="<?php echo $telefone_residencial ?>">

                <label>Tel.Com.</label>
                <input required type="text" name="telefone_comercial" id="telefone_comercial" class="inputUser" value="<?php echo $telefone_comercial ?>">

                <label>Cel.</label>
                <input required type="text" name="celular" id="celular" class="inputUser" value="<?php echo $celular ?>">

                <label>Escolaridade:</label>
                <select name="escolaridade" id="escolaridade" class="inputUser" value="<?php echo $escolaridade ?>">
                    <option value="<?php echo $escolaridade ?>"><?php echo $escolaridade ?></option>
                    <option value="Ensino Fundamental">Ensino Fundamental</option>
                    <option value="Ensino Médio">Ensino Médio</option>
                    <option value="Curso Técnico">Curso Técnico</option>
                    <option value="Universidade">Universidade</option>
                    <option value="Pós-Graduação">Pós-Graduação</option>
                    <option value="Mestrado">Mestrado</option>
                    <option value="Doutorado">Doutorado</option>
                    <option value="Pós-Doutorado">Pós-Doutorado</option>

                    <input required type="radio" name="escolaridade_completa" id="escolaridade_completa" value="1" <?php echo ($escolaridade_completa == '1') ? 'checked' : ''; ?>>
                    <label>Completo</label>

                    <input required type="radio" name="escolaridade_completa" id="escolaridade_completa" value="0" <?php echo ($escolaridade_completa == '0') ? 'checked' : ''; ?>>
                    <label>Incompleto</label>

                </select>



            </div>

            <div class="form-group">


                <label>Profissão:</label>
                <input required type="text" name="profissao" id="profissao" class="inputUser" value="<?php echo $profissao ?>">

                <label>Estado Civil:</label>
                <input required type="text" name="estado_civil" id="estado_civil" class="inputUser" value="<?php echo $estado_civil ?>">

            </div>


            <div class="container">
                <h1 id="habitos-diarios">HÁBITOS DIÁRIOS</h1>
            </div>

            <div class="container3">

                <div class="elemento">

                    <label>Exposição ao sol:</label>
                    <input required type="radio" name="exposicao_ao_sol" value="1" <?php echo ($exposicao_ao_sol == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="exposicao_ao_sol" value="0" <?php echo ($exposicao_ao_sol == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Filtro solar:</label>

                    <input required type="radio" name="filtro_solar" value="1" <?php echo ($exposicao_ao_sol == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="filtro_solar" value="0" <?php echo ($exposicao_ao_sol == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label><span>Frequência:</span></label>
                    <input required type="text" name="frequencia" id="frequencia" class="inputUser" value="<?php echo $frequencia ?>">

                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Faz uso de chapéu ou bonés diariamente?</label>
                    <input required type="radio" name="usa_chapeu_ou_bone" value="1" <?php echo ($usa_chapeu_ou_bone == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_chapeu_ou_bone" value="0" <?php echo ($usa_chapeu_ou_bone == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Utilização de cosméticos capilares:</label>
                    <input required type="radio" name="usa_cosmeticos_capilares" value="1" <?php echo ($usa_cosmeticos_capilares == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_cosmeticos_capilares" value="0" <?php echo ($usa_cosmeticos_capilares == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Qual (is):</label>
                    <input required type="text" name="cosmeticos_capilares" id="cosmeticos_capilares" class="inputUser" value="<?php echo $cosmeticos_capilares ?>">
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Uso de isotretinoína ou derivado da vitamina A tópica ou oral</label>
                    <input required type="radio" name="usa_isotretinoina_ou_derivado" value="1" <?php echo ($usa_isotretinoina_ou_derivado == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_isotretinoina_ou_derivado" value="0" <?php echo ($usa_isotretinoina_ou_derivado == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Utilização de cosméticos fotossensibilizantes:</label>
                    <input required type="radio" name="usa_cosmeticos_fotossensibilizantes" value="1" <?php echo ($usa_cosmeticos_capilares == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_cosmeticos_fotossensibilizantes" value="0" <?php echo ($usa_cosmeticos_capilares == '0') ? 'checked' : ''; ?>> Não
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Qual:</label>
                    <input required type="text" name="cosmeticos_fotossensibilizantes" id="cosmeticos_fotossensibilizantes" class="inputUser" value="<?php echo $cosmeticos_fotossensibilizantes ?>">
                </div>

                <div class="elemento">
                    <label>Usa lentes de contato:</label>
                    <input required type="radio" name="usa_lentes_de_contato" value="1" <?php echo ($usa_lentes_de_contato == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_lentes_de_contato" value="0" <?php echo ($usa_lentes_de_contato == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Tabagismo:</label>
                    <input required type="radio" name="tabagismo" value="1" <?php echo ($tabagismo == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="tabagismo" value="0" <?php echo ($tabagismo == '0') ? 'checked' : ''; ?>> Não
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Quantidade de cigarros/dia:</label>
                    <input required type="text" name="quantidade_cigarros_dia" id="quantidade_cigarros_dia" class="inputUser" value="<?php echo $quantidade_cigarros_dia ?>">
                </div>

                <div class="elemento">
                    <label>Ingere bebida alcoólica:</label>
                    <input required type="radio" name="ingere_bebida_alcoolica" value="1" <?php echo ($ingere_bebida_alcoolica == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="ingere_bebida_alcoolica" value="0" <?php echo ($ingere_bebida_alcoolica == '0') ? 'checked' : ''; ?>> Não
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Frequência:</label>
                    <input required type="text" name="frequencia_bebida_alcoolica" id="frequencia_bebida_alcoolica" class="inputUser" value="<?php echo $frequencia_bebida_alcoolica ?>">
                </div>

                <div class="elemento">
                    <label>Qualidade do sono:</label>
                    <input required type="radio" name="qualidade_de_sono" value="Boa" <?php echo ($qualidade_de_sono == 'Boa') ? 'checked' : ''; ?>> Boa
                    <input required type="radio" name="qualidade_de_sono" value="Regular" <?php echo ($qualidade_de_sono == 'Regular') ? 'checked' : ''; ?>> Regular
                    <input required type="radio" name="qualidade_de_sono" value="Péssima" <?php echo ($qualidade_de_sono == 'Péssima') ? 'checked' : ''; ?>> Péssima
                </div>

                <div class="elemento">
                    <label>Quantas horas / noite:</label>
                    <input required type="text" name="horas_de_sono">
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Ingestão de água (copos / dia):</label>
                    <input required type="text" name="quantidade_ingestao_agua_diaria" id="quantidade_ingestao_agua_diaria" class="inputUser" value="<?php echo $quantidade_ingestao_agua_diaria ?>">
                </div>

                <div class="elemento">
                    <label>Alimentação:</label>
                    <input required type="radio" name="alimentacao" value="Boa" <?php echo ($alimentacao == 'Boa') ? 'checked' : ''; ?>> Boa
                    <input required type="radio" name="alimentacao" value="Regular" <?php echo ($alimentacao == 'Regular') ? 'checked' : ''; ?>> Regular
                    <input required type="radio" name="alimentacao" value="Péssima" <?php echo ($alimentacao == 'Péssima') ? 'checked' : ''; ?>> Péssima
                </div>

            </div>

            <div class="container3">

                <div class="elemento">
                    <label>Está fazendo algum tipo de dieta alimentar rigorosa?</label>
                    <input required type="radio" name="faz_dieta_alimentar_rigorosa" value="1" <?php echo ($faz_dieta_alimentar_rigorosa == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="faz_dieta_alimentar_rigorosa" value="0" <?php echo ($faz_dieta_alimentar_rigorosa == '0') ? 'checked' : ''; ?>> Não
                </div>
            </div>

            <div class="container">
                <h1 id="historico-clinico-e-avaliacao-cutanea">HISTÓRICO CLÍNICO E AVALIAÇÃO CUTÂNEA</h1>

            </div>
            <div class="container3">
                <div class="elemento">
                    <label>Alguma patologia de pele:</label>
                    <input required type="radio" name="possui_patologia_de_pele" value="1" <?php echo ($possui_patologia_de_pele == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_patologia_de_pele" value="0" <?php echo ($possui_patologia_de_pele == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Qual:</label>
                    <input required type="radio" name="patologia_de_pele" value="Acne" <?php echo ($patologia_de_pele == 'Acne') ? 'checked' : ''; ?>> Acne

                    <input required type="radio" name="patologia_de_pele" value="Psoríase" <?php echo ($patologia_de_pele == 'Psoríase') ? 'checked' : ''; ?>> Psoríase

                    <input required type="radio" name="patologia_de_pele" value="Vitiligo" <?php echo ($patologia_de_pele == 'Vitiligo') ? 'checked' : ''; ?>> Vitiligo

                    <input required type="radio" name="patologia_de_pele" value="Nenhuma" <?php echo ($patologia_de_pele == 'Nenhuma') ? 'checked' : ''; ?>> Nenhuma


                </div>

                <div class="elemento">
                    <label>Outra:</label>
                    <input required type="text" name="outra_patologia" id="outra_patologia" class="inputUser" value="<?php echo $outra_patologia ?>">
                </div>
            </div>

            <div class="container3">
                <div class="elemento">
                    <label>Está realizando algum procedimento estético facial atualmente?</label>
                    <input required type="radio" name="faz_procedimento_estetico_facial" value="1" <?php echo ($faz_procedimento_estetico_facial == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="faz_procedimento_estetico_facial" value="0" <?php echo ($faz_procedimento_estetico_facial == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Alterações na tireoide:</label>
                    <input required type="radio" name="possui_alteracoes_tireoide" value="1" <?php echo ($possui_alteracoes_tireoide == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_alteracoes_tireoide" value="0" <?php echo ($possui_alteracoes_tireoide == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Hipotiroidismo:</label>
                    <input required type="radio" name="hipotireoidismo" value="1" <?php echo ($hipotireoidismo == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="hipotireoidismo" value="0" <?php echo ($hipotireoidismo == '0') ? 'checked' : ''; ?>> Não

                </div>

            </div>
            <div class="container3">
                <div class="elemento">
                    <label>Hipertiroidismo:</label>
                    <input required type="radio" name="possui_hipertireoidismo" value="1" <?php echo ($possui_hipertireoidismo == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_hipertireoidismo" value="0" <?php echo ($possui_hipertireoidismo == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Toma medicação?</label>
                    <input required type="radio" name="toma_medicacao" value="1" <?php echo ($toma_medicacao == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="toma_medicacao" value="0" <?php echo ($toma_medicacao == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Qual?</label>
                    <input required type="text" name="medicacao" id="medicacao" class="inputUser" value="<?php echo $medicacao ?>">

                </div>

            </div>


            <div class="container3">

                <div class="elemento">

                    <label>há quanto tempo?</label>
                    <input required type="text" name="tempo_de_medicacao" id="tempo_de_medicacao" class="inputUser" value="<?php echo $tempo_de_medicacao ?>">

                </div>

                <div class="elemento">

                    <label>Usa algum suplemento oral?</label>
                    <input required type="radio" name="usa_suplemento_oral" value="1" <?php echo ($usa_suplemento_oral == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="usa_suplemento_oral" value="0" <?php echo ($usa_suplemento_oral == '0') ? 'checked' : ''; ?>> Não

                </div>

                <div class="elemento">

                    <label>Qual?</label>
                    <input required type="text" name="suplemento_oral" id="suplemento_oral" class="inputUser" value="<?php echo $suplemento_oral ?>">

                </div>

            </div>


            <div class="container3">
                <div class="elemento">
                    <label>Antecedentes oncológicos:</label>
                    <input required type="radio" name="possui_antecedentes_oncologicos" value="1" <?php echo ($possui_antecedentes_oncologicos == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_antecedentes_oncologicos" value="0" <?php echo ($possui_antecedentes_oncologicos == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Qual:</label>
                    <input required type="text" name="antecedentes_oncologicos" id="antecedentes_oncologicos" class="inputUser" value="<?php echo $antecedentes_oncologicos ?>">
                </div>

                <div class="elemento">
                    <label>Tem diabetes?</label>
                    <input required type="radio" name="possui_diabetes" value="1" <?php echo ($possui_diabetes == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_diabetes" value="0" <?php echo ($possui_diabetes == '0') ? 'checked' : ''; ?>> Não
                </div>
            </div>


            <div class="container3">
                <div class="elemento">
                    <label>Cirurgia Plástica Estética:</label>
                    <input required type="radio" name="possui_cirurgia_plastica_estetica" value="1" <?php echo ($possui_cirurgia_plastica_estetica == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="possui_cirurgia_plastica_estetica" value="0" <?php echo ($possui_cirurgia_plastica_estetica == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Qual:</label>
                    <input required type="text" name="plastica_estetica" id="plastica_estetica" class="inputUser" value="<?php echo $plastica_estetica ?>">
                </div>

                <div class="elemento">

                    <label>Com relação a alopecia;</label>
                    <label>Qual a queixa principal?</label>
                    <input required type="text" name="queixa_principal_alopecia" id="queixa_principal_alopecia" class="inputUser" value="<?php echo $queixa_principal_alopecia ?>">

                </div>

            </div>

            <div class="container3">
                <div class="elemento">
                    <label>A doença acomete outras partes do corpo?</label>
                    <input required type="radio" name="alopecia_acomete_partes_do_corpo" value="1" <?php echo ($alopecia_acomete_partes_do_corpo == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="alopecia_acomete_partes_do_corpo" value="0" <?php echo ($alopecia_acomete_partes_do_corpo == '0') ? 'checked' : ''; ?>> Não
                </div>

                <div class="elemento">
                    <label>Quais?</label>
                    <input required type="text" name="partes_afetadas_alopecia" id="partes_afetadas_alopecia" class="inputUser" value="<?php echo $partes_afetadas_alopecia ?>">
                </div>

                <div class="elemento">
                    <label>Há quanto tempo começou a disfunção?</label>
                    <input required type="text" name="tempo_disfuncao" id="tempo_disfuncao" class="inputUser" value="<?php echo $tempo_disfuncao ?>">
                </div>
            </div>


            <div class="container3">
                <div class="elemento">
                    <label>A disfunção está:</label>
                    <input required type="radio" name="tipo_disfuncao" value="estavel" <?php echo ($tipo_disfuncao == 'estavel') ? 'checked' : ''; ?>> Estável
                    <input required type="radio" name="tipo_disfuncao" value="aumentando" <?php echo ($tipo_disfuncao == 'aumentando') ? 'checked' : ''; ?>> Aumentando
                    <input required type="radio" name="tipo_disfuncao" value="diminuindo" <?php echo ($tipo_disfuncao == 'diminuindo') ? 'checked' : ''; ?>> Diminuindo
                    <br>
                    <input required type="radio" name="tipo_disfuncao" value="Não_tenho_disfunção" <?php echo ($tipo_disfuncao == 'Não_tenho_disfunção') ? 'checked' : ''; ?>> Não tenho disfunção
                    </br>
                </div>

                <div class="elemento">
                    <label>O cabelo ficou: </label>
                    <input required type="radio" name="condicao_cabelo" value="Mais fino" <?php echo ($condicao_cabelo == 'Mais fino') ? 'checked' : ''; ?>> Mais Fino
                    <input required type="radio" name="condicao_cabelo" value="Mais crespo" <?php echo ($condicao_cabelo == 'Mais crespo') ? 'checked' : ''; ?>> Mais crespo
                    <input required type="radio" name="condicao_cabelo" value="Mudou de cor" <?php echo ($condicao_cabelo == 'Mudou de cor') ? 'checked' : ''; ?>> Mudou de cor
                    <input required type="radio" name="condicao_cabelo" value="Quebradiço" <?php echo ($condicao_cabelo == 'Quebradiço') ? 'checked' : ''; ?>> Ficou mais quedradiço
                    <br>
                    <input required type="radio" name="condicao_cabelo" value="Normal" <?php echo ($condicao_cabelo == 'Normal') ? 'checked' : ''; ?>> Normal
                    </br>

                </div>

                <div class="elemento">
                    <label>Apresentou alterações no couro cabeludo como:</label>
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Feridas" <?php echo ($alteracoes_couro_cabeludo == 'Feridas') ? 'checked' : ''; ?>> Feridas
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Caspa" <?php echo ($alteracoes_couro_cabeludo == 'Caspa') ? 'checked' : ''; ?>> Caspa
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Oleosidade" <?php echo ($alteracoes_couro_cabeludo == 'Oleosidade') ? 'checked' : ''; ?>> Oleosidade
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Odor" <?php echo ($alteracoes_couro_cabeludo == 'Odor') ? 'checked' : ''; ?>> Odor
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Descamação" <?php echo ($alteracoes_couro_cabeludo == 'Descamação') ? 'checked' : ''; ?>> Descamação
                    <input required type="radio" name="alteracoes_couro_cabeludo" value="Nenhuma" <?php echo ($alteracoes_couro_cabeludo == 'Nenhuma') ? 'checked' : ''; ?>> Nenhuma

                </div>
            </div>

            <div class="container3">
                <div class="elemento">
                    <label>Já teve crises em relação a essas alterações?</label>
                    <input required type="radio" name="teve_crises_couro_cabeludo" value="1" <?php echo ($teve_crises_couro_cabeludo == '1') ? 'checked' : ''; ?>> Sim
                    <input required type="radio" name="teve_crises_couro_cabeludo" value="0" <?php echo ($teve_crises_couro_cabeludo == '0') ? 'checked' : ''; ?>> Não
                </div>



                <div class="elemento">
                    <label>Qual ?</label>
                    <input required type="text" name="crises_couro_cabeludo" id="crises_couro_cabeludo" class="inputUser" value="<?php echo $crises_couro_cabeludo ?>">
                </div>

                <div class="elemento">
                    <label>Quando?</label>
                    <input required type="text" name="periodo_crises" id="periodo_crises" class="inputUser" value="<?php echo $periodo_crises ?>">
                </div>

            </div>


            <!-- <h2 id="termo-de-responsabilidade">TERMO DE RESPONSABILIDADE</h2>
        <p>Eu <input required type="text">, comprometo-me a seguir todas as orientações e a seguir minha prescrição domiciliar. As declarações acima são verdadeiras, não cabendo ao profissional a responsabilidade por informações por mim omitidas.</p>
        <div class="form-group">

    <center>
            <label>Assinatura do paciente</label>
            <input required type="text" name="assinatura-paciente">
            <label>Data</label>
            <input required type="text" name="data_assinatura_paciente">
        </div>
    </center>


        <div class="form-group">
        <center>
            <label>Nome e Assinatura do Profissional</label>
            <input required type="text" name="nome-profissional">
            <br></br>
            <label>Data</label>
            <input required type="text" name="data-assinatura-profissional">
            </div>
        </center>

    </div> -->
            <center>
            <button class="button" type="submit">Enviar</button>
            </center>
        </form>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

        <script>
            const inputs = document.querySelectorAll('input');
            inputs.forEach(input => {
                input.removeAttribute('required')
            })
            $('#celular').mask('(00) 00000-0000');
            $('#cep').mask('00000-000');
            $('#cpf').mask('000.000.000-00', {
                reverse: true
            });
            $('#date_time').mask('00/00/0000 00:00:00');
        </script>

</body>

</html>