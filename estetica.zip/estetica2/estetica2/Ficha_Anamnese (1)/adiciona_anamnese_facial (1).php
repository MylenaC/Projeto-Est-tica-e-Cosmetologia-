<?php
include '../conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $colunas = [];
    $valores = [];

    foreach ($_POST as $chave => $valor) {
        $chave = $conexao->real_escape_string($chave);
        $valor = $conexao->real_escape_string($valor);

        $colunas[] = $chave;
        $valor_tratado = '';

        if ($valor === 'Sim' || $valor === 'on') {
            $valor_tratado = 1;
        } else if ($valor === 'Não' || $valor === 'off') {
            $valor_tratado = 0;
        } else {
            $valor_tratado = $valor;
        }

        $valores[] = "'$valor_tratado'";
    }

    $sql = "INSERT INTO anamnese_facial (" . implode(',', $colunas) . ") VALUES (" . implode(',', $valores) . ")";

    if ($conexao->query($sql) === TRUE) {
        header("Location: ../Ficha_Anamnese/listar.anamnese.facial.php");
        exit();
        } else {
        echo "\nErro: " . $sql . "<br>" . $conexao->error;
    }
}
