<?php
include_once('../conexao.php');

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lista de campos esperados
    $expected_fields = array(
        'id', 'nome_completo', 'data_nascimento', 'idade', 'endereco', 'cep', 'bairro', 'cidade', 'estado', 'telefone_residencial',
        'telefone_comercial', 'celular', 'escolaridade', 'escolaridade_completa', 'profissao', 'estado_civil', 'exposicao_ao_sol',
        'filtro_solar', 'frequencia_filtro_solar', 'usa_chapeu', 'usa_cosmeticos', 'cosmeticos_capilares', 'usa_isotretinoina',
        'usa_fotossensibilizantes', 'fotossensibilizantes', 'usa_lentes', 'tabagismo', 'quantidade_cigarros', 'ingere_bebida',
        'frequencia_bebida', 'qualidade_sono', 'horas_sono', 'ingestao_agua_dia', 'alimentacao', 'faz_dieta', 'patologia_de_pele',
        'patologia', 'outra_patologia', 'faz_procedimento_estetico', 'alteracoes_tireoide', 'hipotireoidismo', 'hipertiroidismo',
        'toma_medicacao', 'medicacao', 'tempo_medicacao', 'usa_suplemento_oral', 'suplemento_oral', 'tem_antecedentes_oncologicos',
        'antecedentes_oncologicos', 'tem_diabetes', 'fez_cirurgia_plastica_estetica', 'cirurgia_plastica_estetica', 'queixa_alopecia',
        'alopecia_acomete_corpo', 'partes_acometidas', 'tempo_disfuncao', 'estado_disfuncao', 'experiencia', 'assinatura', 'assinatura_paciente',
        'data_assinatura_paciente', 'nome_profissional', 'data_assinatura_profissional'
    );

    // Verifica se todos os campos estão presentes
    foreach ($expected_fields as $field) {
        if (!isset($_POST[$field])) {
            die("Dados incompletos. Campo não encontrado: $field");
        }
    }

    // Recupera os dados do formulário
    $id = $_POST['id'];
    $nome_completo = $_POST['nome_completo'];
    $data_nascimento = $_POST['data_nascimento'];
    $idade = $_POST['idade'];
    $endereco = $_POST['endereco'];
    $cep = $_POST['cep'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $telefone_residencial = $_POST['telefone_residencial'];
    $telefone_comercial = $_POST['telefone_comercial'];
    $celular = $_POST['celular'];
    $escolaridade = $_POST['escolaridade'];
    $escolaridade_completa = $_POST['escolaridade_completa'];
    $profissao = $_POST['profissao'];
    $estado_civil = $_POST['estado_civil'];
    $exposicao_ao_sol = $_POST['exposicao_ao_sol'];
    $filtro_solar = $_POST['filtro_solar'];
    $frequencia_filtro_solar = $_POST['frequencia_filtro_solar'];
    $usa_chapeu = $_POST['usa_chapeu'];
    $usa_cosmeticos = $_POST['usa_cosmeticos'];
    $cosmeticos_capilares = $_POST['cosmeticos_capilares'];
    $usa_isotretinoina = $_POST['usa_isotretinoina'];
    $usa_fotossensibilizantes = $_POST['usa_fotossensibilizantes'];
    $fotossensibilizantes = $_POST['fotossensibilizantes'];
    $usa_lentes = $_POST['usa_lentes'];
    $tabagismo = $_POST['tabagismo'];
    $quantidade_cigarros = $_POST['quantidade_cigarros'];
    $ingere_bebida = $_POST['ingere_bebida'];
    $frequencia_bebida = $_POST['frequencia_bebida'];
    $qualidade_sono = $_POST['qualidade_sono'];
    $horas_sono = $_POST['horas_sono'];
    $ingestao_agua_dia = $_POST['ingestao_agua_dia'];
    $alimentacao = $_POST['alimentacao'];
    $faz_dieta = $_POST['faz_dieta'];
    $patologia_de_pele = $_POST['patologia_de_pele'];
    $patologia = $_POST['patologia'];
    $outra_patologia = $_POST['outra_patologia'];
    $faz_procedimento_estetico = $_POST['faz_procedimento_estetico'];
    $alteracoes_tireoide = $_POST['alteracoes_tireoide'];
    $hipotireoidismo = $_POST['hipotireoidismo'];
    $hipertiroidismo = $_POST['hipertiroidismo'];
    $toma_medicacao = $_POST['toma_medicacao'];
    $medicacao = $_POST['medicacao'];
    $tempo_medicacao = $_POST['tempo_medicacao'];
    $usa_suplemento_oral = $_POST['usa_suplemento_oral'];
    $suplemento_oral = $_POST['suplemento_oral'];
    $tem_antecedentes_oncologicos = $_POST['tem_antecedentes_oncologicos'];
    $antecedentes_oncologicos = $_POST['antecedentes_oncologicos'];
    $tem_diabetes = $_POST['tem_diabetes'];
    $fez_cirurgia_plastica_estetica = $_POST['fez_cirurgia_plastica_estetica'];
    $cirurgia_plastica_estetica = $_POST['cirurgia_plastica_estetica'];
    $queixa_alopecia = $_POST['queixa_alopecia'];
    $alopecia_acomete_corpo = $_POST['alopecia_acomete_corpo'];
    $partes_acometidas = $_POST['partes_acometidas'];
    $tempo_disfuncao = $_POST['tempo_disfuncao'];
    $estado_disfuncao = $_POST['estado_disfuncao'];
    $experiencia = $_POST['experiencia'];
    $assinatura = $_POST['assinatura'];
    $assinatura_paciente = $_POST['assinatura_paciente'];
    $data_assinatura_paciente = $_POST['data_assinatura_paciente'];
    $nome_profissional = $_POST['nome_profissional'];
    $data_assinatura_profissional = $_POST['data_assinatura_profissional'];

    // Prepara a instrução SQL para atualizar os dados no banco
    $sql = "UPDATE anamnese_facial SET 
                nome_completo = '$nome_completo', 
                data_nascimento = '$data_nascimento', 
                idade = '$idade', 
                endereco = '$endereco', 
                cep = '$cep', 
                bairro = '$bairro', 
                cidade = '$cidade', 
                estado = '$estado', 
                telefone_residencial = '$telefone_residencial', 
                telefone_comercial = '$telefone_comercial', 
                celular = '$celular', 
                escolaridade = '$escolaridade', 
                escolaridade_completa = '$escolaridade_completa', 
                profissao = '$profissao', 
                estado_civil = '$estado_civil', 
                exposicao_ao_sol = '$exposicao_ao_sol', 
                filtro_solar = '$filtro_solar', 
                frequencia_filtro_solar = '$frequencia_filtro_solar', 
                usa_chapeu = '$usa_chapeu', 
                usa_cosmeticos = '$usa_cosmeticos', 
                cosmeticos_capilares = '$cosmeticos_capilares', 
                usa_isotretinoina = '$usa_isotretinoina', 
                usa_fotossensibilizantes = '$usa_fotossensibilizantes', 
                fotossensibilizantes = '$fotossensibilizantes', 
                usa_lentes = '$usa_lentes', 
                tabagismo = '$tabagismo', 
                quantidade_cigarros = '$quantidade_cigarros', 
                ingere_bebida = '$ingere_bebida', 
                frequencia_bebida = '$frequencia_bebida', 
                qualidade_sono = '$qualidade_sono', 
                horas_sono = '$horas_sono', 
                ingestao_agua_dia = '$ingestao_agua_dia', 
                alimentacao = '$alimentacao', 
                faz_dieta = '$faz_dieta', 
                patologia_de_pele = '$patologia_de_pele', 
                patologia = '$patologia', 
                outra_patologia = '$outra_patologia', 
                faz_procedimento_estetico = '$faz_procedimento_estetico', 
                alteracoes_tireoide = '$alteracoes_tireoide', 
                hipotireoidismo = '$hipotireoidismo', 
                hipertiroidismo = '$hipertiroidismo', 
                toma_medicacao = '$toma_medicacao', 
                medicacao = '$medicacao', 
                tempo_medicacao = '$tempo_medicacao', 
                usa_suplemento_oral = '$usa_suplemento_oral', 
                suplemento_oral = '$suplemento_oral', 
                tem_antecedentes_oncologicos = '$tem_antecedentes_oncologicos', 
                antecedentes_oncologicos = '$antecedentes_oncologicos', 
                tem_diabetes = '$tem_diabetes', 
                fez_cirurgia_plastica_estetica = '$fez_cirurgia_plastica_estetica', 
                cirurgia_plastica_estetica = '$cirurgia_plastica_estetica', 
                queixa_alopecia = '$queixa_alopecia', 
                alopecia_acomete_corpo = '$alopecia_acomete_corpo', 
                partes_acometidas = '$partes_acometidas', 
                tempo_disfuncao = '$tempo_disfuncao', 
                estado_disfuncao = '$estado_disfuncao', 
                experiencia = '$experiencia', 
                assinatura = '$assinatura', 
                assinatura_paciente = '$assinatura_paciente', 
                data_assinatura_paciente = '$data_assinatura_paciente', 
                nome_profissional = '$nome_profissional', 
                data_assinatura_profissional = '$data_assinatura_profissional'
            WHERE id = '$id'";


    // Executa a atualização no banco de dados
    if ($conexao->query($sql) === TRUE) {
        // Redireciona para a página de listagem com uma mensagem de sucesso
        header("Location: listar.anamnese.facial.php?message=Registro atualizado com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar o registro: " . $conexao->error;
    }

    // Fecha a conexão
    $conexao->close();
} else {
    echo "Método de requisição inválido.";
}
?>
