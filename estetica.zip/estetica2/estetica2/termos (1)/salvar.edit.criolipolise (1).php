<?php
include_once('../conexao.php');

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recupera os dados do formulário
    $id = $_POST['id'] ?? null; // Usando null coalesce para evitar erro de chave não definida
    $nome = $_POST['nome'] ?? null;
    $telefone = $_POST['telefone'] ?? null;
    $cpf = $_POST['cpf'] ?? null;
    $email = $_POST['email'] ?? null;
    $tecnico = $_POST['tecnico'] ?? null;
    $data_envio = $_POST['data_envio'] ?? null;
    $assinatura_paciente = $_POST['assinatura_paciente'] ?? null;
    $assinatura_profissional = $_POST['assinatura_profissional'] ?? null;

    // Verifica se todos os campos necessários estão preenchidos
    if ($id && $nome && $telefone && $cpf && $email && $tecnico && $data_envio && $assinatura_paciente && $assinatura_profissional) {
        // Prepara a instrução SQL para atualizar os dados no banco
        $sql = "UPDATE termo_criolipolise SET 
                    nome = ?, 
                    telefone = ?, 
                    cpf = ?, 
                    email = ?, 
                    tecnico = ?, 
                    data_envio = ?, 
                    assinatura_paciente = ?, 
                    assinatura_profissional = ?
                WHERE id = ?";

        // Prepara a declaração
        if ($stmt = $conexao->prepare($sql)) {
            // Vincula as variáveis à instrução preparada como parâmetros
            $stmt->bind_param('ssssssssi', $nome, $telefone, $cpf, $email, $tecnico, $data_envio, $assinatura_paciente, $assinatura_profissional, $id);

            // Tenta executar a declaração preparada
            if ($stmt->execute()) {
                // Redireciona para a página de listagem com uma mensagem de sucesso
                header("Location: listar.criolipolise.php?message=Registro atualizado com sucesso");
                exit;
            } else {
                echo "Erro ao atualizar o registro: " . $stmt->error;
            }

            // Fecha a declaração
            $stmt->close();
        } else {
            echo "Erro na preparação da declaração: " . $conexao->error;
        }
    } else {
        echo "Erro: Todos os campos são obrigatórios.";
    }

    // Fecha a conexão
    $conexao->close();
} else {
    echo "Método de requisição inválido.";
}
?>
