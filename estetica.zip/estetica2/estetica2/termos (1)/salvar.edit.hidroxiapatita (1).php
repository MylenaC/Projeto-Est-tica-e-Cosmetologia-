<?php
include_once('../conexao.php');

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recupera os dados do formulário
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $alergia = $_POST['alergia'];
    $objetivo = $_POST['objetivo'];
    $descricao = $_POST['descricao'];
    $tempo = $_POST['tempo'];
    $data_envio = $_POST['data_envio'];
    $assinatura_paciente = $_POST['assinatura_paciente'];
    $assinatura_profissional = $_POST['assinatura_profissional'];

    // Prepara a instrução SQL para atualizar os dados no banco
    $sql = "UPDATE termo_hidroxiapatita SET 
                nome = ?, 
                telefone = ?, 
                cpf = ?, 
                email = ?, 
                alergia = ?, 
                objetivo = ?, 
                descricao = ?, 
                tempo = ?, 
                data_envio = ?, 
                assinatura_paciente = ?, 
                assinatura_profissional = ?
            WHERE id = ?";

    // Prepara a declaração
    if ($stmt = $conexao->prepare($sql)) {
        // Vincula as variáveis à instrução preparada como parâmetros
        $stmt->bind_param('sssssssssssi', $nome, $telefone, $cpf, $email, $alergia, $objetivo, $descricao, $tempo, $data_envio, $assinatura_paciente, $assinatura_profissional, $id);

        // Tenta executar a declaração preparada
        if ($stmt->execute()) {
            // Redireciona para a página de listagem com uma mensagem de sucesso
            header("Location: listar.hidroxiapatita.php?message=Registro atualizado com sucesso");
        } else {
            echo "Erro ao atualizar o registro: " . $stmt->error;
        }

        // Fecha a declaração
        $stmt->close();
    } else {
        echo "Erro na preparação da declaração: " . $conexao->error;
    }

    // Fecha a conexão
    $conexao->close();
} else {
    echo "Método de requisição inválido.";
}
?>
