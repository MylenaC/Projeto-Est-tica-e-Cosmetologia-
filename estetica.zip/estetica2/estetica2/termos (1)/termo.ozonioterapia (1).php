    <?php

    include("../conexao.php");

    $nome = isset($_POST['nome']) ? $_POST['nome'] : "";
    $telefone = isset($_POST['telefone']) ? $_POST['telefone'] : "";
    $cpf = isset($_POST['cpf']) ? $_POST['cpf'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $alergia = isset($_POST['alergia']) ? $_POST['alergia'] : "";
    $objetivo = isset($_POST['objetivo']) ? $_POST['objetivo'] : "";
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : "";
    $tempo = isset($_POST['tempo']) ? $_POST['tempo'] : "";
    $data_envio = isset($_POST['data_envio']) ? $_POST['data_envio'] : "";
    $assinatura_paciente = isset($_POST['assinatura_paciente']) ? $_POST['assinatura_paciente'] : "";
    $assinatura_profissional = $_POST['assinatura_profissional'];

    $sql = "INSERT INTO termo_ozonioterapia( nome, telefone, cpf, email, alergia, objetivo, descricao, tempo, data_envio,
        assinatura_paciente, assinatura_profissional) 

        VALUES ( '$nome', '$telefone', '$cpf', '$email', '$alergia', '$objetivo', '$descricao', '$tempo', 
        '$data_envio', '$assinatura_paciente', '$assinatura_profissional')";

    if(mysqli_query($conexao, $sql)){

        header('Location: listar.ozonioterapia.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    } else {
    echo "Erro ao inserir dados: " . $conn->error;

    }

    mysqli_close($conexao);

    ?>