<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM termo_plasma WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {



            $id = $user_data['id'];
            $nome = $user_data['nome'];
            $telefone = $user_data['telefone'];
            $cpf = $user_data['cpf'];
            $email = $user_data['email'];
            $alergia = $user_data['alergia'];
            $objetivo = $user_data['objetivo'];
            $descricao = $user_data['descricao'];
            $tempo = $user_data['tempo'];
            $data_envio = $user_data['data_envio'];
            $assinatura_paciente = $user_data['assinatura_paciente'];
            $assinatura_profissional = $user_data['assinatura_profissional'];


        }

    } 
    
    else {
        header('Location: listar.plasma.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Termos.css">
    <title>Termo de Plasma</title>

    <style>
        .botao-registro {
           position: relative;
           top: 10px;
           right: 15px;
           left: 15px;
           background-color: rgb(11, 87, 1);
           color: #ffffff;
           border: none;
           padding: 10px 20px;
           font-size: 16px;
           cursor: pointer;
           border-radius: 5px;
           transition: background-color 0.3s ease;
        }
        </style>

</head>
<body>

    <a href="../pagina_inicial/termos.html">
    <button class="botao-estilizado">Voltar</button>
    </a>
    
    <a href="./listar.plasma.php">
        <button class="botao-registro">Termos</button>
     </a>

    <div class="container">
        <form action="salvar.edit.plasma.php" method="post" class="consent-form">
            <h2>Termo de Consentimento para Plasma Rico em Plaquetas</h2>

            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <label for="nome">Nome Completo:</label>
            <input type="text" id="nome" name="nome" class="inputUser" value="<?php echo $nome  ?>" required>

            <label for="nome">Telefone:</label>
            <input type="tel" id="Telefone" name="telefone" class="inputUser" value="<?php echo $telefone  ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" class="inputUser" value="<?php echo $cpf  ?>" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" class="inputUser" value="<?php echo $email  ?>" required>

            <div class="texto">

            <h3>Descrição e Indicações do Procedimento:</h3>
            O plasma rico em plaquetas (PRP) é uma suspensão de plasma obtida a partir do sangue total, 
            preparada de forma a conter concentrações de plaquetas superiores às encontradas normalmente 
            no sangue circulante. As plaquetas quando liberadas das células, estimulam reparo e regeneração 
            dos tecidos. É um procedimento estético minimamente invasivo e suas aplicações podem ser 
            realizadas tanto facial quanto corporal, sendo um tratamento muito eficaz para flacidez. Os 
            resultados podem sem sentidos a partir de 30 a 60 dias após a aplicação.
            
            <br></br>
            <h3>Contra-Indicações, Reações Adversas e Precauções:</h3>
            Mesmo com objetivos estéticos, plasma rico em plaquetas é um procedimento minimamente invasivo e 
            como tal, tem indicações e contraindicações que me foram apresentadas e verificadas pelo 
            profissional, em consulta prévia, na qual declaro não ter omitido nenhuma informação sobre meu 
            estado de saúde, doenças prévias, cicatrização hipertrófica, gravidez, amamentação, idade, 
            cirurgias anteriores, uso de medicações (AAS, ibuprofeno, outros anti-inflamatórios e medicações 
            que comprometam a coagulação sanguínea), epilepsia, implantes ou próteses, portador de hepatites B,
            C ou HIV, realização de outros tratamentos e alergias.
            <br></br>
            Sou alérgico a:<input type="text" name ="alergia" id="alergia" class="inputUser" value="<?php echo $alergia  ?>">
            Declaro não estar grávida ou amamentando.
            O tratamento é passível de reações adversas como dor no local de aplicação, hematoma, inchaço, 
            vermelhidão ou edema.
            Após aplicação ou enquanto houver hematomas, a exposição da região ao sol poderá manchar a pele, 
            como ocorre com qualquer hematoma quando exposto ao sol. Portanto é necessário aplicar filtro 
            solar FPS 30 de 3 em 3 horas, enquanto houver hematomas. A exposição da área ao calor ou a pressão 
            pontual podem interferir nas características e distribuição do produto recém-aplicado. Compreendo 
            que essas ocorrências são de minha responsabilidade.
            Caso esteja em tratamento (ou fazendo uso de medicações) para descraseias sanguíneas (anemias, 
            coagulopatias, etc) ou uso frequente de AAS (ácido acetil salicílico) e inflamação nos locais de 
            aplicação não devem ser submetidos à aplicação do produto.
            

           <br></br>

           <h3>Cuidados pós aplicação:</h3>
           Recomenda-se ao paciente não tomar sol durante os 7 primeiros dias após a aplicação, principalmente 
           se houver hematoma ou equimose. Pode-se notar o aparecimento de um pequeno halo de vermelhidão, 
           inchaço, coceira ao redor dos pontos de aplicação logo após a realização do procedimento, que é uma 
           reação do organismo decorrente do trauma de qualquer injeção, que regride nas primeiras horas ou 
           poucos dias, sem necessidade de tratamento específico. Ao persistirem os sintomas ou qualquer 
           anormalidade, o profissional deverá ser consultado.

            <br></br>

            <h3>Plano de Tratamento Proposto e Responsabilidades</h3>
            A elaboração do plano de tratamento depende de e varia com os objetivos e características 
            individuais de cada paciente. Faz parte do plano de tratamento como um todo, que o paciente 
            compareça às sessões, siga as orientações médicas e as precauções acima descritas. Sendo assim, 
            compreendo que cada tratamento é único, os resultados variam de paciente para paciente e não me 
            podem ser dadas promessas de resultados, principalmente porque eles dependerão também do paciente.
            <br></br> 
            -Objetivo do tratamento:<input type="text" name = "objetivo" id="objetivo" class="inputUser" value="<?php echo $objetivo  ?>">
            <br></br>
            -Descrição do plano de tratamento:<input type="text" name = "descricao" id="descricao" class="inputUser" value="<?php echo $descricao  ?>">
            <br></br>
            -Tempo estimado do tratamento:<input type="text" name = "tempo" id="tempo" class="inputUser" value="<?php echo $tempo  ?>">

            <br></br>

            <h3>Registros, Uso de Imagens e Consentimento Geral</h3>
            Autorizo o registro das minhas fotos de antes e depois dos procedimentos, pois compreendo que 
            isto representa uma fonte de esclarecimento dos resultados alcançados, tanto para o profissional 
            quanto para mim. As fotos poderão ser enviadas ao cliente via e-mail ao término do tratamento, 
            ficando também arquivadas em seu prontuário. De forma a preservar minha identidade, autorizo expor
            meus resultados de forma pontual e profissional. Compreendo todos os riscos do tratamento e
            aceito os custos e responsabilidades que envolvem e que me foram previamente apresentados. 
            Tive a oportunidade de esclarecer minhas dúvidas relativas ao procedimento que voluntariamente
            irei me submeter, tendo lido, compreendido e consentido as informações contidas neste documento
            antes da sua assinatura. Assim, não restando dúvidas, eu autorizo a realização dos 
            procedimentos propostos neste termo.

            </div>



            <label for="aceito">Eu aceito os termos e condições</label>
        </div>    
        <center>
            <label>Data</label>
            <input type="date" name="data_envio" id="data_envio" class="inputUser" value="<?php echo $data_envio  ?>">
            <br></br>
            <label>Assinatura do paciente ou responsável legal por escrito</label>
            <input type="text" name="assinatura_paciente" id="assinatura_paciente" class="inputUser" value="<?php echo $assinatura_paciente  ?>">

            </center>
        </div>
            
    
            
        <div class="form-group">
    
            <center>
            <label>Nome e Assinatura do Profissional</label>
            <input type="text" name="assinatura_profissional" id="assinatura_profissional" class="inputUser" value="<?php echo $assinatura_profissional  ?>">
            <br></br>
            
    
        </center>
        </div>



        <center>
            <button class="meu-botao">Enviar</button>
            </center>
        </form>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

        <script>
             $('#Telefone').mask('(00) 00000-0000');
             $('#cpf').mask('000.000.000-00', {reverse: true});
             $('#date_time').mask('00/00/0000 00:00:00');
        </script>

</body>
</html>

