<?php

if (!empty($_GET['id'])) 
{
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM termo_pelling WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {



            $id = $user_data['id'];
            $nome = $user_data['nome'];
            $telefone = $user_data['telefone'];
            $cpf = $user_data['cpf'];
            $email = $user_data['email'];
            $declaro = $user_data['declaro'];
            $nome_segundario = $user_data['nome_segundario'];
            $ativo = $user_data['ativo'];
            $data_envio = $user_data['data_envio'];
            $assinatura_paciente = $user_data['assinatura_paciente'];
            $assinatura_profissional = $user_data['assinatura_profissional'];


        }

    } 
    
    else {
        header('Location: listar.pelling.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Termos.css">
    <title>Termo de Pelling</title>

    <style>
        .botao-registro {
           position: relative;
           top: 10px;
           right: 15px;
           left: 15px;
           background-color: rgb(11, 87, 1);
           color: #ffffff;
           border: none;
           padding: 10px 20px;
           font-size: 16px;
           cursor: pointer;
           border-radius: 5px;
           transition: background-color 0.3s ease;
        }
        </style>

</head>
<body>

    <a href="../pagina_inicial/termos.html">
    <button class="botao-estilizado">Voltar</button>
    </a>

    <a href="./listar.pelling.php">
        <button class="botao-registro">Termos</button>
     </a>
    
    <div class="container">
        <form action="salvar.edit.pelling.php" method="post" class="consent-form">
            <h2>Termo de Consentimento para realização de Pelling</h2>

            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <label>Nome Completo:</label>
            <input required type="text" name="nome" id="nome" class="inputUser" value="<?php echo $nome  ?>">  

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" class="inputUser" value="<?php echo isset($telefone) ? $telefone : ''; ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" class="inputUser" value="<?php echo isset($cpf) ? $cpf : ''; ?>" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" class="inputUser" value="<?php echo isset($email) ? $email : ''; ?>" required>


            <div class="texto">

            Declaro que <input type="text" name="declaro" id="declaro" class="inputUser" value="<?php echo $declaro ?>">explicou-me a descrição da técnica de aplicação do 
            peeling. Estou ciente e concordo em receber o tratamento, me comprometendo a realizar as seguintes
            atitudes durante o programa terapêutico:
            <br></br>
            - Não secar o rosto com a toalha ou bucha vegetal de forma agressiva;          
            <br></br>
            - Em caso de possuir rinite alérgica, evitar coçar o nariz vigorosamente;
            <br></br>
            - Não utilizar pasta de dente em excesso, para que não entre em contato com a área próxima a boca;
            <br></br>
            - Não realizar o peeling caso tenha feito depilação do buço em um tempo inferior a uma semana;
            <br></br>
            - Evitar lavar o rosto com muita freqüência;
            <br></br>
            - Não utilizar perfumes sobre a área tratada nem produtos que contenham ácido;
            <br></br>
            - Evitar a exposição ao sol e usar filtro solar com fator de proteção acima de 30, para evitar 
            manchas causadas pelos raios UV;
            <br></br>
            - Reaplicar o filtro solar com FPS acima de 30 a cada duas horas ou sempre que necessário;
            <br></br>
            - É aconselhável a manutenção do tratamento em casa, que consiste em higienizar a pele com loção 
            de limpeza, com tônico facial e hidratação. Produtos específicos para cada tipo de pele será 
            recomendado pelo profissional habilitado.
            <br></br>
            - Em casos de pele acneica, você tem que estar ciente que para o melhor resultado, deve seguir 
            as orientações passadas pelo profissional, no que diz respeito a hábitos alimentares e condutas 
            de cuidados diários.
            <br></br>            
            - Em se tratando de peelings (seja químicos, enzimáticos, orgânicos ou mecânicos) e clareamento 
            de pele, evite completamente se expor ao sol durante todo o tratamento, para não ocasionar manchas
            na pele devido à radiação ultravioleta.
            <br></br>
            - Declaro e confirmo mais uma vez que entendi todas as explicações que me foram fornecidas, 
            de forma clara e simples, inclusive permitindo que eu realizasse todas as perguntas e fizesse 
            todas as observações que achei pertinente para entender o que ocorrerá comigo neste procedimento, 
            não ficando dúvidas sobre a qual serei submetido (a).
            <br></br>
            - O grau do resultado do tratamento não pode ser previsto ou garantido pelo profissional.
            <br></br>            
            Eu,<input type="text" name="nome_segundario" id="nome_segundario" class="inputUser" value="<?php echo $nome_segundario ?>"> estou ciente de que para realizar o procedimento Peeling 
            NÃO DEVO apresentar as seguintes manifestações no local a ser tratado:
            <br></br>            
            - Herpes ou Ferimentos;
            <br></br>            
            - Perda de sensibilidade;
            <br></br>            
            - Quelóides (nem devo ter tendência a este tipo de cicatrização patológica);
            <br></br>            
            - Qualquer tipo de queimadura (por agentes físicos, químicos ou queimaduras causadas pelo sol).
            <br></br>            
            
            Além disso, estou ciente que devo seguir as seguintes orientações:
            <br></br>            
            - Usarei o seguinte ativo (<input type="text" name="ativo" id="ativo" class="inputUser" value="<?php echo $ativo ?>"> ) e informo que não tenho alergia a tal 
            produto;
            <br></br>            
            - Estou ciente que este procedimento não pode ser realizado em regiões de mucosas e área genital;
            <br></br>            
            - Devo permanecer por 20 dias sem me bronzear antes do procedimento;
            <br></br>            
            - Afirmo que não estou fazendo uso de antiinflamatórios, corticosteróides, antibióticos ou 
            Roacutan® (Isotretinoína);
            <br></br>            
            - Afirmo que não realizei peeling de diamante, cristal ou laser quinze dias antes deste 
            procedimento;
            <br></br>            
            - Não estou em pós-operatório imediato ou tardio da região na qual será realizado o procedimento.
            <br></br>            
            - Não fumo e se fumo, estou cerca de vinte dias em abstinência do cigarro, pois compreendo que a 
            nicotina prejudica os resultados do meu tratamento.
            <br></br>            

            
            </div>


            <label for="aceito">Eu aceito os termos e condições</label>

        </div>

    </div>    
    <center>
            <label>Data</label>
            <input type="date" name="data_envio" id="data_envio" class="inputUser" value="<?php echo $data_envio ?>">
            <br></br>
            <label>Assinatura do paciente ou responsável legal por escrito</label>
            <input type="text" name="assinatura_paciente" id="assinatura_paciente" class="inputUser" value="<?php echo $assinatura_paciente ?>">
            

            </center>
        </div>
            
    
        <div class="form-group">
    
            <center>
            <label>Nome e Assinatura do Profissional</label>
            <input type="text" name="assinatura_profissional" id="assinatura_profissional" class="inputUser" value="<?php echo $assinatura_profissional ?>">
            <br></br>
            
    
        </center>
        </div>


        <center>
            <button class="meu-botao" id="btn-enviar">Enviar</button>
        </center>

        </form>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

        <script>
             $('#Telefone').mask('(00) 00000-0000');
             $('#cpf').mask('000.000.000-00', {reverse: true});
             $('#date_time').mask('00/00/0000 00:00:00');
        </script>

</body>
</html>
