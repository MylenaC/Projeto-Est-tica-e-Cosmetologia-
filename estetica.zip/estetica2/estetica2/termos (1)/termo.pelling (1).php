<?php

include("../conexao.php");

$nome = isset($_POST['nome']) ? $_POST['nome'] : "";
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : "";
$cpf = isset($_POST['cpf']) ? $_POST['cpf'] : "";
$email = isset($_POST['email']) ? $_POST['email'] : "";
$declaro = isset($_POST['declaro']) ? $_POST['declaro'] : "";
$nome_segundario = isset($_POST['nome_segundario']) ? $_POST['nome_segundario'] : "";
$ativo = isset($_POST['ativo']) ? $_POST['ativo'] : "";
$data_envio = $_POST['data_envio'];
$assinatura_paciente = $_POST['assinatura_paciente'];
$assinatura_profissional = $_POST['assinatura_profissional'];

$sql = "INSERT INTO termo_pelling( nome, telefone, cpf, email, declaro, nome_segundario, ativo, data_envio,
    assinatura_paciente, assinatura_profissional) 

    VALUES ( '$nome', '$telefone', '$cpf', '$email', '$declaro', '$nome_segundario', '$ativo', 
    '$data_envio', '$assinatura_paciente', '$assinatura_profissional')";
    

if(mysqli_query($conexao, $sql)){

    header('Location: listar.pelling.php');
    exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
} else {
echo "Erro ao inserir dados: " . $conn->error;

}
mysqli_close($conexao);

?>
