<?php
if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlDelete = "DELETE FROM termo_pelling WHERE id=$id";
    $resultadoDelete = $conexao->query($sqlDelete);

    if ($resultadoDelete) {
        // A exclusão foi bem-sucedida
        header('Location: listar.pelling.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    } else {
        // Ocorreu um erro na exclusão
        echo "Erro ao excluir o registro: " . $conexao->error;
    }
} else {
    // Não foi fornecido um ID válido para exclusão
    echo "ID não fornecido para exclusão.";
}
?>
