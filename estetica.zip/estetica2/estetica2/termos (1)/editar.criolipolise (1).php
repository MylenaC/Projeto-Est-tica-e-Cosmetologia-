<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM termo_criolipolise WHERE id=$id";

    $result = $conexao->query($sqlSelect);
    

    if ($result->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($result)) 
        {
            $nome = $user_data['nome'];
            $telefone = $user_data['telefone'];
            $cpf = $user_data['cpf'];
            $email = $user_data['email'];
            $tecnico = $user_data['tecnico'];
            $data_envio = $user_data['data_envio'];
            $assinatura_paciente = $user_data['assinatura_paciente'];
            $assinatura_profissional = $user_data['assinatura_profissional'];

    }

    } 
    
    else {
        header('Location: listar.criolipolise');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Termos.css">
    <title>Termo de Consentimento</title>

    <style>
        .botao-registro {
           position: relative;
           top: 10px;
           right: 15px;
           left: 15px;
           background-color: rgb(11, 87, 1);
           color: #ffffff;
           border: none;
           padding: 10px 20px;
           font-size: 16px;
           cursor: pointer;
           border-radius: 5px;
           transition: background-color 0.3s ease;
        }
        </style>

</head>
<body>

    <a href="../pagina_inicial/termos.html">
    <button class="botao-estilizado">Voltar</button>
    </a>

    <a href="listar.criolipolise.php">
        <button class="botao-registro">Termos</button>
     </a>

    <div class="container">
     <form action="salvar.edit.criolipolise.php" method="POST" class="consent-form">
            <h2>Termo de Consentimento Criolipólise</h2>

            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <label>Nome Completo:</label>
            <input required type="text" name="nome" id="nome" class="inputUser" value="<?php echo $nome  ?>">  

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" class="inputUser" value="<?php echo isset($telefone) ? $telefone : ''; ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" class="inputUser" value="<?php echo isset($cpf) ? $cpf : ''; ?>" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" class="inputUser" value="<?php echo isset($email) ? $email : ''; ?>" required>

            <div class="texto">

            Eu, abaixo identificado(a) e firmado(a), declaro ter sido informado(a) claramente e 
            estar ciente sobre os benefícios, riscos, indicações, contraindicações, principais efeitos 
            colaterais e advertências gerais, relacionados ao tratamento estético de CRIOLIPÓLISE, 
            um procedimento estético não invasivo onde um equipamento atua no tecido subcutâneo e promove 
            apoptose dos adipócitos, através do resfriamento. Este tratamento, tem o potencial de promover 
            resposta fisiológica á fim de melhorar as disfunções estéticas de gordura localizada e celulite 
            no tecido e região alvo do tratamento.

            <br></br>

            Os termos técnicos foram explicados e todas as minhas dúvidas foram esclarecidas por 
            Dr.<input type="text" name="tecnico" id="tecnico" class="inputUser" value="<?php echo $tecnico ?>">, que é o profissional que 
            conduzirá todo o tratamento estético. Comprometo-me a seguir todas as orientações profissionais 
            á cerca deste procedimento, o qual me explicou todos os cuidados para o sucesso e evitar 
            complicações. Entendi que este procedimento é contraindicado em gestantes e lactantes e ressalto 
            que no momento do tratamento, não possuo marcapasso cardíaco, não tenho implante de metal no local
             de tratamento, não estou em tratamento médico, não estou em uso de ácidos, isotretinoína, 
             roacutan ou qualquer outra substância de uso oral ou tópico, e nunca apresentei quadros alérgicos.
            Não apresento histórico de insuficiência respiratória, hemoglobinúria paroxística ao frio, doenças 
            auto-imune, câncer em metástases, sensibilidade ao frio, ou outras doenças ou infecções de pele.
            Entendo que em caso de alergias ou outra complicação inesperada, o profissional dará assistência
            necessária, e por entender que ações alergênicas inesperadas podem ocorrer, fica o profissional
            isento neste ato estético de qualquer culpa. 

            <br></br>

            Concordo espontaneamente em submeter-me ao referido tratamento, assumindo a responsabilidade e os 
            riscos pelos eventuais efeitos indesejáveis decorrentes do procedimento, de indisciplina ou omissão
            de intolerância particular de minha pele às substâncias contidas nos produtos e que neste momento 
            me foram informadas tais como: Queimaduras, hiperpigmentação pós inflamatória, neste caso o 
            profissional me dará suporte para um tratamento tópico. Entendi que a duração dos resultados dos 
            procedimentos é variável, dependendo do metabolismo e hábitos de cada paciente. Entendi que para 
            se alcançar os objetivos destes  tratamento se faz necessário associação de uma rotina de vida 
            audável com uma alimentação balanceada e a prática de atividades físicas.

            <br></br>

            O tratamento é passível de reações adversas imediatas ou tardias, que são previstas e que foram 
            me informadas no momento da consulta tais como: Ardor no momento da aplicação, surgimento de edema,
             eritema, hematoma e coceira, que são reações transitórias. Comprometo-me em reportar ao profissional
            qualquer reação não prevista que ocorra na área tradada durante o tratamento.  Estou ciente de que a 
            prática na área da saúde não é uma ciência exata e reconheço que, apesar de o profissional haver me 
            informado adequadamente sobre as possibilidades de atingir os objetivos do procedimento, não se pode 
            afirmar que os resultados são garantidos. 

            <br></br>

            Entendo que em caso de desistência deste tratamento, poderei optar por outro procedimento, 
            sem qualquer ônus ao profissional e clínica e que este termo de consentimento faz parte do 
            contrato de prestação de serviços estéticos.  Dou o meu consentimento para ser fotografado ou 
            filmado antes, durante e depois do procedimento, autorizando o profissional a utilizar minha
            imagem pessoal de forma gratuita.

            <br></br>

            </div>



            <label for="aceito">Eu aceito os termos e condições</label>

        </div>    
        <center>
            <label>Data</label>
            <input type="date" name="data_envio" id="data_envio" class="inputUser" value="<?php echo $data_envio ?>">
            <br></br>
            <label>Assinatura do paciente ou responsável legal por escrito</label>
            <input type="text" name="assinatura_paciente" id="assinatura_paciente" class="inputUser" value="<?php echo $assinatura_paciente ?>">
            

            </center>
        </div>
            
    
        <div class="form-group">
    
            <center>
            <label>Nome e Assinatura do Profissional</label>
            <input type="text" name="assinatura_profissional" id="assinatura_profissional" class="inputUser" value="<?php echo $assinatura_profissional ?>">
            <br></br>
            
    
        </center>
        </div>



        <center>
            <button class="meu-botao" id="btn-enviar">Enviar</button>
        </center>
    </form>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

    <script>
         $('#Telefone').mask('(00) 00000-0000');
         $('#cpf').mask('000.000.000-00', {reverse: true});
         $('#date_time').mask('00/00/0000 00:00:00');
    </script>
</body>
</html>
