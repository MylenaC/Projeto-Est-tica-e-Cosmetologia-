<?php
    include("conexao.php");

    $email = $_POST['email'];
    $senha = $_POST['password'];

    $sql = "SELECT * FROM login WHERE email = '$email'";

    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        // Verificar se o usuario existe no banco de dados
        if (mysqli_num_rows($resultado) > 0) {
            $linha = mysqli_fetch_assoc($resultado);
            
            // Verificar se a senha fornecida está correta
            if ($senha === $linha["senha"]) {
                header("Location: pagina_inicial/Inicio.html");
                exit();
            } else {
                echo 'Senha incorreta';
            }
        } else {
            echo 'Usuário não encontrado';
        }
    } else {
        echo 'Erro de conexão/query.';
    }

    mysqli_close($conexao);
?>