<?php

    include_once('../conexao.php');

    if (isset($_POST['update']))

    {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $material = $_POST['material'];
        $descricao = $_POST['descricao'];

        $sqlUpdate = "UPDATE aquisicao SET nome='$nome', email='$email', material='$material', descricao='$descricao'
        WHERE id='$id'";

        $resultado = $conexao->query($sqlUpdate);
    }

    header('Location:listar_aquisicao.php');


?>