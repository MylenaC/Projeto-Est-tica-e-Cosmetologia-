<?php
include_once('../conexao.php');

// Verificar se a conexão foi bem-sucedida
if ($conexao->connect_error) {
    die("Erro de Conexão: " . $conexao->connect_error);
}

$sql = "SELECT * FROM manutencao ORDER BY id ASC";

$resultado = $conexao->query($sql);

// Verificar se a consulta foi bem-sucedida
if (!$resultado) {
    die("Erro na Consulta: " . $conexao->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manutenção de Equipamentos</title>
    <link rel="stylesheet" href="../bootstrap-4.1.3-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        .table-bg {
            background:rgb(161, 233, 183);;
            border-radius: 15px 15px 0 0;
        }
    
        .botao-estilizado {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgb(11, 87, 1);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        h1 {
            margin-top: 5%;
            color: rgb(11, 87, 1);
        }

        table {
            margin-top: 10%;
        }

        .m-5 {
            position: relative;
        }

        /* Adicione algum estilo ao botão de filtro */
        #filtro-form {
            margin-bottom: 20px;
            width: 250px; /* Defina a largura desejada */
            padding: 8px; /* Adicione algum espaçamento interno para melhor aparência */
            box-sizing: border-box; /* Inclua padding e borda na largura total */
            margin-bottom: 10px; /* Adicione algum espaço abaixo do input */
        }

        /* Estilize o campo de entrada de filtro */
        #filtro-material {
            border-radius: 5px;
            padding: 5px 10px;
            font-size: 12px;
            height: 30px;
            width: -100px
        }

        /* Estilize o botão de filtro */
        .btn-filtrar {
            border-radius: 5px;
            font-size: 12px;
            height: 30px;
            background-color: rgb(11, 87, 1);
            color:#ffff;
        }

        .btn-filtrar i {
            margin-left: 5px;
        }

        .novo {
            position: absolute;
            top: 10%;
            left: 10px;
            background-color: rgb(11, 87, 1);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
    </style>
</head>
<body>

<center>
    <h1>Manutenção de Equipamentos</h1>
</center>

<a href="../pagina_inicial/Inicio.html">
    <button class="botao-estilizado">Voltar</button>
</a>

<div class="m-5">
    <!-- Adicione um formulário para filtrar -->
    <form id="filtro-form" action="" method="get">
        <div class="input-group mb-3">
            <input type="text" class="form-control" id="filtro-material" name="filtro-material" placeholder="Filtrar por:">
            <div class="input-group-append">
                <button type="submit" class="btn btn-filtrar">Filtrar <i class="fas fa-caret-down"></i></button>
            </div>
        </div>
    </form>

    <a href="./manutencao_equipamentos.html">
    <button class="novo">Novo registro</button>
    </a>

    <table class="table table-hover table-bg">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Modelo</th>
                <th scope="col">Solicitante</th>
                <th scope="col">Tipo</th>
                <th scope="col">Detalhes Produtos ou Serviços</th>
                <th scope="col">Problema Específico</th>
                <th scope="col">Histórico</th>
                <th scope="col">Rotina</th>
                <th scope="col">Ambiente</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>

  <?php
while ($user_data = $resultado->fetch_assoc()) {
  echo "<tr>";
  echo "<td>".$user_data['id']."</td>";
  echo "<td>".$user_data['modelo']."</td>";
  echo "<td>".$user_data['solicitante']."</td>";
  echo "<td>".$user_data['tipo']."</td>";
  echo "<td>".$user_data['detalhes_produtos']."</td>";
  echo "<td>".(isset($user_data['problema_especifico']) ? $user_data['problema_especifico'] : '')."</td>";
  echo "<td>".(isset($user_data['historico_problemas']) ? $user_data['historico_problemas'] : '')."</td>";
  echo "<td>".(isset($user_data['rotina_manutencao']) ? $user_data['rotina_manutencao'] : '')."</td>";
  echo "<td>".(isset($user_data['ambiente_operacao']) ? $user_data['ambiente_operacao'] : '')."</td>";
  echo "<td>
      <a class='btn btn-sm btn-primary' href='editar_manutencao.php?id=$user_data[id]'>
      <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-pencil' viewBox='0 0 16 16'>
      <path d='M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.
      65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.
      707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.
      106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z'/>
      </svg>
      </a>

      <a class='btn btn-sm btn-danger' href='delete_manutencao.php?id=$user_data[id]'>
      <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-trash3-fill' 
      viewBox='0 0 16 16'>
      <path d='M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 
      1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 
      11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 
      0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 
      0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5'/>
      </svg>
      </a>
      </td>";
  echo "</tr>";
}



  ?>

  </tbody>
</table>

  </div>
</body>
</html>
