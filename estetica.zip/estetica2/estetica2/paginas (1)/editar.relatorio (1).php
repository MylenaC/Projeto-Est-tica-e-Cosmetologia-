<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM relatorioatendimento WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {
        $dataAtendimento = isset($user_data['dataAtendimento']) ? $user_data['dataAtendimento'] : '';
$horaInicio = isset($_POST['horaInicio']) ? $_POST['horaInicio'] : '';
$horaTermino = isset($_POST['horaTermino']) ? $_POST['horaTermino'] : '';
$nomeCliente = isset($_POST['nomeCliente']) ? $_POST['nomeCliente'] : '';
$numeroCliente = isset($_POST['numeroCliente']) ? $_POST['numeroCliente'] : '';
$enderecoCliente = isset($_POST['enderecoCliente']) ? $_POST['enderecoCliente'] : '';
$telefoneCliente = isset($_POST['telefoneCliente']) ? $_POST['telefoneCliente'] : '';
$emailCliente = isset($_POST['emailCliente']) ? $_POST['emailCliente'] : '';
$tipoAtendimento = isset($_POST['tipoAtendimento']) ? $_POST['tipoAtendimento'] : '';
$nomeAtendente = isset($_POST['nomeAtendente']) ? $_POST['nomeAtendente'] : '';
$numeroProtocolo = isset($_POST['numeroProtocolo']) ? $_POST['numeroProtocolo'] : '';
$descricaoAtendimento = isset($_POST['descricaoAtendimento']) ? $_POST['descricaoAtendimento'] : '';
$acoesRealizadas = isset($_POST['acoesRealizadas']) ? $_POST['acoesRealizadas'] : '';
$recomendacoes = isset($_POST['recomendacoes']) ? $_POST['recomendacoes'] : '';
$observacoes = isset($_POST['observacoes']) ? $_POST['observacoes'] : '';
$conclusao = isset($_POST['conclusao']) ? $_POST['conclusao'] : '';

        }

    } 
    
    else {
        header('Location: listar_aquisicao.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estética e Cosmetologia </title>
    <link rel="stylesheet" href="../css/relatorio_atendimento.css">

    <style>
        .botao-registro {
           position: relative;
           top: 10px;
           right: 15px;
           left: 15px;
           background-color: rgb(11, 87, 1);
           color: #ffffff;
           border: none;
           padding: 10px 20px;
           font-size: 16px;
           cursor: pointer;
           border-radius: 5px;
           transition: background-color 0.3s ease;
        }
        </style>


</head>



<body>

    <style>
        .navbar {
    background-color: rgb(11, 87, 1); /* Cor de fundo da barra de navegação */
    overflow: hidden;
}


.navbar a {
    float: left; /* Alinhar os itens à esquerda */
    display: block; /* Fazer os itens ocuparem uma linha inteira */
    color: white; /* Cor do texto */
    text-align: center; /* Centralizar o texto */
    padding: 14px 16px; /* Espaçamento interno (topo/baixo, esquerda/direita) */
    text-decoration: none; /* Remover sublinhado dos links */
}

.navbar a:hover {
    background-color: #ddd; /* Cor de fundo quando passa o mouse por cima */
    color: black; /* Cor do texto quando passa o mouse por cima */
}

body {
    font-family: Arial, sans-serif;
}
.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}
h1 {
    text-align: center;
}
.info {
    margin-bottom: 20px;
}
.info label {
    font-weight: bold;
}
.info input {
    width: 100%;
    padding: 5px;
    margin-bottom: 10px;
}
.description, .actions, .recommendations, .observations, .conclusion {
    margin-bottom: 20px;
}
.description textarea, .actions textarea, .recommendations textarea, .observations textarea, .conclusion textarea {
    width: 100%;
    padding: 5px;
}
.signature {
    margin-top: 20px;
}
.signature input {
    width: 100%;
    padding: 5px;
}
.footer {
    text-align: center;
    margin-top: 20px;
    font-size: 12px;
}

.submit-button {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
}

.submit-button:hover {
    background-color: #0056b3;
}      

.botao-estilizado {
    position: absolute;
    top: 10px;
    right: 10px;
    background-color: rgb(11, 87, 1);
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}
    </style>

    <form action="../paginas/relatorio_atendimento.php" method="post">
        

        <a href="/estetica/pagina_inicial/Inicio.html">
            <button class="botao-estilizado">Voltar</button>
        </a>
    
        <a href="/estetica/paginas/listar.relatorio.php">
            <button class="botao-registro">Registro de Relatórios</button>
        </a>
    
        <div class="container">
            <h1>RELATÓRIO DE ATENDIMENTO</h1>
            
            <div class="info">
                <label for="dataAtendimento">Data do Atendimento:</label>
                <input type="date" id="dataAtendimento" name="dataAtendimento" class="inputUser" value="<?php echo isset($dataAtendimento) ? $dataAtendimento : ''; ?>" >
            </div>
            <div class="info">
                <label for="horaInicio">Hora de Início:</label>
                <input type="time" id="horaInicio" name="horaInicio" class="inputUser" value="<?php echo isset($horaInicio) ? $horaInicio : ''; ?>">
            </div>
            <div class="info">
                <label for="horaTermino">Hora de Término:</label>
                <input type="time" id="horaTermino" name="horaTermino" class="inputUser" value="<?php echo isset($horaTermino) ? $horaTermino : ''; ?>">
            </div>
            <h2>Informações do Cliente:</h2>
            <div class="info">
                <label for="nomeCliente">Nome do Cliente:</label>
                <input type="text" id="nomeCliente" name="nomeCliente" class="inputUser" value="<?php echo isset($nomeCliente) ? $dataAtendimento : ''; ?>">
            </div>
            <div class="info">
                <label for="numeroCliente">Número de Cliente:</label>
                <input type="number" id="numeroCliente" name="numeroCliente" class="inputUser" value="<?php echo isset($numeroCliente) ? $numeroCliente : ''; ?>">
            </div>
            <div class="info">
                <label for="enderecoCliente">Endereço:</label>
                <input type="text" id="enderecoCliente"  name="enderecoCliente" class="inputUser" value="<?php echo isset($enderecoCliente) ? $enderecoCliente : ''; ?>">
            </div>
            <div class="info">
                <label for="telefoneCliente">Telefone:</label>
                <input type="tel" id="telefoneCliente" name="telefoneCliente" class="inputUser" value="<?php echo isset($telefoneCliente) ? $telefoneCliente : ''; ?>">
            </div>
            <div class="info">
                <label for="emailCliente">E-mail:</label>
                <input type="email" id="emailCliente" name="emailCliente" class="inputUser" value="<?php echo isset($emailCliente) ? $emailCliente : ''; ?>">
            </div>
            <h2>Resumo do Atendimento:</h2>
            
            <div class="info">
                <label for="tipoAtendimento">Tipo de Atendimento:</label>
                <input type="text" id="tipoAtendimento" name="tipoAtendimento" class="inputUser" value="<?php echo isset($tipoAtendimento) ? $tipoAtendimento : ''; ?>">
            </div>
            <div class="info">
                <label for="nomeAtendente">Atendente:</label>
                <input type="text" id="nomeAtendente"  name="nomeAtendente" class="inputUser" value="<?php echo isset($nomeAtendente) ? $nomeAtendente : ''; ?>">
            </div>
            <div class="info">
                <label for="numeroProtocolo">Número de Protocolo:</label>
                <input type="number" id="numeroProtocolo" name="numeroProtocolo" class="inputUser" value="<?php echo isset($numeroProtocolo) ? $numeroProtocolo : ''; ?>">
            </div>
            <h2>Descrição do Atendimento:</h2>
            <div class="description">
                <textarea rows="4" id="descricaoAtendimento"  name="descricaoAtendimento" placeholder="Descreva detalhadamente o motivo do atendimento e quaisquer problemas ou preocupações apresentados pelo cliente."></textarea>
            </div>
            <h2>Ações Realizadas:</h2>
            <div class="actions">
                <textarea rows="4" id="acoesRealizadas"  name="acoesRealizadas" placeholder="Descreva as ações específicas realizadas durante o atendimento para resolver o problema ou atender às necessidades do cliente."></textarea>
            </div>
            <h2>Recomendações:</h2>
            <div class="recommendations">
                <textarea rows="4" id="recomendacoes" name="recomendacoes" placeholder="Se houver recomendações para o cliente, como ações a serem tomadas após o atendimento, mencione-as aqui."></textarea>
            </div>
            <h2>Observações Adicionais:</h2>
            <div class="observations">
                <textarea rows="4" id="observacoes" name="observacoes" placeholder="Aqui, você pode adicionar quaisquer observações ou notas relevantes sobre o atendimento."></textarea>
            </div>
            <h2>Conclusão:</h2>
            <div class="conclusion">
                <textarea rows="4" id="conclusao" name="conclusao" placeholder="Resuma a conclusão do atendimento e confirme se o cliente está satisfeito com as ações realizadas."></textarea>
            </div>
            <div class="footer">
                <p>Este relatório de atendimento é confidencial e destinado apenas para uso interno. Qualquer divulgação não autorizada é estritamente proibida.</p>
            </div>
            
                <button class="submit-button" type="submit">Enviar Informações</button>

            </form>
        </div>
        
    </body>
    </html>