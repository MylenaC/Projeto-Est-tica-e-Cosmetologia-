<?php
include('../conexao.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $modelo = $_POST["modelo"];
    $solicitante = $_POST["solicitante"];
    $tipo = $_POST["tipo"];
    $data_solicitacao = $_POST["data_solicitacao"];
    $detalhes_produtos = $_POST["detalhes_produtos"];
    $problema_especifico = $_POST["problema_especifico"];
    $historico_problemas = $_POST["historico_problemas"];
    $rotina_manutencao = $_POST["rotina_manutencao"];
    $ambiente_operacao = $_POST["ambiente_operacao"];

    $sql = "INSERT INTO manutencao (modelo, solicitante, tipo, data_solicitacao, detalhes_produtos,
    problema_especifico, historico_problemas, rotina_manutencao, ambiente_operacao) VALUES ('$modelo', '$solicitante', '$tipo', '$data_solicitacao', '$detalhes_produtos', '$problema_especifico', 
    '$historico_problemas', '$rotina_manutencao', '$ambiente_operacao')";

    if (!empty($sql)) {
        $resultado = mysqli_query($conexao, $sql);

        if ($resultado) {
            header('Location: listar_manutencao.php');
            exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento        } else {
            echo "Erro ao enviar a solicitação: " . mysqli_error($conexao) . " (Código: " . mysqli_errno($conexao) . ")";
        }
    }
}

    mysqli_close($conexao);
?>

