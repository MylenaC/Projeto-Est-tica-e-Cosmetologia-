<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    include('../conexao.php');

        $dataAtendimento= $_POST['dataAtendimento'];
        $horaInicio= $_POST['horaInicio'];
        $horaTermino= $_POST['horaTermino'];
        $nomeCliente= $_POST['nomeCliente'];
        $numeroCliente= $_POST['numeroCliente'];
        $enderecoCliente= $_POST['enderecoCliente'];
        $telefoneCliente= $_POST['telefoneCliente'];
        $emailCliente= $_POST['emailCliente'];
        $tipoAtendimento= $_POST['tipoAtendimento'];
        $nomeAtendente= $_POST['nomeAtendente'];
        $numeroProtocolo= $_POST['numeroProtocolo'];
        $descricaoAtendimento= $_POST['descricaoAtendimento'];
        $acoesRealizadas= $_POST['acoesRealizadas'];
        $recomendacoes= $_POST['recomendacoes'];
        $observacoes= $_POST['observacoes'];
        $conclusao= $_POST['conclusao'];

        
            $sql =  "INSERT INTO relatorioatendimento (
            dataAtendimento, horaInicio, horaTermino, nomeCliente, numeroCliente, enderecoCliente,
            telefoneCliente, emailCliente, tipoAtendimento, nomeAtendente, numeroProtocolo,descricaoAtendimento, acoesRealizadas, recomendacoes, observacoes, conclusao)
            VALUES ('$dataAtendimento','$horaInicio','$horaTermino','$nomeCliente','$numeroCliente','$enderecoCliente','$telefoneCliente',
            '$emailCliente','$tipoAtendimento','$nomeAtendente','$numeroProtocolo','$descricaoAtendimento','$acoesRealizadas','$recomendacoes','$observacoes','$conclusao')";

$result=mysqli_query ($conexao,$sql);
echo "Registro inserido com sucesso!";


    mysqli_close($conexao);
}


?>
