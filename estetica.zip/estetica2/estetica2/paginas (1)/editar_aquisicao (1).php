<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM aquisicao WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {
        $nome = isset($user_data['nome']) ? $user_data['nome'] : '';
        $email = isset($user_data['email']) ? $user_data['email'] : '';
        $material = isset($user_data['material']) ? $user_data['material'] : '';
        $descricao = isset($user_data['descricao']) ? $user_data['descricao'] : '';
        }

    } 
    
    else {
        header('Location: listar_aquisicao.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agendamento de Serviços</title>
<link rel="stylesheet" href="../css/Aquisicao.materiais.css">

<style>
   #submit {
      position: relative;
      top: 10px;
      right: 10px;
      background-color: rgb(11, 87, 1);
      color: #ffffff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s ease;
  }
</style>
</head>

<body>

 <a href="../paginas/listar_aquisicao.php">
 <button class="botao-estilizado">Voltar</button>
 </a>

<div class="container">
 <h1>Aquisição de materiais</h1>

 <p>Preencha o formulário abaixo para requisição de materiais para Clínica.</p>

 <form action="..\paginas\salvar_aquisicao.php" method="POST" >
 <div class="form-group">
 <label for="nome">Nome completo:</label>
 <input type="text" id="nome" name="nome" class="inputUser" value= "<?php echo $nome?>" required>
 </div>


 <div class="form-group">
      <label for="email">E-mail:</label>
 <input type="email" id="email" name="email" class="inputUser" value= "<?php echo $email?>" required>
 </div>

    <div class="form-group">
    <label for="material">Material desejado:</label>

    <select id="material" name="material" class="inputUser" required>
    <option value="<?php echo isset($material) ? $material : ''; ?>" selected><?php echo isset($material) ? $material : ''; ?></option>
    <option value="" disabled selected>Selecione o(s) materiais desejados.</option>
    <option value="agulha">Agulha</option>
    <option value="Mascara">Máscaras</option>
    <option value="Luvas">luvas</option>
    <option value="Outros">Outros</option>
    <!-- Adicione mais opções de serviços conforme necessário -->
    </select>

 </div>

 <div class="form-group">
 <label for="descricao">Descrição do pedido:</label>
 <textarea id="descricao" name="descricao" rows="4" class="inputUser"><?php echo isset($descricao) ? $descricao : ''; ?></textarea>
 </div>

 <input type="hidden" name="id" value="<?php echo $id?>">

 <center>
<input type="submit" name="update" id="submit" value="Enviar pedido">
</center>

 </form>

</div>

</body>
</html>
