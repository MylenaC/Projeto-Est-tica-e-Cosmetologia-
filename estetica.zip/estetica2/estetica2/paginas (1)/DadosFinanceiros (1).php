<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    include('../conexao.php');

        $id_financeiro= $_POST ['id_financeiro'];
        $data_financeiro= $_POST ['data_financeiro'] ;
        $descricao_financeira= $_POST ['descricao_financeira'];
        $valor_financeiro= $_POST ['valor_financeiro'];
        $conta_financeiro= $_POST ['conta_financeiro'];
        $categoriaFinanceiro= $_POST ['categoriaFinanceiro'];
        $TipoPagamento= $_POST ['TipoPagamento'];

        
            $sql =  "INSERT INTO Dados_financeiro (id_financeiro, data_financeiro, descricao_financeira, valor_financeiro, conta_financeiro, categoriaFinanceiro, TipoPagamento)
            VALUES ('$id_financeiro',' $data_financeiro', '$descricao_financeira','$valor_financeiro','$conta_financeiro','$categoriaFinanceiro','$TipoPagamento')";
            $result=mysqli_query ($conexao,$sql);
            
    mysqli_close($conexao);

}

?>
