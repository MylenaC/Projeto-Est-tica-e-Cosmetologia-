<?php

include_once('../conexao.php');

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $modelo = $_POST['modelo'];
    $solicitante = $_POST['solicitante'];
    $tipo = $_POST['tipo'];
    $data_solicitacao = $_POST['data_solicitacao'];
    $detalhes_produtos = $_POST['detalhes_produtos'];
    $problema_especifico = $_POST['problema_especifico'];
    $historico_problemas = $_POST['historico_problemas'];
    $rotina_manutencao = $_POST['rotina_manutencao'];
    $ambiente_operacao = $_POST['ambiente_operacao'];

    $sqlUpdate = "UPDATE manutencao SET modelo='$modelo', solicitante='$solicitante', tipo='$tipo', 
    data_solicitacao='$data_solicitacao', detalhes_produtos='$detalhes_produtos', 
    problema_especifico='$problema_especifico', historico_problemas='$historico_problemas', 
    rotina_manutencao='$rotina_manutencao', ambiente_operacao='$ambiente_operacao'
    WHERE id='$id'";

    $resultado = $conexao->query($sqlUpdate);

    if ($resultado) {
        echo "Registro atualizado com sucesso!";
        header('Location: listar_manutencao.php');
        exit();
    } else {
        echo "Erro ao atualizar o registro: " . $conexao->error;
    }
}
?>
