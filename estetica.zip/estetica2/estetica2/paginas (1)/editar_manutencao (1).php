<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM manutencao WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {
        $modelo = isset($user_data['modelo']) ? $user_data['modelo'] : '';
        $solicitante = isset($user_data['solicitante']) ? $user_data['solicitante'] : '';
        $tipo = isset($user_data['tipo']) ? $user_data['tipo'] : '';
        $data_solicitacao = isset($user_data['data_solicitacao']) ? $user_data['data_solicitacao'] : '';
        $detalhes_produtos = isset($user_data['detalhes_produtos']) ? $user_data['detalhes_produtos'] : '';
        $problema_especifico = isset($user_data['problema_especifico']) ? $user_data['problema_especifico'] : '';
        $historico_problemas = isset($user_data['historico_problemas']) ? $user_data['historico_problemas'] : '';
        $rotina_manutencao = isset($user_data['rotina_manutencao']) ? $user_data['rotina_manutencao'] : '';
        $ambiente_operacao = isset($user_data['ambiente_operacao']) ? $user_data['ambiente_operacao'] : '';


    
    
    }

    } 
    
    else {
        header('Location: editar_manutencao');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
    }
}
?>


<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Manutenção de Equipamentos</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Raleway:ital,wght@0,400;0,500;0,600;0,700;1,600&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="./img/logo_2.png">
    <link rel="stylesheet" href="../css/Manutencao.equipamentos.css">

    <style>
   #submit {
      position: relative;
      top: 10px;
      right: 10px;
      background-color: rgb(11, 87, 1);
      color: #ffffff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s ease;
  }
</style>

</head>
<body>
    <!--INICIO HEADER-->
    

    <header>
        <nav class="nav">

            <ul class="nav-list">
                <li><a href="#"> Manutenção de Equipamentos</a></li>
            </ul>
        </nav>
    </header>

    <!--FIM HEADER-->

    <!--INICIO MAIN-->

    <a href="../paginas/listar_manutencao.php">
        <button class="botao-estilizado">Voltar</button>
        </a>

    <section>
        <div class="container">

            <form action="..\paginas\salvar_manutencao.php" method="POST">
                <div class="user-details">

                    <div class="input-box">
                        <span class="details">Modelo</span>
                        <input type="text" id="modelo" name="modelo" class="inputUser" value="<?php echo isset($modelo) ? $modelo : ''; ?>" required>
                    </div>

                    <div class="input-box">
                        <span class="details">Solicitante</span>
                        <input type="text" id="solicitante" name="solicitante" class="inputUser" value="<?php echo isset($solicitante) ? $solicitante : ''; ?>">
                    </div>

                    <div class="input-box">
                        <span class="details">Tipo de solicitação</span>
                        <input type="text" id="tipo" name="tipo" class="inputUser" value="<?php echo isset($tipo) ? $tipo : ''; ?>">
                    </div>

                    <div class="input-box">
                        <span class="details">Data</span>
                        <input type="date" id="data_solicitacao" name="data_solicitacao" class="inputUser" value="<?php echo isset($data_solicitacao) ? $data_solicitacao : ''; ?>">
                    </div>
                </div>

                <div class="boddy">
                 <div class="wrapper">
                <h2>Detalhes do Produto ou Serviço</h2>
                <textarea id="detalhes_produtos" name="detalhes_produtos" class="inputUser" placeholder="Descrição detalhada dos bens ou serviços a serem adquiridos. Quantidade necessária. Especificações técnicas, se aplicável."><?php echo isset($detalhes_produtos) ? $detalhes_produtos : ''; ?></textarea>
               </div>
            </div>

                <div class="boddy">
                    <div class="wrapper">
                        <h2>Problema Específico</h2>
                        <textarea id="problema_especifico" name="problema_especifico" class="inputUser" placeholder="Descrição detalhada dos bens ou serviços a serem adquiridos. Quantidade necessária. Especificações técnicas, se aplicável."><?php echo isset($problema_especifico) ? $problema_especifico : ''; ?></textarea>
                    </div>
                </div>

                <div class="boddy">
                    <div class="wrapper">
                        <h2>Histórico de Problemas</h2>
                        <textarea id="historico_problemas" name="historico_problemas" class="inputUser" placeholder="Descrição detalhada dos bens ou serviços a serem adquiridos. Quantidade necessária. Especificações técnicas, se aplicável."><?php echo isset($historico_problemas) ? $historico_problemas : ''; ?></textarea>
                    </div>
                </div>

                <div class="boddy">
                    <div class="wrapper">
                        <h2>Rotina de Manutenção</h2>
                        <textarea id="rotina_manutencao" name="rotina_manutencao" class="inputUser" placeholder="Descrição detalhada dos bens ou serviços a serem adquiridos. Quantidade necessária. Especificações técnicas, se aplicável."><?php echo isset($rotina_manutencao) ? $rotina_manutencao : ''; ?></textarea>
                    </div>
                </div>

                <div class="boddy">
                    <div class="wrapper">
                        <h2>Ambiente de Operação</h2>
                        <textarea id="ambiente_operacao" name="ambiente_operacao" class="inputUser" placeholder="Descrição detalhada dos bens ou serviços a serem adquiridos. Quantidade necessária. Especificações técnicas, se aplicável."><?php echo isset($ambiente_operacao) ? $ambiente_operacao : ''; ?></textarea>
                    </div>
                </div>

                <input type="hidden" name="id" value="<?php echo isset($id) ? $id : ''; ?>">

                <center>
                <input type="submit" name="update" id="submit" value="Enviar">
                </center>
                </form>
        </div>
    </section>

    <!--FIM MAIN-->
</body>
</html>