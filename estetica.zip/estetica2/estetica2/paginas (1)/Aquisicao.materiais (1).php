<?php
    include("../conexao.php");
    
    $nome = isset($_POST['nome']) ? $_POST['nome'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $material = isset($_POST['material']) ? $_POST['material'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';

    $sql = "INSERT INTO aquisicao (nome, email, material, descricao) 
    
    VALUES ('$nome','$email', '$material', '$descricao')";

    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        // A exclusão foi bem-sucedida
        header('Location: listar_aquisicao.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
        
    } else {
        echo "Erro ao enviar a solicitação: " . mysqli_error($conexao) . " (Código: " . mysqli_errno($conexao) . ")";
    }

    mysqli_close($conexao);
?>
























