<?php

include_once('../conexao.php');

if (isset($_POST['update'])) {
    $contratante_nome = isset($_POST['contratante_nome']) ? $_POST['contratante_nome'] : '';
    $contratante_nacionalidade = isset($_POST['contratante_nacionalidade']) ? $_POST['contratante_nacionalidade'] : '';
    $contratante_estado_civil = isset($_POST['contratante_estado_civil']) ? $_POST['contratante_estado_civil'] : '';
    $contratante_cpf = isset($_POST['contratante_cpf']) ? $_POST['contratante_cpf'] : '';
    $contratante_rg = isset($_POST['contratante_rg']) ? $_POST['contratante_rg'] : '';
    $contratante_data_nascimento = isset($_POST['contratante_data_nascimento']) ? $_POST['contratante_data_nascimento'] : '';
    $contratante_endereco = isset($_POST['contratante_endereco']) ? $_POST['contratante_endereco'] : '';
    $contratante_bairro = isset($_POST['contratante_bairro']) ? $_POST['contratante_bairro'] : '';
    $contratante_cep = isset($_POST['contratante_cep']) ? $_POST['contratante_cep'] : '';
    $contratante_cidade = isset($_POST['contratante_cidade']) ? $_POST['contratante_cidade'] : '';
    $contratante_profissao = isset($_POST['contratante_profissao']) ? $_POST['contratante_profissao'] : '';
    
    $contratada_nome = isset($_POST['contratada_nome']) ? $_POST['contratada_nome'] : '';
    $contratada_sede = isset($_POST['contratada_sede']) ? $_POST['contratada_sede'] : '';
    $contratada_cnpj = isset($_POST['contratada_cnpj']) ? $_POST['contratada_cnpj'] : '';
    $contratada_cep = isset($_POST['contratada_cep']) ? $_POST['contratada_cep'] : '';
    $contratada_bairro = isset($_POST['contratada_bairro']) ? $_POST['contratada_bairro'] : '';
    $contratada_estado = isset($_POST['contratada_estado']) ? $_POST['contratada_estado'] : '';
    $valor_servicos = isset($_POST['valor_servicos']) ? $_POST['valor_servicos'] : '';
    
    $contratante_assinatura = isset($_POST['contratante_assinatura']) ? $_POST['contratante_assinatura'] : '';
    $contratada_assinatura = isset($_POST['contratada_assinatura']) ? $_POST['contratada_assinatura'] : '';
    $data_assinatura_profissional = isset($_POST['data_assinatura_profissional']) ? $_POST['data_assinatura_profissional'] : '';

}

    if (isset($_POST['id'])) {
        $id = $_POST['id'];

    $sqlUpdate = "UPDATE contrato SET 
    contratante_nome='$contratante_nome',
    contratante_nacionalidade='$contratante_nacionalidade',
    contratante_estado_civil='$contratante_estado_civil',
    contratante_cpf='$contratante_cpf',
    contratante_rg='$contratante_rg',
    contratante_data_nascimento='$contratante_data_nascimento',
    contratante_endereco='$contratante_endereco',
    contratante_bairro='$contratante_bairro',
    contratante_cep='$contratante_cep',
    contratante_cidade='$contratante_cidade',
    contratante_profissao='$contratante_profissao',
    contratada_nome='$contratada_nome',
    contratada_sede='$contratada_sede',
    contratada_cnpj='$contratada_cnpj',
    contratada_cep='$contratada_cep',
    contratada_bairro='$contratada_bairro',
    contratada_estado='$contratada_estado',
    valor_servicos='$valor_servicos',
    contratante_assinatura='$contratante_assinatura',
    contratada_assinatura='$contratada_assinatura',
    data_assinatura_profissional='$data_assinatura_profissional'
        WHERE id='$id'";

        $id = isset($_POST['id']) ? $_POST['id'] : (isset($_GET['id']) ? $_GET['id'] : '');

        if (isset($_POST['update'])) {

    $resultado = $conexao->query($sqlUpdate);

    if ($resultado) {
        echo "Registro atualizado com sucesso!";
        header('Location: listar.contrato.bioestimuladores.php');
        exit();
    } else {
        echo "Erro ao atualizar o registro: " . $conexao->error;
    }
}
    
}
?>