<?php

if (!empty($_GET['id']))

{
    include_once('../conexao.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM contrato WHERE id=$id";

    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) 
    { 
    
        while ($user_data = mysqli_fetch_assoc($resultado)) 
        {
        
    $contratante_nome = isset($user_data['contratante_nome']) ? $user_data['contratante_nome'] : '';
    $contratante_nacionalidade = isset($user_data['contratante_nacionalidade']) ? $user_data['contratante_nacionalidade'] : '';
    $contratante_estado_civil = isset($user_data['contratante_estado_civil']) ? $user_data['contratante_estado_civil'] : '';
    $contratante_cpf = isset($user_data['contratante_cpf']) ? $user_data['contratante_cpf'] : '';
    $contratante_rg = isset($user_data['contratante_rg']) ? $user_data['contratante_rg'] : '';
    $contratante_data_nascimento = isset($user_data['contratante_data_nascimento']) ? $user_data['contratante_data_nascimento'] : '';
    $contratante_endereco = isset($user_data['contratante_endereco']) ? $user_data['contratante_endereco'] : '';
    $contratante_bairro = isset($user_data['contratante_bairro']) ? $user_data['contratante_bairro'] : '';
    $contratante_cep = isset($user_data['contratante_cep']) ? $user_data['contratante_cep'] : '';
    $contratante_cidade = isset($user_data['contratante_cidade']) ? $user_data['contratante_cidade'] : '';
    $contratante_profissao = isset($user_data['contratante_profissao']) ? $user_data['contratante_profissao'] : '';
    
    $contratada_nome = isset($user_data['contratada_nome']) ? $user_data['contratada_nome'] : '';
    $contratada_sede = isset($user_data['contratada_sede']) ? $user_data['contratada_sede'] : '';
    $contratada_cnpj = isset($user_data['contratada_cnpj']) ? $user_data['contratada_cnpj'] : '';
    $contratada_cep = isset($user_data['contratada_cep']) ? $user_data['contratada_cep'] : '';
    $contratada_bairro = isset($user_data['contratada_bairro']) ? $user_data['contratada_bairro'] : '';
    $contratada_estado = isset($user_data['contratada_estado']) ? $user_data['contratada_estado'] : '';
    $valor_servicos = isset($user_data['valor_servicos']) ? $user_data['valor_servicos'] : '';

    $contratante_assinatura = isset($user_data['contratante_assinatura']) ? $user_data['contratante_assinatura'] : '';
    $contratada_assinatura = isset($user_data['contratada_assinatura']) ? $user_data['contratada_assinatura'] : '';
    $data_assinatura_profissional = isset($user_data['data_assinatura_profissional']) ? $user_data['data_assinatura_profissional'] : '';


    }

    } 
    else
    {
        header('Location:./listar.contrato.preenchimento.php');
    }    
    
}
?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contrato Bioestimulador</title>
    <link rel="stylesheet" href="../css/Contrato.css">
    <script src="conexaobioestimu.php"></script>
</head>

<style>
    .botao-registro {
       position: relative;
       top: 10px;
       right: 15px;
       left: 15px;
       background-color: rgb(11, 87, 1);
       color: #ffffff;
       border: none;
       padding: 10px 20px;
       font-size: 16px;
       cursor: pointer;
       border-radius: 5px;
       transition: background-color 0.3s ease;
    }

    #update {
      position: relative;
      top: 10px;
      right: 10px;
      background-color: rgb(11, 87, 1);
      color: #ffffff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s ease;
  }
    </style>

<body>

    <a href="../pagina_inicial/contratos.html">
        <button class="botao-estilizado">Voltar</button>
    </a>
    
    <a href="./listar.contrato.bioestimuladores.php">
    <button class="botao-registro">Registro de Contratos</button>
 </a>

    <form action="salvar.bioestimuladores.php" method="post" enctype="multipart/form-data">

        <div class="container">
            <h2>CONTRATO
                <br></br>
                PRESTAÇÃO DE SERVIÇOS DE PROCEDIMENTOS ESTÉTICOS
                <br></br>
                Bioestimuladores de Colágeno
            </h2>

            <p>
                <h3>CONTRATANTE</h3>

                <div class="form-group">
    <label>Nome:</label>
    <input type="text" name="contratante_nome" class="inputUser" value="<?php echo isset($contratante_nome) ? $contratante_nome : ''; ?>" placeholder="Nome completo">

    <label>Nacionalidade:</label>
        <input type="text" name="contratante_nacionalidade" class="inputUser" value="<?php echo isset($contratante_nacionalidade) ? $contratante_nacionalidade : ''; ?>" >
    </div>

    <div class="form-group">
        <label>Estado Civil:</label>
        <input type="text" name="contratante_estado_civil" class="inputUser" value="<?php echo isset($contratante_estado_civil) ? $contratante_estado_civil : ''; ?>">  

        <label>CPF:</label>
        <input type="text" name="contratante_cpf" class="inputUser" value="<?php echo isset($contratante_cpf) ? $contratante_cpf : ''; ?>">
    </div>

    <div class="form-group">
        <label>RG:</label>
        <input type="text" name="contratante_rg" class="inputUser" value="<?php echo isset($contratante_rg) ? $contratante_rg : ''; ?>">

        <label>Data de Nascimento:</label>
        <input type="date" name="contratante_data_nascimento" class="inputUser" value="<?php echo isset($contratante_data_nascimento) ? $contratante_data_nascimento : ''; ?>">
    </div>

    <div class="form-group">
        <label>Endereço:</label>
        <input type="text" name="contratante_endereco" class="inputUser" value="<?php echo isset($contratante_endereco) ? $contratante_endereco : ''; ?>">

        <label>Bairro:</label>
        <input type="text" name="contratante_bairro" class="inputUser" value="<?php echo isset($contratante_bairro) ? $contratante_bairro : ''; ?>">
    </div>

    <div class="form-group">
        <label>CEP:</label>
        <input type="text" name="contratante_cep" class="inputUser" value="<?php echo isset($contratante_cep) ? $contratante_cep : ''; ?>">

        <label>Cidade:</label>
        <input type="text" name="contratante_cidade" class="inputUser" value="<?php echo isset($contratante_cidade) ? $contratante_cidade : ''; ?>">
    </div>

    <div class="form-group">
        <label>Profissão:</label>
        <input type="text" name="contratante_profissao" class="inputUser" value="<?php echo isset($contratante_profissao) ? $contratante_profissao : ''; ?>">
    </div>
</p>

<h3>CONTRATADA</h3>

<div class="form-group">
    <label>Nome:</label>
    <input type="text" name="contratada_nome" class="inputUser" value="<?php echo isset($contratada_nome) ? $contratada_nome : ''; ?>" placeholder="Nome completo">

    <label>Sede:</label>
    <input type="text" name="contratada_sede" class="inputUser" value="<?php echo isset($contratada_sede) ? $contratada_sede : ''; ?>">
</div>

<div class="form-group">
    <label>CNPJ:</label>
    <input type="text" name="contratada_cnpj" class="inputUser" value="<?php echo isset($contratada_cnpj) ? $contratada_cnpj : ''; ?>">

    <label>CEP:</label>
    <input type="text" name="contratada_cep"class="inputUser" value="<?php echo isset($contratada_cep) ? $contratada_cep : ''; ?>">
</div>

<div class="form-group">
    <label>Bairro:</label>
    <input type="text" name="contratada_bairro" class="inputUser" value="<?php echo isset($contratada_bairro) ? $contratada_bairro : ''; ?>">

    <label>Estado:</label>
    <input type="text" name="contratada_estado" class="inputUser" value="<?php echo isset($contratada_estado) ? $contratada_estado : ''; ?>">
</div>

                <div class="contrato">
            <p>
                <h3>Parágrafo Único:</h3>
            A CONTRATADA compromete-se a disponibilizar profissionais capacitados e habilitados para suas 
            <br></br>
            respectivas funções durante todo o processo de tratamento.

            <h3>I. CONDIÇÕES DOS SERVIÇOS CONTRATADOS</h3>

        <h3>a) do Local</h3>
        Todos os serviços contratados serão prestados nas dependências da CLÍNICA......., conforme mencionado 
        os dados e endereço acima. 

        <h3>b) do horário de atendimento</h3>
        A CONTRATADA compromete-se a disponibilizar horários variados que possibilitem a realização dos 
        procedimentos e serviços contratados, não havendo, no entanto, compromisso de atendimento fora dos 
        horários estipulados pela clínica.

        <h3>c) dos Profissionais</h3>

        Profissionais habilitados serão disponibilizados para atender o CONTRATANTE adequadamente, de acordo 
        com padrões técnicos exigidos.

        <h3>d) do objeto de contratação:</h3>
        Aplicação de Bioestimulador de colágeno. Na Dermatologia e estética, o Procedimento está indicado 
        para o estimulo de colágeno no local objetivo do tratamento, tendo como resposta melhoria da firmeza 
        e sustentação, Pode ser indicado para a prevenção e tratamento da flacidez, aumento da espessura 
        dérmica e rejuvenescimento facial e corporal. Os resultados não são imediatos, podendo ser observado 
        por volta de 20 a 40 dias após a aplicação, dependendo da área e da resistência pessoal ao fármaco, 
        com efeito máximo em até 6 meses, podendo durar seus resultados por até 2 anos, de acordo com a bula 
        do fármaco. O procedimento é realizado em uma única sessão com direito ao retorno. O retorno será 
        realizado entre 30 á 90 dias após a aplicação para avaliação dos resultados obtidos e averiguação da 
        necessidade em dar continuidade ao tratamento de acordo com o objetivo do tratamento. Ressalta-se que 
        a durabilidade dos resultados dos bioestimuladores de colágeno é limitada, e depende, sobretudo, da 
        resposta fisiológica do paciente, de fatores externos podendo ser necessário mais de uma aplicação 
        dependendo do objetivo de tratamento inicial.  


    <h3>II.  VALOR DOS SERVIÇOS</h3>
Pelos serviços contratados, o (a) CONTRATANTE pagará o valor total de <input type="text" name="valor_servicos" class="inputUser" value="<?php echo isset($valor_servicos) ? $valor_servicos : ''; ?>">


<h3>III. FORMA DE PAGAMENTO</h3>

a) O pagamento poderá ser realizado em dinheiro, cartão de débito ou crédito, transferência bancária, PIX 
ou boleto bancário.
<br></br>
b). Os pagamentos deverão ser feitos independentemente de freqüência ao Nosso Local, posto que os serviços, 
equipamentos e instalações ficarão disponíveis para utilização por todo o prazo do plano contratado.
<br></br>
c) A quitação somente se dará após a confirmação do crédito total em favor do Contratado.
 
<h3>IV.  DAS FALTAS</h3>

a) É de responsabilidade única e exclusiva do(a) CONTRATANTE respeitar e cumprir a agenda previamente 
organizada.
<br></br>
b) O CONTRATANTE terá direito a repor o retorno, desde que seja realizado dentro do período de até 90 dias 
após a aplicação, mediante aviso prévio de, no máximo, 12 horas de antecedência. Caso o CONTRATANTE  falte,
sem aviso prévio ao retorno, a sessão será dada como realizada.
<br></br>
<h3>V. PRAZOS DE VALIDADE: </h3>

a) da Duração do Contrato: A duração do contrato é de 90 dias, de acordo com o tratamento definido no momento
da avaliação inicial, que já é parte integrante deste documento.

<h3>VI. DOS ANEXOS E DA RESCISÃO</h3>

a) Faz parte do presente, o orçamento previamente mencionado na cláusula terceira, os termos de consentimento 
e esclarecimento informados e as orientações pós-procedimentos (quando houver), que serão anexados ao contrato
para fins de documentação.
<br></br>
b) O presente Termo poderá ser rescindido a qualquer tempo, mediante solicitação por escrito, com antecedência 
mínima de 10 (dez) dias da data do vencimento da próxima parcela. Em caso de cancelamento por iniciativa do 
contratante ou em decorrência do descumprimento, pelo contratante, de suas obrigações contratuais, será devido 
ao CONTRATADO o equivalente à 30% do valor das sessões ainda não executadas. 
<br></br>
c) Caso a solicitação de cancelamento seja recebida pelo Contratado após a data acima mencionada, será 
procedido normalmente o envio da cobrança.
<br></br>
d) Na hipótese de descumprimento de quaisquer das cláusulas contratuais e/ou regulamentares do Contratado 
por parte do contratante, assim como qualquer conduta do mesmo contrária à moral e aos bons costumes ou que, 
por qualquer forma, cause perturbação no ambiente, aos funcionários, instrutores, ou demais frequentadores, 
o contratado poderá rescindir o presente Termo sem qualquer ônus e sem que seja devida restituição de qualquer 
valor já pago.
<br></br>
e) Caso o Contratado fique impossibilitado permanentemente de prestar os serviços contratados, o cliente será reembolsado em 100% sobre o valor dos procedimentos não realizados.

<h3>VII. DISPOSIÇÕES GERAIS</h3>

a) O presente termo é firmado por prazo determinado, o qual poderá ser renovado mediante condições vigentes à
época, podendo o contratante optar por qualquer um dos planos disponíveis.
<br></br>
b) Fica desde já expressamente autorizada a realização de fotografias para fins documentais (prontuário) e 
comparativos entre antes e depois para demonstração de resultado ao(à) CONTRATANTE.
<br></br>
c) E, por estarem de acordo com as condições acima descritas, assinam o presente contrato, em duas vias de 
igual teor, para que se produzam todos os efeitos legais, elegendo o Foro de CIDADE - UF como o único competente para dirimir as dúvidas decorrentes deste.



            </p>

            </div>

            <div class="form-group">

                <center>
                    <label>Contratante (Assinatura)</label>
                    <input type="text" name="contratante_assinatura" class="inputUser" value="<?php echo isset($contratante_assinatura) ? $contratante_assinatura : ''; ?>">
                    <br></br>

                    <label>Contratada (Assinatura)</label>
                    <input type="text" name="contratada_assinatura" class="inputUser" value="<?php echo isset($contratada_assinatura) ? $contratada_assinatura : ''; ?>">
                    <br></br>

                    <label>Data</label>
                    <input type="date" name="data_assinatura_profissional" class="inputUser" value="<?php echo isset($data_assinatura_profissional) ? $data_assinatura_profissional : ''; ?>">
                </center>
            </div>

            <input type="hidden" name="id" value="<?php echo isset($id) ? $id : ''; ?>">

            <center>
            <input type="submit" name="update" id="update" value="Aceitar Contrato">
            </center>
        </div>
    </form>

</body>
</html>
