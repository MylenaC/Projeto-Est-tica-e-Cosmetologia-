<?php
    include("../conexao.php");
    
    $contratanteNome = isset($_POST['contratante_nome']) ? $_POST['contratante_nome'] : '';
    $contratanteNacionalidade = isset($_POST['contratante_nacionalidade']) ? $_POST['contratante_nacionalidade'] : '';
    $contratanteEstadoCivil = isset($_POST['contratante_estado_civil']) ? $_POST['contratante_estado_civil'] : '';
    $contratanteCPF = isset($_POST['contratante_cpf']) ? $_POST['contratante_cpf'] : '';
    $contratanteRG = isset($_POST['contratante_rg']) ? $_POST['contratante_rg'] : '';
    $contratanteDataNascimento = isset($_POST['contratante_data_nascimento']) ? $_POST['contratante_data_nascimento'] : '';
    $contratanteEndereco = isset($_POST['contratante_endereco']) ? $_POST['contratante_endereco'] : '';
    $contratanteBairro = isset($_POST['contratante_bairro']) ? $_POST['contratante_bairro'] : '';
    $contratanteCEP = isset($_POST['contratante_cep']) ? $_POST['contratante_cep'] : '';
    $contratanteCidade = isset($_POST['contratante_cidade']) ? $_POST['contratante_cidade'] : '';
    $contratanteProfissao = isset($_POST['contratante_profissao']) ? $_POST['contratante_profissao'] : '';
    
    $contratadaNome = isset($_POST['contratada_Nome']) ? $_POST['contratada_Nome'] : '';
    $contratadaSede = isset($_POST['contratada_Sede']) ? $_POST['contratada_Sede'] : '';
    $contratadaCNPJ = isset($_POST['contratada_cnpj']) ? $_POST['contratada_cnpj'] : '';
    $contratadaCEP = isset($_POST['contratada_cep']) ? $_POST['contratada_cep'] : '';
    $contratadaBairro = isset($_POST['contratada_bairro']) ? $_POST['contratada_bairro'] : '';
    $contratadaEstado = isset($_POST['contratada_estado']) ? $_POST['contratada_estado'] : '';
    
    $contratanteAssinatura = isset($_POST['contratante_assinatura']) ? $_POST['contratante_assinatura'] : '';
    $contratadaAssinatura = isset($_POST['contratada_assinatura']) ? $_POST['contratada_assinatura'] : '';
    $dataAssinaturaProfissional = isset($_POST['data_assinatura_profissional']) ? $_POST['data_assinatura_profissional'] : '';
    

    // Prepara a instrução SQL para a inserção de dados
    $sql = "INSERT INTO contrato_preenchimento_acido (
    contratante_nome, contratante_nacionalidade, contratante_estado_civil, contratante_cpf, contratante_rg,
    contratante_data_nascimento, contratante_endereco, contratante_bairro, contratante_cep, contratante_cidade,
    contratante_profissao, contratada_nome, contratada_sede, contratada_cnpj, contratada_cep, contratada_bairro,
    contratada_estado, contratante_assinatura, contratada_assinatura, data_assinatura_profissional) 

    VALUES ('$contratanteNome', '$contratanteNacionalidade', '$contratanteEstadoCivil', '$contratanteCPF',
    '$contratanteRG', '$contratanteDataNascimento', '$contratanteEndereco', '$contratanteBairro',
    '$contratanteCEP', '$contratanteCidade', '$contratanteProfissao', '$contratadaNome', '$contratadaSede',
    '$contratadaCNPJ', '$contratadaCEP', '$contratadaBairro', '$contratadaEstado', '$contratanteAssinatura',
    '$contratadaAssinatura', '$dataAssinaturaProfissional')";

    $resultado = mysqli_query($conexao, $sql);


// Executa a instrução SQL
    if ($conexao->query($sql) === TRUE) {
        header('Location: listar.contrato.preenchimento.php');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento
} else {
    echo "Erro ao inserir dados: " . $conn->error;
}

// Fecha a conexão
$conexao->close();
?>



