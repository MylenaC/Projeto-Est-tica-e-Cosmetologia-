<?php
include_once('../conexao.php');

// Verificar se a conexão foi bem-sucedida
if ($conexao->connect_error) {
    die("Erro de Conexão: " . $conexao->connect_error);
}

if (!empty($_GET['search'])) {

    $data = $_GET ['search'];

    $sql = "SELECT * FROM termo_hidroxiapatita WHERE id LIKE '%$data%' or nome LIKE '%$data%' or email LIKE '%$data%' ORDER BY id ASC";

} else {
    $sql = "SELECT * FROM termo_hidroxiapatita ORDER BY id ASC";
}

// Executar a consulta após a definição da variável $sql
$resultado = $conexao->query($sql);

// Verificar se a consulta foi bem-sucedida
if (!$resultado) {
    die("Erro na Consulta: " . $conexao->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termo de Consentimento para Hidroxiapatita de Cálcio</title>
    <link rel="stylesheet" href="../bootstrap-4.1.3-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        .table-bg {
            background:rgb(161, 233, 183);
            border-radius: 15px 15px 0 0;
            width: 100%;
        }
    
        .botao-estilizado {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgb(11, 87, 1);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        h1 {
            margin-top: 5%;
            color: rgb(11, 87, 1);
        }

        table {
            margin-top: 10%;
        }

        .m-5 {
            position: relative;
        }

        .novo {
            position: absolute;
            top: 15%;
            left: 10px;
            background-color: rgb(11, 87, 1);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        
        .box-search {
        display: flex;
        justify-content: center;
        gap: .1%;
        margin-top: 50px; /* Ajuste este valor conforme necessário */
        }

    </style>
</head>
<body>

<center>
    <h1>Termo de Consentimento para Hidroxiapatita de Cálcio</h1>
</center>

<a href="../pagina_inicial/termos">
    <button class="botao-estilizado">Voltar</button>
</a>

<div class="box-search">
        <input type="search" class="form-control w-25" placeholder="Pesquisar" id="pesquisar">
        <button onclick="searchData()" class="btn btn-success">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
        </svg>
        </button>
    </div>

    <a href="../termos/Termo.Hidroxiapatita.html">
    <button class="novo">Novo registro</button>
    </a>

    <table class="table table-hover table-bg">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">CPF</th>
                <th scope="col">E-mail</th>
                <th scope="col">Alergia</th>
                <th scope="col">Objetivo</th>
                <th scope="col">Descrição</th>
                <th scope="col">tempo</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>

  <?php
while ($user_data = $resultado->fetch_assoc()) {
  echo "<tr>";
  echo "<td>".$user_data['id']."</td>";
  echo "<td>".$user_data['nome']."</td>";
  echo "<td>".$user_data['cpf']."</td>";
  echo "<td>".$user_data['email']."</td>";
  echo "<td>".$user_data['alergia']."</td>";
  echo "<td>".$user_data['objetivo']."</td>";
  echo "<td>".$user_data['descricao']."</td>";
  echo "<td>".$user_data['tempo']."</td>";
  echo "<td>".
      "<a class='btn btn-sm btn-primary' href='editar.hidroxiapatita.php?id=$user_data[id]'>".
      "<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-pencil' viewBox='0 0 16 16'>".
      "<path d='M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.
      65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.
      707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.
      106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z'/>".
      "</svg>".
      "</a>".

      "<a class='btn btn-sm btn-danger' href='delete.hidroxiapatita.php?id=$user_data[id]'>".
      "<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-trash3-fill' 
      viewBox='0 0 16 16'>".
      "<path d='M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 
      1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 
      11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 
      0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 
      0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5'/>".
      "</svg>".
      "</a>".
      "</td>";
  echo "</tr>";
}



  ?>

  </tbody>
</table>

  </div>
</body>

<script>
        var search = document.getElementById('pesquisar');

        search.addEventListener("keydown", function(event){
            if (event.key === "Enter")
            {
                searchData();
            }
        
        });

        function searchData()
        {
            window.location = 'listar.hidroxiapatita.php?search='+search.value;
        }

    </script>
</html>
