<?php

if (!empty($_GET['id'])) {
    include_once('../conexao.php');

    $id = $_GET['id'];
    $sqlSelect = "SELECT * FROM anamnese_corporal WHERE id=$id";
    $resultado = $conexao->query($sqlSelect);

    if ($resultado->num_rows > 0) {
        $user_data = $resultado->fetch_assoc();

        if ($user_data) {
            $nome_completo = isset($user_data['nome_completo']) ? $user_data['nome_completo'] : '';
            $data_nascimento = isset($user_data['data_nascimento']) ? $user_data['data_nascimento'] : '';
            $idade = isset($user_data['idade']) ? $user_data['idade'] : '';
            $endereco = isset($user_data['endereco']) ? $user_data['endereco'] : '';
            $cep = isset($user_data['cep']) ? $user_data['cep'] : '';
            $bairro = isset($user_data['bairro']) ? $user_data['bairro'] : '';
            $cidade = isset($user_data['cidade']) ? $user_data['cidade'] : '';
            $estado = isset($user_data['estado']) ? $user_data['estado'] : '';
            $telefone_residencial = isset($user_data['telefone_residencial']) ? $user_data['telefone_residencial'] : '';
            $telefone_comercial = isset($user_data['telefone_comercial']) ? $user_data['telefone_comercial'] : '';
            $celular = isset($user_data['celular']) ? $user_data['celular'] : '';
            $escolaridade = isset($user_data['escolaridade']) ? $user_data['escolaridade'] : '';
            $escolaridade_completa = isset($user_data['escolaridade_completa']) ? $user_data['escolaridade_completa'] : '';
            $profissao = isset($user_data['profissao']) ? $user_data['profissao'] : '';
            $estado_civil = isset($user_data['estado_civil']) ? $user_data['estado_civil'] : '';
            $exposicao_ao_sol = isset($user_data['exposicao_ao_sol']) ? $user_data['exposicao_ao_sol'] : '';
            $filtro_solar = isset($user_data['filtro_solar']) ? $user_data['filtro_solar'] : '';
            $frequencia_filtro_solar = isset($user_data['frequencia_filtro_solar']) ? $user_data['frequencia_filtro_solar'] : '';
            $usa_chapeu = isset($user_data['usa_chapeu']) ? $user_data['usa_chapeu'] : '';
            $usa_cosmeticos = isset($user_data['usa_cosmeticos']) ? $user_data['usa_cosmeticos'] : '';
            $cosmeticos_capilares = isset($user_data['cosmeticos_capilares']) ? $user_data['cosmeticos_capilares'] : '';
            $usa_isotretinoina = isset($user_data['usa_isotretinoina']) ? $user_data['usa_isotretinoina'] : '';
            $usa_fotossensibilizantes = isset($user_data['usa_fotossensibilizantes']) ? $user_data['usa_fotossensibilizantes'] : '';
            $fotossensibilizantes = isset($user_data['fotossensibilizantes']) ? $user_data['fotossensibilizantes'] : '';
            $usa_lentes = isset($user_data['usa_lentes']) ? $user_data['usa_lentes'] : '';
            $tabagismo = isset($user_data['tabagismo']) ? $user_data['tabagismo'] : '';
            $quantidade_cigarros = isset($user_data['quantidade_cigarros']) ? $user_data['quantidade_cigarros'] : '';
            $ingere_bebida = isset($user_data['ingere_bebida']) ? $user_data['ingere_bebida'] : '';
            $frequencia_bebida = isset($user_data['frequencia_bebida']) ? $user_data['frequencia_bebida'] : '';
            $qualidade_sono = isset($user_data['qualidade_sono']) ? $user_data['qualidade_sono'] : '';
            $horas_sono = isset($user_data['horas_sono']) ? $user_data['horas_sono'] : '';
            $ingestao_agua_dia = isset($user_data['ingestao_agua_dia']) ? $user_data['ingestao_agua_dia'] : '';
            $alimentacao = isset($user_data['alimentacao']) ? $user_data['alimentacao'] : '';
            $faz_dieta = isset($user_data['faz_dieta']) ? $user_data['faz_dieta'] : '';
            $patologia_de_pele = isset($user_data['patologia_de_pele']) ? $user_data['patologia_de_pele'] : '';
            $patologia = isset($user_data['patologia']) ? $user_data['patologia'] : '';
            $outra_patologia = isset($user_data['outra_patologia']) ? $user_data['outra_patologia'] : '';
            $faz_procedimento_estetico = isset($user_data['faz_procedimento_estetico']) ? $user_data['faz_procedimento_estetico'] : '';
            $alteracoes_tireoide = isset($user_data['alteracoes_tireoide']) ? $user_data['alteracoes_tireoide'] : '';
            $hipotireoidismo = isset($user_data['hipotireoidismo']) ? $user_data['hipotireoidismo'] : '';
            $hipertireoidismo = isset($user_data['hipertireoidismo']) ? $user_data['hipertireoidismo'] : '';
            $toma_medicacao = isset($user_data['toma_medicacao']) ? $user_data['toma_medicacao'] : '';
            $medicacao = isset($user_data['medicacao']) ? $user_data['medicacao'] : '';
            $tempo_medicacao = isset($user_data['tempo_medicacao']) ? $user_data['tempo_medicacao'] : '';
            $usa_suplemento_oral = isset($user_data['usa_suplemento_oral']) ? $user_data['usa_suplemento_oral'] : '';
            $suplemento_oral = isset($user_data['suplemento_oral']) ? $user_data['suplemento_oral'] : '';
            $tem_antecedentes_oncologicos = isset($user_data['tem_antecedentes_oncologicos']) ? $user_data['tem_antecedentes_oncologicos'] : '';
            $antecedentes_oncologicos = isset($user_data['antecedentes_oncologicos']) ? $user_data['antecedentes_oncologicos'] : '';
            $tem_diabetes = isset($user_data['tem_diabetes']) ? $user_data['tem_diabetes'] : '';
            $fez_cirurgia_plastica_estetica = isset($user_data['fez_cirurgia_plastica_estetica']) ? $user_data['fez_cirurgia_plastica_estetica'] : '';
            $cirurgia_plastica_estetica = isset($user_data['cirurgia_plastica_estetica']) ? $user_data['cirurgia_plastica_estetica'] : '';
            $queixa_alopecia = isset($user_data['queixa_alopecia']) ? $user_data['queixa_alopecia'] : '';
            $alopecia_acomete_corpo = isset($user_data['alopecia_acomete_corpo']) ? $user_data['alopecia_acomete_corpo'] : '';
            $partes_acometidas = isset($user_data['partes_acometidas']) ? $user_data['partes_acometidas'] : '';
            $tempo_disfuncao = isset($user_data['tempo_disfuncao']) ? $user_data['tempo_disfuncao'] : '';
            $estado_disfuncao = isset($user_data['estado_disfuncao']) ? $user_data['estado_disfuncao'] : '';
            $peso_inicio = isset($user_data['peso_inicio']) ? $user_data['peso_inicio'] : '';
            $peso_meio = isset($user_data['peso_meio']) ? $user_data['peso_meio'] : '';
            $peso_fim = isset($user_data['peso_fim']) ? $user_data['peso_fim'] : '';
            $busto_inicio = isset($user_data['busto_inicio']) ? $user_data['busto_inicio'] : '';
            $busto_meio = isset($user_data['busto_meio']) ? $user_data['busto_meio'] : '';
            $busto_fim = isset($user_data['busto_fim']) ? $user_data['busto_fim'] : '';
            $braco_esq_inicio = isset($user_data['braco_esq_inicio']) ? $user_data['braco_esq_inicio'] : '';
            $braco_esq_meio = isset($user_data['braco_esq_meio']) ? $user_data['braco_esq_meio'] : '';
            $braco_esq_fim = isset($user_data['braco_esq_fim']) ? $user_data['braco_esq_fim'] : '';
            $braco_dir_inicio = isset($user_data['braco_dir_inicio']) ? $user_data['braco_dir_inicio'] : '';
            $braco_dir_meio = isset($user_data['braco_dir_meio']) ? $user_data['braco_dir_meio'] : '';
            $braco_dir_fim = isset($user_data['braco_dir_fim']) ? $user_data['braco_dir_fim'] : '';
            $abdomen_inicio = isset($user_data['abdomen_inicio']) ? $user_data['abdomen_inicio'] : '';
            $abdomen_meio = isset($user_data['abdomen_meio']) ? $user_data['abdomen_meio'] : '';
            $abdomen_fim = isset($user_data['abdomen_fim']) ? $user_data['abdomen_fim'] : '';
            $cintura_inicio = isset($user_data['cintura_inicio']) ? $user_data['cintura_inicio'] : '';
            $cintura_meio = isset($user_data['cintura_meio']) ? $user_data['cintura_meio'] : '';
            $cintura_fim = isset($user_data['cintura_fim']) ? $user_data['cintura_fim'] : '';
            $quadril_inicio = isset($user_data['quadril_inicio']) ? $user_data['quadril_inicio'] : '';
            $quadril_meio = isset($user_data['quadril_meio']) ? $user_data['quadril_meio'] : '';
            $quadril_fim = isset($user_data['quadril_fim']) ? $user_data['quadril_fim'] : '';
            $culote_inicio = isset($user_data['culote_inicio']) ? $user_data['culote_inicio'] : '';
            $culote_meio = isset($user_data['culote_meio']) ? $user_data['culote_meio'] : '';
            $culote_fim = isset($user_data['culote_fim']) ? $user_data['culote_fim'] : '';
            $coxa_esq_inicio = isset($user_data['coxa_esq_inicio']) ? $user_data['coxa_esq_inicio'] : '';
            $coxa_esq_meio = isset($user_data['coxa_esq_meio']) ? $user_data['coxa_esq_meio'] : '';
            $coxa_esq_fim = isset($user_data['coxa_esq_fim']) ? $user_data['coxa_esq_fim'] : '';
            $coxa_dir_inicio = isset($user_data['coxa_dir_inicio']) ? $user_data['coxa_dir_inicio'] : '';
            $coxa_dir_meio = isset($user_data['coxa_dir_meio']) ? $user_data['coxa_dir_meio'] : '';
            $coxa_dir_fim = isset($user_data['coxa_dir_fim']) ? $user_data['coxa_dir_fim'] : '';
            $panturrilha_esq_inicio = isset($user_data['panturrilha_esq_inicio']) ? $user_data['panturrilha_esq_inicio'] : '';
            $panturrilha_esq_meio = isset($user_data['panturrilha_esq_meio']) ? $user_data['panturrilha_esq_meio'] : '';
            $panturrilha_esq_fim = isset($user_data['panturrilha_esq_fim']) ? $user_data['panturrilha_esq_fim'] : '';
            $panturrilha_dir_inicio = isset($user_data['panturrilha_dir_inicio']) ? $user_data['panturrilha_dir_inicio'] : '';
            $panturrilha_dir_meio = isset($user_data['panturrilha_dir_meio']) ? $user_data['panturrilha_dir_meio'] : '';
            $panturrilha_dir_fim = isset($user_data['panturrilha_dir_fim']) ? $user_data['panturrilha_dir_fim'] : '';
            $imc_inicio = isset($user_data['imc_inicio']) ? $user_data['imc_inicio'] : '';
            $imc_meio = isset($user_data['imc_meio']) ? $user_data['imc_meio'] : '';
            $imc_fim = isset($user_data['imc_fim']) ? $user_data['imc_fim'] : '';
            $biotipo_corporal = isset($user_data['biotipo_corporal']) ? $user_data['biotipo_corporal'] : '';
            $distribuicao_gordura = isset($user_data['distribuicao_gordura']) ? $user_data['distribuicao_gordura'] : '';
            $presenca_diastase = isset($user_data['presenca_diastase']) ? $user_data['presenca_diastase'] : '';
            $tipo_gordura = isset($user_data['tipo_gordura']) ? $user_data['tipo_gordura'] : '';
            $regiao_gordura = isset($user_data['regiao_gordura']) ? $user_data['regiao_gordura'] : '';
            $observacoes_gordura = isset($user_data['observacoes_gordura']) ? $user_data['observacoes_gordura'] : '';
            $tipo_flacidez = isset($user_data['tipo_flacidez']) ? $user_data['tipo_flacidez'] : '';
            $regiao_flacidez = isset($user_data['regiao_flacidez']) ? $user_data['regiao_flacidez'] : '';
            $observacoes_flacidez = isset($user_data['observacoes_flacidez']) ? $user_data['observacoes_flacidez'] : '';
            $grau_hldg = isset($user_data['grau_hldg']) ? $user_data['grau_hldg'] : '';
            $tipo_hldg = isset($user_data['tipo_hldg']) ? $user_data['tipo_hldg'] : '';
            $regiao_hldg = isset($user_data['regiao_hldg']) ? $user_data['regiao_hldg'] : '';
            $observacoes_hldg = isset($user_data['observacoes_hldg']) ? $user_data['observacoes_hldg'] : '';
            $tipo_estrias = isset($user_data['tipo_estrias']) ? $user_data['tipo_estrias'] : '';
            $largura_estria = isset($user_data['largura_estria']) ? $user_data['largura_estria'] : '';
            $observacoes_estrias = isset($user_data['observacoes_estrias']) ? $user_data['observacoes_estrias'] : '';
            $experiencia = isset($user_data['experiencia']) ? $user_data['experiencia'] : '';
            $nome_paciente = isset($user_data['nome_paciente']) ? $user_data['nome_paciente'] : '';
            $assinatura = isset($user_data['assinatura']) ? $user_data['assinatura'] : '';
            $assinatura_paciente = isset($user_data['assinatura_paciente']) ? $user_data['assinatura_paciente'] : '';
            $data_assinatura_paciente = isset($user_data['data_assinatura_paciente']) ? $user_data['data_assinatura_paciente'] : '';
            $nome_profissional = isset($user_data['nome_profissional']) ? $user_data['nome_profissional'] : '';
            $data_assinatura_profissional = isset($user_data['data_assinatura_profissional']) ? $user_data['data_assinatura_profissional'] : '';
        }
    } else {
        header('Location: listar.anamnese.corporal');
        exit(); // Adicione esta linha para garantir que o script seja encerrado após o redirecionamento

    }
}

?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha Anamnese Corporal</title>
    <link rel="stylesheet" href="../css/Ficha.anamnese.css">
</head>

<style>
    /* Estilo para o fundo */
    .background {
        background-color: #ffffff;
        /* Cor de fundo */
    }

    /* Estilo para o menu */
    header {
        background-color: rgb(76, 115, 55);
        /* Cor de fundo do cabeçalho */
        padding: 20px 0;
        /* Espaçamento interno no cabeçalho */
        text-align: center;
        /* Alinhamento centralizado do texto */
    }

    .links {
        list-style-type: none;
        /* Remove marcadores de lista */
        margin: 0;
        /* Remove margem externa */
        padding: 0;
        /* Remove preenchimento interno */
    }

    .links li {
        display: inline;
        /* Exibe os itens de menu em linha */
        margin-right: 20px;
        /* Espaçamento entre os itens do menu */
    }

    .links li a {
        text-decoration: none;
        /* Remove sublinhado dos links */
        color: #fff;
        /* Cor do texto */
        font-weight: bold;
        /* Texto em negrito */
        transition: color 0.3s;
        /* Transição de cor suave */
    }

    .links li a:hover {
        color: #8dd090;
        /* Cor do texto ao passar o mouse sobre o link */
    }

    .container2 {
        text-align: center;
        /* Centraliza o conteúdo dentro do contêiner */
    }

    .container2 img {
        display: inline-block;
        /* Permite a aplicação de margens automáticas */
        margin: 0 auto;
        /* Centraliza a imagem horizontalmente */
    }

    .botao-estilizado2 {
        position: absolute;
        /* Posição absoluta */
        top: 10px;
        /* Distância do topo */
        left: 10px;
        /* Distância da direita */
        background-color: rgb(13, 55, 8);
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }
</style>

<body>

    <a href="../Ficha_Anamnese/listar.anamnese.corporal.php">
        <button class="botao-estilizado2">Anamnese Corporal</button>
    </a>


    <div class="background">
        <header>
            <ul class="links">
                <li><a href="#dados-pessoais">Dados pessoais</a></li>
                <li><a href="#habitos-diarios">Hábitos diários</a></li>
                <li><a href="#historico-clinico-e-avaliacao-cutanea">Histórico clínico e avaliação cutânea</a></li>
                <li><a href="#termo-de-responsabilidade">Termo de Responsabilidade</a></li>
            </ul>
        </header>

        <a href="/estetica2/pagina_inicial/ficha.html">
            <button class="botao-estilizado">Voltar</button>
        </a>



        <div class="container">
            <form method="post" action="salvar.anamnese.corporal.php" id="anamnese_corporal">
                <h1>FICHA DE ANAMNESE CORPORAL</h1>
        </div>


        <h2 id="dados-pessoais">DADOS PESSOAIS</h2>


        <div class="form-group">

            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <label>Nome:</label>
            <input type="text" name="nome_completo" id="nome_completo" class="inputUser" value="<?php echo $nome_completo ?>" placeholder="Nome completo">

            <label>Data de Nascimento:</label>
            <input type="date" name="data_nascimento" id="data_nascimento" class="inputUser" value="<?php echo $data_nascimento ?>">

            <label>Idade:</label>
            <input type="number" name="idade" id="idade" class="inputUser" value="<?php echo $idade ?>">

            <label>Endereço:</label>
            <input type="text" name="endereco" id="endereco" class="inputUser" value="<?php echo $endereco ?>">
        </div>

        <div class="form-group">

            <label>CEP:</label>
            <input type="text" name="cep" id="cep" class="inputUser" value="<?php echo $cep ?>">

            <label>Bairro:</label>
            <input type="text" name="bairro" id="bairro" class="inputUser" value="<?php echo $bairro ?>">

            <label>Cidade:</label>
            <input type="text" name="cidade" id="cidade" class="inputUser" value="<?php echo $cidade ?>">

            <label for="text">Estado</label>
            <select name="estado">
                <option value="<?php echo $estado ?>"><?php echo $estado ?></option>
                <option value="AC">AC</option>
                <option value="AL">AL</option>
                <option value="AP">AP</option>
                <option value="AM">AM</option>
                <option value="BA">BA</option>
                <option value="BA">CE</option>
                <option value="CE">ES</option>
                <option value="GO">GO</option>
                <option value="MA">MA</option>
                <option value="MT">MT</option>
                <option value="MS">MS</option>
                <option value="MG">MG</option>
                <option value="PA">PA</option>
                <option value="PB">PB</option>
                <option value="PR">PR</option>
                <option value="PE">PE</option>
                <option value="PI">PI</option>
                <option value="RJ">RJ</option>
                <option value="RN">RN</option>
                <option value="RS">RS</option>
                <option value="RO">RO</option>
                <option value="RR">RR</option>
                <option value="SC">SC</option>
                <option value="SP">SP</option>
                <option value="SE">SE</option>
                <option value="TO">TO</option>
                <option value="DF">DF</option>
            </select>

        </div>


        <div class="form-group">
            <label>Tel.Res.</label>
            <input type="text" name="telefone_residencial" id="telefone_residencial" class="inputUser" value="<?php echo $telefone_residencial ?>">

            <label>Tel.Com.</label>
            <input type="text" name="telefone_comercial" id="telefone_comercial" class="inputUser" value="<?php echo $telefone_comercial ?>">

            <label>Cel.</label>
            <input type="text" name="celular" id="celular" class="inputUser" value="<?php echo $celular ?>">

            <label>Escolaridade:</label>
            <select name="escolaridade">
                <option value="<?php echo $escolaridade ?>"><?php echo $escolaridade ?></option>
                <option value="Ensino Fundamental">Ensino Fundamental</option>
                <option value="Ensino Médio">Ensino Médio</option>
                <option value="Curso Técnico">Curso Técnico</option>
                <option value="Universidade">Universidade</option>
                <option value="Pós-Graduação">Pós-Graduação</option>
                <option value="Mestrado">Mestrado</option>
                <option value="Doutorado">Doutorado</option>
                <option value="Pós-Doutorado">Pós-Doutorado</option>
            </select>

        </div>

        <div class="form-group">

            <input required type="radio" name="escolaridade_completa" id="escolaridade_completa" value="1" <?php echo ($escolaridade_completa == '1') ? 'checked' : ''; ?>>
            <label>Completo</label>

            <input required type="radio" name="escolaridade_completa" id="escolaridade_completa" value="0" <?php echo ($escolaridade_completa == '0') ? 'checked' : ''; ?>>
            <label>Incompleto</label>

            <label>Profissão:</label>
            <input type="text" name="profissao" id="profissao" class="inputUser" value="<?php echo $profissao ?>">

            <label>Estado Civil:</label>
            <input type="text" name="estado_civil" id="estado_civil" class="inputUser" value="<?php echo $estado_civil ?>">

        </div>


        <div class="container">
            <h1>HÁBITOS DIÁRIOS</h1>
        </div>

        <div class="container3">

        <div class="elemento">

        <label>Exposição ao sol:</label>
            <input type="radio" name="exposicao_ao_sol" value="1" id="exposicao_ao_sol_sim" <?php echo ($exposicao_ao_sol == '1') ? 'checked' : ''; ?>> Sim
            <input type="radio" name="exposicao_ao_sol" value="0" id="exposicao_ao_sol_nao" <?php echo ($exposicao_ao_sol == '0') ? 'checked' : ''; ?>> Não

        </div>

            <div class="elemento">
            <label>Filtro solar:</label>
            <input type="radio" name="filtro_solar" value="Sim" id="filtro_solar" <?php echo ($filtro_solar == 'Sim') ? 'checked' : ''; ?>> Sim
            <input type="radio" name="filtro_solar" value="Não" id="filtro_solar" <?php echo ($filtro_solar == 'Não') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label><span>Frequência:</span></label>
                <input type="text" name="frequencia_filtro_solar" id="frequencia_filtro_solar" class="inputUser" value="<?php echo $frequencia_filtro_solar ?>">
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Faz uso de chapéu ou bonés diariamente?</label>
                    <input type="radio" name="usa_chapeu" value="Sim" id="usa_chapeu" <?php echo ($usa_chapeu == 'Sim') ? 'checked' : ''; ?>> Sim
                    <input type="radio" name="usa_chapeu" value="Não" id="usa_chapeu" <?php echo ($usa_chapeu == 'Não') ? 'checked' : ''; ?>> Não
                </div>

            <div class="elemento">
                <label>Utilização de cosméticos capilares:</label>
                <input type="radio" name="usa_cosmeticos" value="Sim" id="usa_cosmeticos" value="Sim" <?php echo ($usa_cosmeticos == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_cosmeticos" value="Não" id="usa_cosmeticos" value="Não" <?php echo ($usa_cosmeticos == 'Não') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label>Qual (is):</label>
                <input type="text" name="cosmeticos_capilares" id="cosmeticos_capilares" class="inputUser" value="<?php echo $cosmeticos_capilares ?>">
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Uso de isotretinoína ou derivado da vitamina A tópica ou oral</label>
                <input type="radio" name="usa_isotretinoina" value="Sim" id="usa_isotretinoina" value="Sim" <?php echo ($usa_isotretinoina == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_isotretinoina" value="Não" id="usa_isotretinoina" value="Não" <?php echo ($usa_isotretinoina == 'Não') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label>Utilização de cosméticos fotossensibilizantes:</label>
                <input type="radio" name="usa_fotossensibilizantes" value="Sim" id="usa_fotossensibilizantes" value="Sim" <?php echo ($usa_fotossensibilizantes == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_fotossensibilizantes" value="Não" id="usa_fotossensibilizantes" value="Não" <?php echo ($usa_fotossensibilizantes == 'Não') ? 'checked' : ''; ?>> Não
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Qual:</label>
                <input type="text" name="fotossensibilizantes" id="fotossensibilizantes" class="inputUser" value="<?php echo $fotossensibilizantes ?>">
            </div>

            <div class="elemento">
                <label>Usa lentes de contato:</label>
                <input type="radio" name="usa_lentes" value="Sim" id="usa_lentes" value="Sim" <?php echo ($usa_lentes == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_lentes" value="Não" id="usa_lentes" value="Não" <?php echo ($usa_lentes == 'Não') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label>Tabagismo:</label>
                <input type="radio" name="tabagismo" value="Sim" id="tabagismo" value="Sim" <?php echo ($tabagismo == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="tabagismo" value="Não" id="tabagismo" value="Não" <?php echo ($tabagismo == 'Não') ? 'checked' : ''; ?>> Não
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Quantidade de cigarros/dia:</label>
                <input type="text" name="quantidade_cigarros" id="quantidade_cigarros" class="inputUser" value="<?php echo $quantidade_cigarros ?>">
            </div>

            <div class="elemento">
                <label>Ingere bebida alcoólica:</label>
                <input type="radio" name="ingere_bebida" value="Sim" id="ingere_bebida" value="Sim" <?php echo ($ingere_bebida == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="ingere_bebida" value="Não" id="ingere_bebida" value="Não" <?php echo ($ingere_bebida == 'Não') ? 'checked' : ''; ?>> Não
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Frequência:</label>
                <input type="text" name="frequencia_bebida" id="frequencia_bebida" class="inputUser" value="<?php echo $frequencia_bebida ?>">
            </div>

            <div class="elemento">
                <label>Qualidade do sono:</label>
                <input required type="radio" name="qualidade_sono" value="Boa" <?php echo ($qualidade_sono == 'Boa') ? 'checked' : ''; ?>> Boa
                <input required type="radio" name="qualidade_sono" value="Regular" <?php echo ($qualidade_sono == 'Regular') ? 'checked' : ''; ?>> Regular
                <input required type="radio" name="qualidade_sono" value="Péssima" <?php echo ($qualidade_sono == 'Péssima') ? 'checked' : ''; ?>> Péssima
            </div>

            <div class="elemento">
                <label>Quantas horas / noite:</label>
                <input type="text" name="horas_sono" id="horas_sono" class="inputUser" value="<?php echo $horas_sono ?>">
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Ingestão de água (copos / dia):</label>
                <input type="text" name="ingestao_agua_dia" id="ingestao_agua_dia" class="inputUser" value="<?php echo $ingestao_agua_dia ?>">
            </div>

            <div class="elemento">
                <label>Alimentação:</label>
                <input type="radio" name="alimentacao" value="Boa" <?php echo ($qualidade_sono == 'Boa') ? 'checked' : ''; ?>> Boa
                <input type="radio" name="alimentacao" value="Regular" <?php echo ($qualidade_sono == 'Regular') ? 'checked' : ''; ?>> Regular
                <input type="radio" name="alimentacao" value="Péssima" <?php echo ($qualidade_sono == 'Péssima') ? 'checked' : ''; ?>> Péssima
            </div>

        </div>

        <div class="container3">

            <div class="elemento">
                <label>Está fazendo algum tipo de dieta alimentar rigorosa?</label>
                <input type="radio" name="faz_dieta" value="Sim" id="faz_dieta" value="Sim" <?php echo ($faz_dieta == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="faz_dieta" value="Não" id="faz_dieta" value="Não" <?php echo ($faz_dieta == 'Não') ? 'checked' : ''; ?>> Não
            </div>
        </div>


        <div class="container">
            <h1>HISTÓRICO CLÍNICO E AVALIAÇÃO CUTÂNEA</h1>

        </div>
        <div class="container3">

            <div class="elemento">

                <label>Alguma patologia de pele:</label>
                <input type="radio" name="patologia_de_pele" value="Sim" id="patologia_de_pele" value="Sim" <?php echo ($patologia_de_pele == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="patologia_de_pele" value="Não" id="patologia_de_pele" value="Não" <?php echo ($patologia_de_pele == 'Não') ? 'checked' : ''; ?>> Não
            </div>

            <div class="elemento">
                <label>Qual:</label>
                <input type="radio" name="patologia" value="Acne" <?php echo ($patologia == 'Acne') ? 'checked' : ''; ?>> Acne

                <input type="radio" name="patologia" value="Psoríase" <?php echo ($patologia == 'Psoríase') ? 'checked' : ''; ?>> Psoríase

                <input type="radio" name="patologia" value="Vitiligo" <?php echo ($patologia == 'Vitiligo') ? 'checked' : ''; ?>> Vitiligo

                <input type="radio" name="patologia" value="Nenhum" <?php echo ($patologia == 'Nenhum') ? 'checked' : ''; ?>> Nenhum
            </div>

            <div class="elemento">
                <label>Outra:</label>
                <input type="text" name="outra_patologia" id="outra_patologia" class="inputUser" value="<?php echo $outra_patologia ?>">
            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Está realizando algum procedimento estético facial atualmente?</label>
                <input type="radio" name="faz_procedimento_estetico" value="Sim" id="faz_procedimento_estetico" value="Sim" <?php echo ($faz_procedimento_estetico == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="faz_procedimento_estetico" value="Não" id="faz_procedimento_estetico" value="Não" <?php echo ($faz_procedimento_estetico == 'Não') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Alterações na tireoide:</label>
                <input type="radio" name="alteracoes_tireoide" value="Sim" id="alteracoes_tireoide" value="Sim" <?php echo ($alteracoes_tireoide == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="alteracoes_tireoide" value="Não" id="alteracoes_tireoide" value="Não" <?php echo ($alteracoes_tireoide == 'Não') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Hipotiroidismo:</label>
                <input type="radio" name="hipotireoidismo" value="Sim" id="hipotireoidismo" value="Sim" <?php echo ($hipotireoidismo == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="hipotireoidismo" value="Não" id="hipotireoidismo" value="Não" <?php echo ($hipotireoidismo == 'Não') ? 'checked' : ''; ?>> Não


            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>hipertireoidismo:</label>
                <input type="radio" name="hipertireoidismo" id="hipertireoidismo" value="1" <?php echo ($hipertireoidismo == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="hipertireoidismo" id="hipertireoidismo" value="0" <?php echo ($hipertireoidismo == '0') ? 'checked' : ''; ?>> Não


            </div>

            <div class="elemento">

                <label>Toma medicação?</label>
                <input type="radio" name="toma_medicacao" value="Sim" id="toma_medicacao" value="Sim" <?php echo ($toma_medicacao == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="toma_medicacao" value="Não" id="toma_medicacao" value="Não" <?php echo ($toma_medicacao == 'Não') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Qual?</label>
                <input type="text" name="medicacao" id="medicacao" class="inputUser" value="<?php echo $medicacao ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>há quanto tempo?</label>
                <input type="text" name="tempo_medicacao" id="tempo_medicacao" class="inputUser" value="<?php echo $tempo_medicacao ?>">

            </div>

            <div class="elemento">

                <label>Usa algum suplemento oral?</label>
                <input type="radio" name="usa_suplemento_oral" value="Sim" id="toma_medicacao" value="Sim" <?php echo ($toma_medicacao == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="usa_suplemento_oral" value="Não" id="toma_medicacao" value="Não" <?php echo ($toma_medicacao == 'Não') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Qual?</label>
                <input type="text" name="suplemento_oral" id="suplemento_oral" class="inputUser" value="<?php echo $suplemento_oral ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Antecedentes oncológicos:</label>
                <input type="radio" name="tem_antecedentes_oncologicos" value="Sim" id="tem_antecedentes_oncologicos" value="Sim" <?php echo ($tem_antecedentes_oncologicos == '1') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="tem_antecedentes_oncologicos" value="Não" id="tem_antecedentes_oncologicos" value="Não" <?php echo ($tem_antecedentes_oncologicos == '0') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Qual:</label>
                <input type="text" name="antecedentes_oncologicos" id="antecedentes_oncologicos" class="inputUser" value="<?php echo $antecedentes_oncologicos ?>">

            </div>

            <div class="elemento">

                <label>Tem diabetes?</label>
                <input type="radio" name="tem_diabetes" value="Sim" id="tem_diabetes" value="Sim" <?php echo ($tem_diabetes == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="tem_diabetes" value="Não" id="tem_diabetes" value="Não" <?php echo ($tem_diabetes == 'Não') ? 'checked' : ''; ?>> Não

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Cirurgia Plástica Estética:</label>
                <input type="radio" name="fez_cirurgia_plastica_estetica" value="Sim" id="fez_cirurgia_plastica_estetica" value="Sim" <?php echo ($fez_cirurgia_plastica_estetica == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="fez_cirurgia_plastica_estetica" value="Não" id="fez_cirurgia_plastica_estetica" value="Não" <?php echo ($fez_cirurgia_plastica_estetica == 'Não') ? 'checked' : ''; ?>> Não

            </div>

            <div class="elemento">

                <label>Qual:</label>
                <input type="text" name="cirurgia_plastica_estetica" id="cirurgia_plastica_estetica" class="inputUser" value="<?php echo $cirurgia_plastica_estetica ?>">

            </div>

            <div class="elemento">

                <label>Com relação a alopecia;</label>
                <label>Qual a queixa principal?</label>
                <input type="text" name="queixa_alopecia" id="queixa_alopecia" class="inputUser" value="<?php echo $queixa_alopecia ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>A doença acomete outras partes do corpo?</label>
                <input type="radio" name="alopecia_acomete_corpo" value="Não" id="alopecia_acomete_corpo" value="Sim" <?php echo ($tem_diabetes == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="alopecia_acomete_corpo" value="Sim" id="alopecia_acomete_corpo" value="Não" <?php echo ($tem_diabetes == 'Não') ? 'checked' : ''; ?>> Não

                <br>
                </br>

            </div>

            <div class="elemento">

                <label>Quais?</label>
                <input type="text" name="partes_acometidas" id="partes_acometidas" class="inputUser" value="<?php echo $partes_acometidas ?>">

            </div>

            <div class="elemento">

                <label>Há quanto tempo começou a disfunção?</label>
                <input type="text" name="tempo_disfuncao" id="tempo_disfuncao" class="inputUser" value="<?php echo $tempo_disfuncao ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>A disfunção está:</label>
                <input type="radio" name="estado_disfuncao" value="estavel" <?php echo ($estado_disfuncao == 'estavel') ? 'checked' : ''; ?>> Estável
                <input type="radio" name="estado_disfuncao" value="aumentando" <?php echo ($estado_disfuncao == 'aumentando') ? 'checked' : ''; ?>> Aumentando
                <input type="radio" name="estado_disfuncao" value="diminuindo" <?php echo ($estado_disfuncao == 'diminuindo') ? 'checked' : ''; ?>> Diminuindo

            </div>

        </div>


        <p></p>
        <div class="container2">
            <img src="../imagens/MEDIDAS-removebg-preview.png">


            <table style="margin-bottom:100px;">
                <thead>
                    <tr>
                        <th colspan="4" style="text-align: center;">Medidas</th>
                    </tr>
                </thead>

                <tr>
                    <th></th>
                    <th>Início</th>
                    <th>Meio</th>
                    <th>Fim</th>
                </tr>
             <tr>
             <tr>
            <th>Peso</th>
                <td contenteditable="true" data-name="peso_inicio"><?php echo isset($peso_inicio) ? $peso_inicio : ''; ?></td>
                <td contenteditable="true" data-name="peso_meio"><?php echo isset($peso_meio) ? $peso_meio : ''; ?></td>
                <td contenteditable="true" data-name="peso_fim"><?php echo isset($peso_fim) ? $peso_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Busto</th>
                <td contenteditable="true" data-name="busto_inicio"><?php echo isset($busto_inicio) ? $busto_inicio : ''; ?></td>
                <td contenteditable="true" data-name="busto_meio"><?php echo isset($busto_meio) ? $busto_meio : ''; ?></td>
                <td contenteditable="true" data-name="busto_fim"><?php echo isset($busto_fim) ? $busto_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Braço Esquerdo</th>
                <td contenteditable="true" data-name="braco_esq_inicio"><?php echo isset($braco_esq_inicio) ? $braco_esq_inicio : ''; ?></td>
                <td contenteditable="true" data-name="braco_esq_meio"><?php echo isset($braco_esq_meio) ? $braco_esq_meio : ''; ?></td>
                <td contenteditable="true" data-name="braco_esq_fim"><?php echo isset($braco_esq_fim) ? $braco_esq_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Braço Direito</th>
                <td contenteditable="true" data-name="braco_dir_inicio"><?php echo isset($braco_dir_inicio) ? $braco_dir_inicio : ''; ?></td>
                <td contenteditable="true" data-name="braco_dir_meio"><?php echo isset($braco_dir_meio) ? $braco_dir_meio : ''; ?></td>
                <td contenteditable="true" data-name="braco_dir_fim"><?php echo isset($braco_dir_fim) ? $braco_dir_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Abdomen</th>
                <td contenteditable="true" data-name="abdomen_inicio"><?php echo isset($abdomen_inicio) ? $abdomen_inicio : ''; ?></td>
                <td contenteditable="true" data-name="abdomen_meio"><?php echo isset($abdomen_meio) ? $abdomen_meio : ''; ?></td>
                <td contenteditable="true" data-name="abdomen_fim"><?php echo isset($abdomen_fim) ? $abdomen_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Cintura</th>
                <td contenteditable="true" data-name="cintura_inicio"><?php echo isset($cintura_inicio) ? $cintura_inicio : ''; ?></td>
                <td contenteditable="true" data-name="cintura_meio"><?php echo isset($cintura_meio) ? $cintura_meio : ''; ?></td>
                <td contenteditable="true" data-name="cintura_fim"><?php echo isset($cintura_fim) ? $cintura_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Quadril</th>
                <td contenteditable="true" data-name="quadril_inicio"><?php echo isset($quadril_inicio) ? $quadril_inicio : ''; ?></td>
                <td contenteditable="true" data-name="quadril_meio"><?php echo isset($quadril_meio) ? $quadril_meio : ''; ?></td>
                <td contenteditable="true" data-name="quadril_fim"><?php echo isset($quadril_fim) ? $quadril_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Culote</th>
                <td contenteditable="true" data-name="culote_inicio"><?php echo isset($culote_inicio) ? $culote_inicio : ''; ?></td>
                <td contenteditable="true" data-name="culote_meio"><?php echo isset($culote_meio) ? $culote_meio : ''; ?></td>
                <td contenteditable="true" data-name="culote_fim"><?php echo isset($culote_fim) ? $culote_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Coxa Esquerda</th>
                <td contenteditable="true" data-name="coxa_esq_inicio"><?php echo isset($coxa_esq_inicio) ? $coxa_esq_inicio : ''; ?></td>
                <td contenteditable="true" data-name="coxa_esq_meio"><?php echo isset($coxa_esq_meio) ? $coxa_esq_meio : ''; ?></td>
                <td contenteditable="true" data-name="coxa_esq_fim"><?php echo isset($coxa_esq_fim) ? $coxa_esq_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Coxa Direita</th>
                <td contenteditable="true" data-name="coxa_dir_inicio"><?php echo isset($coxa_dir_inicio) ? $coxa_dir_inicio : ''; ?></td>
                <td contenteditable="true" data-name="coxa_dir_meio"><?php echo isset($coxa_dir_meio) ? $coxa_dir_meio : ''; ?></td>
                <td contenteditable="true" data-name="coxa_dir_fim"><?php echo isset($coxa_dir_fim) ? $coxa_dir_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Panturrilha Esquerda</th>
                <td contenteditable="true" data-name="panturrilha_esq_inicio"><?php echo isset($panturrilha_esq_inicio) ? $panturrilha_esq_inicio : ''; ?></td>
                <td contenteditable="true" data-name="panturrilha_esq_meio"><?php echo isset($panturrilha_esq_meio) ? $panturrilha_esq_meio : ''; ?></td>
                <td contenteditable="true" data-name="panturrilha_esq_fim"><?php echo isset($panturrilha_esq_fim) ? $panturrilha_esq_fim : ''; ?></td>
            </tr>

            <tr>
                <th>Panturrilha Direita</th>
                <td contenteditable="true" data-name="panturrilha_dir_inicio"><?php echo isset($panturrilha_dir_inicio) ? $panturrilha_dir_inicio : ''; ?></td>
                <td contenteditable="true" data-name="panturrilha_dir_meio"><?php echo isset($panturrilha_dir_meio) ? $panturrilha_dir_meio : ''; ?></td>
                <td contenteditable="true" data-name="panturrilha_dir_fim"><?php echo isset($panturrilha_dir_fim) ? $panturrilha_dir_fim : ''; ?></td>
            </tr>

            <tr>
                <th>IMC</th>
                <td contenteditable="true" data-name="imc_inicio"><?php echo isset($imc_inicio) ? $imc_inicio : ''; ?></td>
                <td contenteditable="true" data-name="imc_meio"><?php echo isset($imc_meio) ? $imc_meio : ''; ?></td>
                <td contenteditable="true" data-name="imc_fim"><?php echo isset($imc_fim) ? $imc_fim : ''; ?></td>
            </tr>
            </table>

        </div>

        <div class="container3">

            <div class="elemento">

                <label>Biotipo Corporal:</label>
                <input type="radio" name="biotipo_corporal" value="Ectomorfo" <?php echo ($biotipo_corporal == 'Ectomorfo') ? 'checked' : ''; ?>> Ectomorfo
                <input type="radio" name="biotipo_corporal" value="Mesomorfo" <?php echo ($biotipo_corporal == 'Mesomorfo') ? 'checked' : ''; ?>> Mesomorfo
                <input type="radio" name="biotipo_corporal" value="Endomorfo" <?php echo ($biotipo_corporal == 'Endomorfo') ? 'checked' : ''; ?>> Endomorfo

            </div>

            <div class="elemento">

                <label>Distribuição de Gordura:</label>
                <input type="radio" name="distribuicao_gordura" value="Andróide" <?php echo ($distribuicao_gordura == 'Andróide') ? 'checked' : ''; ?>> Andróide
                <input type="radio" name="distribuicao_gordura" value="Ginóide" <?php echo ($distribuicao_gordura == 'Ginóide') ? 'checked' : ''; ?>> Ginóide

            </div>

            <div class="elemento">

                <label>Presença de Diástase Abdominal:</label>
                <input type="radio" name="presenca_diastase" value="Sim" <?php echo ($presenca_diastase == 'Sim') ? 'checked' : ''; ?>> Sim
                <input type="radio" name="presenca_diastase" value="Não" <?php echo ($presenca_diastase == 'Não') ? 'checked' : ''; ?>> Não

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Tipo de Gordura:</label>
                <input type="radio" name="tipo_gordura" value="Flácida" <?php echo ($tipo_gordura == 'Flácida') ? 'checked' : ''; ?>> Flácida
                <input type="radio" name="tipo_gordura" value="Compacta" <?php echo ($tipo_gordura == 'Compacta') ? 'checked' : ''; ?>> Compacta

            </div>

            <div class="elemento">

                <label>Região:</label>
                <input type="text" name="regiao_gordura" id="regiao_gordura" class="inputUser" value="<?php echo $regiao_gordura ?>">

            </div>

            <div class="elemento">

                <label>Observações:</label>
                <input type="text" name="observacoes_gordura" id="observacoes_gordura" class="inputUser" value="<?php echo $observacoes_gordura ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Tipo de Flacidez:</label>
                <input type="radio" name="tipo_flacidez" value="Dérmica" <?php echo ($tipo_flacidez == 'Dérmica') ? 'checked' : ''; ?>> Dérmica
                <input type="radio" name="tipo_flacidez" value="Compacta" <?php echo ($tipo_flacidez == 'Compacta') ? 'checked' : ''; ?>> Muscular

            </div>

            <div class="elemento">

                <label>Região:</label>
                <input type="text" name="regiao_flacidez" id="regiao_flacidez" class="inputUser" value="<?php echo $regiao_flacidez ?>">

            </div>

            <div class="elemento">

                <label>Observações:</label>
                <input type="text" name="observacoes_flacidez" id="observacoes_flacidez" class="inputUser" value="<?php echo $observacoes_flacidez ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Grau de HLDG:</label>
                <input type="radio" name="grau_hldg" value="GrauI" <?php echo ($grau_hldg == 'GrauI') ? 'checked' : ''; ?>> Grau I
                <input type="radio" name="grau_hldg" value="GrauII" <?php echo ($grau_hldg == 'GrauII') ? 'checked' : ''; ?>> Grau II
                <input type="radio" name="grau_hldg" value="GrauIII" <?php echo ($grau_hldg == 'GrauIII') ? 'checked' : ''; ?>> Grau III
                <input type="radio" name="grau_hldg" value="GrauIV" <?php echo ($grau_hldg == 'GrauIV') ? 'checked' : ''; ?>> Grau IV

            </div>

            <div class="elemento">

                <label>Tipo de HLDG:</label>
                <input type="radio" name="tipo_hldg" value="Flácida" <?php echo ($tipo_hldg == 'Flácida') ? 'checked' : ''; ?>> Flácida
                <input type="radio" name="tipo_hldg" value="Compacta" <?php echo ($tipo_hldg == 'Compacta') ? 'checked' : ''; ?>> Compacta

            </div>

            <div class="elemento">

                <label>Região:</label>
                <input type="text" name="regiao_hldg" id="regiao_hldg" class="inputUser" value="<?php echo $regiao_hldg ?>">

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Observações:</label>
                <input type="text" name="observacoes_hldg" id="observacoes_hldg" class="inputUser" value="<?php echo $observacoes_hldg ?>">

            </div>

            <div class="elemento">

                <label>Tipo de estrias:</label>
                <input type="radio" name="tipo_estrias" value="Vermelhas" <?php echo ($tipo_estrias == 'Vermelhas') ? 'checked' : ''; ?>> Vermelhas
                <input type="radio" name="tipo_estrias" value="Violáceas" <?php echo ($tipo_estrias == 'Violáceas') ? 'checked' : ''; ?>> Violáceas
                <input type="radio" name="tipo_estrias" value="Brancas" <?php echo ($tipo_estrias == 'Brancas') ? 'checked' : ''; ?>> Brancas
                <input type="radio" name="tipo_estrias" value="Nacaradas" <?php echo ($tipo_estrias == 'Nacaradas') ? 'checked' : ''; ?>> Nacaradas

            </div>

            <div class="elemento">

                <label>Larguras:</label>
                <input type="radio" name="largura_estria" value="Finas" <?php echo ($largura_estria == 'Finas') ? 'checked' : ''; ?>> Finas
                <input type="radio" name="largura_estria" value="Largas" <?php echo ($largura_estria == 'Largas') ? 'checked' : ''; ?>> Largas
                <input type="radio" name="largura_estria" value="Variadas" <?php echo ($largura_estria == 'Variadas') ? 'checked' : ''; ?>> Variadas

            </div>

        </div>


        <div class="container3">

            <div class="elemento">

                <label>Observações:</label>
                <input type="text" name="observacoes_estrias" id="observacoes_estrias" class="inputUser" value="<?php echo $observacoes_estrias ?>">

            </div>

        </div>

        <div class="campo">
            <br>
            <h2>
                <label for="experiencia"><strong>Relatório: </strong></label>
                <textarea rows="6" style="width: 26em" id="experiencia" name="experiencia"><?php echo htmlspecialchars($experiencia); ?></textarea>
            </h2>
        </div>


        <h2>TERMO DE RESPONSABILIDADE</h2>
        <p>Eu <input type="text" name=assinatura id="assinatura" class="inputUser" value="<?php echo $assinatura ?>">, comprometo-me a seguir todas as orientações e a seguir minha prescrição domiciliar. As declarações acima são verdadeiras, não cabendo ao profissional a responsabilidade por informações por mim omitidas.</p>
        <div class="form-group">
            <center>
                <label>Assinatura do paciente</label>
                <input type="text" name="assinatura_paciente" id="assinatura_paciente" class="inputUser" value="<?php echo $assinatura_paciente ?>">
                <label>Data</label>
                <input type="date" name="data_assinatura_paciente" id="assinatura" class="inputUser" value="<?php echo $data_assinatura_paciente ?>">
        </div>
        </center>


        <center>
        <div class="form-group">
            <label>Nome e Assinatura do Profissional</label>
            <input type="text" name="nome_profissional" id="nome_profissional" class="inputUser" value="<?php echo $nome_profissional ?>">
            <br></br>
            <label>Data</label>
            <input type="date" name="data_assinatura_profissional" id="data_assinatura_profissional" class="inputUser" value="<?php echo $data_assinatura_profissional ?>">
        </div>
        </center>
        
        <br></br>

        <center>
            
                <button class="button" type="button" onclick="submitForm()">Enviar</button>
            
        </center>
    </div>
    </center>

    </div>

    </form>


    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script>
        function submitForm(event) {
            var cells = document.querySelectorAll('[contenteditable=true]');

            cells.forEach(function(cell) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = cell.getAttribute('data-name');
                input.value = cell.innerText.trim();
                if (cell.getAttribute('data-name') && cell.innerText.trim() !== '') {
                    document.getElementById('anamnese_corporal').appendChild(input);
                }
            });

            document.getElementById('anamnese_corporal').submit();
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

    <script>
        $('#celular').mask('(00) 00000-0000');
        $('#telefone_residencial').mask('(00) 0000-0000');
        $('#telefone_comercial').mask('(00) 0000-0000');
        $('#cep').mask('00000-000');
        $('#cpf').mask('000.000.000-00', {
            reverse: true
        });
        $('#date_time').mask('00/00/0000 00:00:00');
    </script>

</body>

</html>