<?php
include_once('../conexao.php');

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lista de campos esperados
    $expected_fields = array(
        'nome_completo', 'data_nascimento', 'idade', 'endereco', 'cep', 'bairro', 'cidade', 'estado', 'telefone_residencial',
        'telefone_comercial', 'celular', 'escolaridade', 'escolaridade_completa', 'profissao', 'estado_civil', 'exposicao_ao_sol',
        'filtro_solar', 'frequencia_filtro_solar', 'usa_chapeu', 'usa_cosmeticos', 'cosmeticos_capilares', 'usa_isotretinoina',
        'usa_fotossensibilizantes', 'fotossensibilizantes', 'usa_lentes', 'tabagismo', 'quantidade_cigarros', 'ingere_bebida',
        'frequencia_bebida', 'qualidade_sono', 'horas_sono', 'ingestao_agua_dia', 'alimentacao', 'faz_dieta', 'patologia_de_pele',
        'patologia', 'outra_patologia', 'faz_procedimento_estetico', 'alteracoes_tireoide', 'hipotireoidismo', 'hipertireoidismo',
        'toma_medicacao', 'medicacao', 'tempo_medicacao', 'usa_suplemento_oral', 'suplemento_oral', 'tem_antecedentes_oncologicos',
        'antecedentes_oncologicos', 'tem_diabetes', 'fez_cirurgia_plastica_estetica', 'cirurgia_plastica_estetica', 'queixa_alopecia',
        'alopecia_acomete_corpo', 'partes_acometidas', 'tempo_disfuncao', 'estado_disfuncao', 'peso_inicio', 'peso_meio', 'peso_fim',
        'busto_inicio', 'busto_meio', 'busto_fim', 'braco_esq_inicio', 'braco_esq_meio', 'braco_esq_fim', 'braco_dir_inicio',
        'braco_dir_meio', 'braco_dir_fim', 'abdomen_inicio', 'abdomen_meio', 'abdomen_fim', 'cintura_inicio', 'cintura_meio', 'cintura_fim',
        'quadril_inicio', 'quadril_meio', 'quadril_fim', 'culote_inicio', 'culote_meio', 'culote_fim','coxa_esq_inicio', 'coxa_esq_meio', 'coxa_esq_fim', 'coxa_dir_inicio',
        'coxa_dir_meio', 'coxa_dir_fim', 'panturrilha_esq_inicio', 'panturrilha_esq_meio', 'panturrilha_esq_fim', 'panturrilha_dir_inicio', 'panturrilha_dir_meio',
        'panturrilha_dir_fim','imc_inicio', 'imc_meio', 'imc_fim', 'biotipo_corporal', 'distribuicao_gordura', 'presenca_diastase', 'tipo_gordura',
        'regiao_gordura', 'observacoes_gordura', 'tipo_flacidez', 'regiao_flacidez', 'observacoes_flacidez', 'grau_hldg',
        'tipo_hldg', 'regiao_hldg', 'observacoes_hldg', 'tipo_estrias', 'largura_estria', 'observacoes_estrias', 'experiencia', 'assinatura', 'assinatura_paciente', 'data_assinatura_paciente',
        'nome_profissional', 'data_assinatura_profissional'
    );

    // Verifica se todos os campos estão presentes
    // foreach ($expected_fields as $field) {
    //     if (!isset($_POST[$field])) {
    //         die("Dados incompletos. Campo não encontrado: $field");
    //     }
    // }

    // Recupera os dados do formulário
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $nome_completo = isset($_POST['nome_completo']) ? $_POST['nome_completo'] : '';
    $data_nascimento = isset($_POST['data_nascimento']) ? $_POST['data_nascimento'] : '';
    $idade = isset($_POST['idade']) ? $_POST['idade'] : '';
    $endereco = isset($_POST['endereco']) ? $_POST['endereco'] : '';
    $cep = isset($_POST['cep']) ? $_POST['cep'] : '';
    $bairro = isset($_POST['bairro']) ? $_POST['bairro'] : '';
    $cidade = isset($_POST['cidade']) ? $_POST['cidade'] : '';
    $estado = isset($_POST['estado']) ? $_POST['estado'] : '';
    $telefone_residencial = isset($_POST['telefone_residencial']) ? $_POST['telefone_residencial'] : '';
    $telefone_comercial = isset($_POST['telefone_comercial']) ? $_POST['telefone_comercial'] : '';
    $celular = isset($_POST['celular']) ? $_POST['celular'] : '';
    $escolaridade = isset($_POST['escolaridade']) ? $_POST['escolaridade'] : '';
    $escolaridade_completa = isset($_POST['escolaridade_completa']) ? $_POST['escolaridade_completa'] : '';
    $profissao = isset($_POST['profissao']) ? $_POST['profissao'] : '';
    $estado_civil = isset($_POST['estado_civil']) ? $_POST['estado_civil'] : '';
    $exposicao_ao_sol = isset($_POST['exposicao_ao_sol']) ? $_POST['exposicao_ao_sol'] : '';
    $filtro_solar = isset($_POST['filtro_solar']) ? $_POST['filtro_solar'] : '';
    $frequencia_filtro_solar = isset($_POST['frequencia_filtro_solar']) ? $_POST['frequencia_filtro_solar'] : '';
    $usa_chapeu = isset($_POST['usa_chapeu']) ? $_POST['usa_chapeu'] : '';
    $usa_cosmeticos = isset($_POST['usa_cosmeticos']) ? $_POST['usa_cosmeticos'] : '';
    $cosmeticos_capilares = isset($_POST['cosmeticos_capilares']) ? $_POST['cosmeticos_capilares'] : '';
    $usa_isotretinoina = isset($_POST['usa_isotretinoina']) ? $_POST['usa_isotretinoina'] : '';
    $usa_fotossensibilizantes = isset($_POST['usa_fotossensibilizantes']) ? $_POST['usa_fotossensibilizantes'] : '';
    $fotossensibilizantes = isset($_POST['fotossensibilizantes']) ? $_POST['fotossensibilizantes'] : '';
    $usa_lentes = isset($_POST['usa_lentes']) ? $_POST['usa_lentes'] : '';
    $tabagismo = isset($_POST['tabagismo']) ? $_POST['tabagismo'] : '';
    $quantidade_cigarros = isset($_POST['quantidade_cigarros']) ? $_POST['quantidade_cigarros'] : '';
    $ingere_bebida = isset($_POST['ingere_bebida']) ? $_POST['ingere_bebida'] : '';
    $frequencia_bebida = isset($_POST['frequencia_bebida']) ? $_POST['frequencia_bebida'] : '';
    $qualidade_sono = isset($_POST['qualidade_sono']) ? $_POST['qualidade_sono'] : '';
    $horas_sono = isset($_POST['horas_sono']) ? $_POST['horas_sono'] : '';
    $ingestao_agua_dia = isset($_POST['ingestao_agua_dia']) ? $_POST['ingestao_agua_dia'] : '';
    $alimentacao = isset($_POST['alimentacao']) ? $_POST['alimentacao'] : '';
    $faz_dieta = isset($_POST['faz_dieta']) ? $_POST['faz_dieta'] : '';
    $patologia_de_pele = isset($_POST['patologia_de_pele']) ? $_POST['patologia_de_pele'] : '';
    $patologia = isset($_POST['patologia']) ? $_POST['patologia'] : '';
    $outra_patologia = isset($_POST['outra_patologia']) ? $_POST['outra_patologia'] : '';
    $faz_procedimento_estetico = isset($_POST['faz_procedimento_estetico']) ? $_POST['faz_procedimento_estetico'] : '';
    $alteracoes_tireoide = isset($_POST['alteracoes_tireoide']) ? $_POST['alteracoes_tireoide'] : '';
    $hipotireoidismo = isset($_POST['hipotireoidismo']) ? $_POST['hipotireoidismo'] : '';
    $hipertireoidismo = isset($_POST['hipertireoidismo']) ? $_POST['hipertireoidismo'] : '';
    $toma_medicacao = isset($_POST['toma_medicacao']) ? $_POST['toma_medicacao'] : '';
    $medicacao = isset($_POST['medicacao']) ? $_POST['medicacao'] : '';
    $tempo_medicacao = isset($_POST['tempo_medicacao']) ? $_POST['tempo_medicacao'] : '';
    $usa_suplemento_oral = isset($_POST['usa_suplemento_oral']) ? $_POST['usa_suplemento_oral'] : '';
    $suplemento_oral = isset($_POST['suplemento_oral']) ? $_POST['suplemento_oral'] : '';
    $tem_antecedentes_oncologicos = isset($_POST['tem_antecedentes_oncologicos']) ? $_POST['tem_antecedentes_oncologicos'] : '';
    $antecedentes_oncologicos = isset($_POST['antecedentes_oncologicos']) ? $_POST['antecedentes_oncologicos'] : '';
    $tem_diabetes = isset($_POST['tem_diabetes']) ? $_POST['tem_diabetes'] : '';
    $fez_cirurgia_plastica_estetica = isset($_POST['fez_cirurgia_plastica_estetica']) ? $_POST['fez_cirurgia_plastica_estetica'] : '';
    $cirurgia_plastica_estetica = isset($_POST['cirurgia_plastica_estetica']) ? $_POST['cirurgia_plastica_estetica'] : '';
    $queixa_alopecia = isset($_POST['queixa_alopecia']) ? $_POST['queixa_alopecia'] : '';
    $alopecia_acomete_corpo = isset($_POST['alopecia_acomete_corpo']) ? $_POST['alopecia_acomete_corpo'] : '';
    $partes_acometidas = isset($_POST['partes_acometidas']) ? $_POST['partes_acometidas'] : '';
    $tempo_disfuncao = isset($_POST['tempo_disfuncao']) ? $_POST['tempo_disfuncao'] : '';
    $estado_disfuncao = isset($_POST['estado_disfuncao']) ? $_POST['estado_disfuncao'] : '';
    $peso_inicio = isset($_POST['peso_inicio']) ? $_POST['peso_inicio'] : '';
    $peso_meio = isset($_POST['peso_meio']) ? $_POST['peso_meio'] : '';
    $peso_fim = isset($_POST['peso_fim']) ? $_POST['peso_fim'] : '';
    $busto_inicio = isset($_POST['busto_inicio']) ? $_POST['busto_inicio'] : '';
    $busto_meio = isset($_POST['busto_meio']) ? $_POST['busto_meio'] : '';
    $busto_fim = isset($_POST['busto_fim']) ? $_POST['busto_fim'] : '';
    $braco_esq_inicio = isset($_POST['braco_esq_inicio']) ? $_POST['braco_esq_inicio'] : '';
    $braco_esq_meio = isset($_POST['braco_esq_meio']) ? $_POST['braco_esq_meio'] : '';
    $braco_esq_fim = isset($_POST['braco_esq_fim']) ? $_POST['braco_esq_fim'] : '';
    $braco_dir_inicio = isset($_POST['braco_dir_inicio']) ? $_POST['braco_dir_inicio'] : '';
    $braco_dir_meio = isset($_POST['braco_dir_meio']) ? $_POST['braco_dir_meio'] : '';
    $braco_dir_fim = isset($_POST['braco_dir_fim']) ? $_POST['braco_dir_fim'] : '';
    $abdomen_inicio = isset($_POST['abdomen_inicio']) ? $_POST['abdomen_inicio'] : '';
    $abdomen_meio = isset($_POST['abdomen_meio']) ? $_POST['abdomen_meio'] : '';
    $abdomen_fim = isset($_POST['abdomen_fim']) ? $_POST['abdomen_fim'] : '';
    $cintura_inicio = isset($_POST['cintura_inicio']) ? $_POST['cintura_inicio'] : '';
    $cintura_meio = isset($_POST['cintura_meio']) ? $_POST['cintura_meio'] : '';
    $cintura_fim = isset($_POST['cintura_fim']) ? $_POST['cintura_fim'] : '';
    $quadril_inicio = isset($_POST['quadril_inicio']) ? $_POST['quadril_inicio'] : '';
    $quadril_meio = isset($_POST['quadril_meio']) ? $_POST['quadril_meio'] : '';
    $quadril_fim = isset($_POST['quadril_fim']) ? $_POST['quadril_fim'] : '';
    $culote_inicio = isset($_POST['culote_inicio']) ? $_POST['culote_inicio'] : '';
    $culote_meio = isset($_POST['culote_meio']) ? $_POST['culote_meio'] : '';
    $culote_fim = isset($_POST['culote_fim']) ? $_POST['culote_fim'] : '';
    $coxa_esq_inicio = isset($_POST['coxa_esq_inicio']) ? $_POST['coxa_esq_inicio'] : '';
    $coxa_esq_meio = isset($_POST['coxa_esq_meio']) ? $_POST['coxa_esq_meio'] : '';
    $coxa_esq_fim = isset($_POST['coxa_esq_fim']) ? $_POST['coxa_esq_fim'] : '';
    $coxa_dir_inicio = isset($_POST['coxa_dir_inicio']) ? $_POST['coxa_dir_inicio'] : '';
    $coxa_dir_meio = isset($_POST['coxa_dir_meio']) ? $_POST['coxa_dir_meio'] : '';
    $coxa_dir_fim = isset($_POST['coxa_dir_fim']) ? $_POST['coxa_dir_fim'] : '';
    $panturrilha_esq_inicio = isset($_POST['panturrilha_esq_inicio']) ? $_POST['panturrilha_esq_inicio'] : '';
    $panturrilha_esq_meio = isset($_POST['panturrilha_esq_meio']) ? $_POST['panturrilha_esq_meio'] : '';
    $panturrilha_esq_fim = isset($_POST['panturrilha_esq_fim']) ? $_POST['panturrilha_esq_fim'] : '';
    $panturrilha_dir_inicio = isset($_POST['panturrilha_dir_inicio']) ? $_POST['panturrilha_dir_inicio'] : '';
    $panturrilha_dir_meio = isset($_POST['panturrilha_dir_meio']) ? $_POST['panturrilha_dir_meio'] : '';
    $panturrilha_dir_fim = isset($_POST['panturrilha_dir_fim']) ? $_POST['panturrilha_dir_fim'] : '';
    $imc_inicio = isset($_POST['imc_inicio']) ? $_POST['imc_inicio'] : '';
    $imc_meio = isset($_POST['imc_meio']) ? $_POST['imc_meio'] : '';
    $imc_fim = isset($_POST['imc_fim']) ? $_POST['imc_fim'] : '';
    $biotipo_corporal = isset($_POST['biotipo_corporal']) ? $_POST['biotipo_corporal'] : '';
    $distribuicao_gordura = isset($_POST['distribuicao_gordura']) ? $_POST['distribuicao_gordura'] : '';
    $presenca_diastase = isset($_POST['presenca_diastase']) ? $_POST['presenca_diastase'] : '';
    $tipo_gordura = isset($_POST['tipo_gordura']) ? $_POST['tipo_gordura'] : '';
    $regiao_gordura = isset($_POST['regiao_gordura']) ? $_POST['regiao_gordura'] : '';
    $observacoes_gordura = isset($_POST['observacoes_gordura']) ? $_POST['observacoes_gordura'] : '';
    $tipo_flacidez = isset($_POST['tipo_flacidez']) ? $_POST['tipo_flacidez'] : '';
    $regiao_flacidez = isset($_POST['regiao_flacidez']) ? $_POST['regiao_flacidez'] : '';
    $observacoes_flacidez = isset($_POST['observacoes_flacidez']) ? $_POST['observacoes_flacidez'] : '';
    $grau_hldg = isset($_POST['grau_hldg']) ? $_POST['grau_hldg'] : '';
    $tipo_hldg = isset($_POST['tipo_hldg']) ? $_POST['tipo_hldg'] : '';
    $regiao_hldg = isset($_POST['regiao_hldg']) ? $_POST['regiao_hldg'] : '';
    $observacoes_hldg = isset($_POST['observacoes_hldg']) ? $_POST['observacoes_hldg'] : '';
    $tipo_estrias = isset($_POST['tipo_estrias']) ? $_POST['tipo_estrias'] : '';
    $largura_estria = isset($_POST['largura_estria']) ? $_POST['largura_estria'] : '';
    $observacoes_estrias = isset($_POST['observacoes_estrias']) ? $_POST['observacoes_estrias'] : '';
    $experiencia = isset($_POST['experiencia']) ? $_POST['experiencia'] : '';
    $assinatura = isset($_POST['assinatura']) ? $_POST['assinatura'] : '';
    $assinatura_paciente = isset($_POST['assinatura_paciente']) ? $_POST['assinatura_paciente'] : '';
    $data_assinatura_paciente = isset($_POST['data_assinatura_paciente']) ? $_POST['data_assinatura_paciente'] : '';
    $nome_profissional = isset($_POST['nome_profissional']) ? $_POST['nome_profissional'] : '';
    $data_assinatura_profissional = isset($_POST['data_assinatura_profissional']) ? $_POST['data_assinatura_profissional'] : '';

    // Prepara a instrução SQL para atualizar os dados no banco
    $sql = "UPDATE anamnese_corporal SET 
        nome_completo = '$nome_completo', 
        data_nascimento = '$data_nascimento', 
        idade = '$idade', 
        endereco = '$endereco', 
        cep = '$cep', 
        bairro = '$bairro', 
        cidade = '$cidade', 
        estado = '$estado', 
        telefone_residencial = '$telefone_residencial', 
        telefone_comercial = '$telefone_comercial', 
        celular = '$celular', 
        escolaridade = '$escolaridade', 
        escolaridade_completa = '$escolaridade_completa', 
        profissao = '$profissao', 
        estado_civil = '$estado_civil', 
        exposicao_ao_sol = '$exposicao_ao_sol', 
        filtro_solar = '$filtro_solar', 
        frequencia_filtro_solar = '$frequencia_filtro_solar', 
        usa_chapeu = '$usa_chapeu', 
        usa_cosmeticos = '$usa_cosmeticos', 
        cosmeticos_capilares = '$cosmeticos_capilares', 
        usa_isotretinoina = '$usa_isotretinoina', 
        usa_fotossensibilizantes = '$usa_fotossensibilizantes', 
        fotossensibilizantes = '$fotossensibilizantes', 
        usa_lentes = '$usa_lentes', 
        tabagismo = '$tabagismo', 
        quantidade_cigarros = '$quantidade_cigarros', 
        ingere_bebida = '$ingere_bebida', 
        frequencia_bebida = '$frequencia_bebida', 
        qualidade_sono = '$qualidade_sono', 
        horas_sono = '$horas_sono', 
        ingestao_agua_dia = '$ingestao_agua_dia', 
        alimentacao = '$alimentacao', 
        faz_dieta = '$faz_dieta', 
        patologia_de_pele = '$patologia_de_pele', 
        patologia = '$patologia', 
        outra_patologia = '$outra_patologia', 
        faz_procedimento_estetico = '$faz_procedimento_estetico', 
        alteracoes_tireoide = '$alteracoes_tireoide', 
        hipotireoidismo = '$hipotireoidismo', 
        hipertireoidismo = '$hipertireoidismo', 
        toma_medicacao = '$toma_medicacao', 
        medicacao = '$medicacao', 
        tempo_medicacao = '$tempo_medicacao', 
        usa_suplemento_oral = '$usa_suplemento_oral', 
        suplemento_oral = '$suplemento_oral', 
        tem_antecedentes_oncologicos = '$tem_antecedentes_oncologicos', 
        antecedentes_oncologicos = '$antecedentes_oncologicos', 
        tem_diabetes = '$tem_diabetes', 
        fez_cirurgia_plastica_estetica = '$fez_cirurgia_plastica_estetica', 
        cirurgia_plastica_estetica = '$cirurgia_plastica_estetica', 
        queixa_alopecia = '$queixa_alopecia', 
        alopecia_acomete_corpo = '$alopecia_acomete_corpo', 
        partes_acometidas = '$partes_acometidas', 
        tempo_disfuncao = '$tempo_disfuncao', 
        estado_disfuncao = '$estado_disfuncao', 
        peso_inicio = '$peso_inicio', 
        peso_meio = '$peso_meio', 
        peso_fim = '$peso_fim', 
        busto_inicio = '$busto_inicio', 
        busto_meio = '$busto_meio', 
        busto_fim = '$busto_fim', 
        braco_esq_inicio = '$braco_esq_inicio', 
        braco_esq_meio = '$braco_esq_meio', 
        braco_esq_fim = '$braco_esq_fim', 
        braco_dir_inicio = '$braco_dir_inicio', 
        braco_dir_meio = '$braco_dir_meio', 
        braco_dir_fim = '$braco_dir_fim', 
        abdomen_inicio = '$abdomen_inicio',
        abdomen_meio = '$abdomen_meio',
        abdomen_fim = '$abdomen_fim',
        cintura_inicio = '$cintura_inicio',
        cintura_meio = '$cintura_meio',
        cintura_fim = '$cintura_fim',
        quadril_inicio = '$quadril_inicio',
        quadril_meio = '$quadril_meio',
        quadril_fim = '$quadril_fim',
        culote_inicio = '$culote_inicio',
        culote_meio = '$culote_meio',
        culote_fim = '$culote_fim',
        coxa_esq_inicio = '$coxa_esq_inicio',
        coxa_esq_meio = '$coxa_esq_meio',
        coxa_esq_fim = '$coxa_esq_fim',
        coxa_dir_inicio = '$coxa_dir_inicio',
        coxa_dir_meio = '$coxa_dir_meio',
        coxa_dir_fim = '$coxa_dir_fim',
        panturrilha_esq_inicio = '$panturrilha_esq_inicio',
        panturrilha_esq_meio = '$panturrilha_esq_meio',
        panturrilha_esq_fim = '$panturrilha_esq_fim',
        panturrilha_dir_inicio = '$panturrilha_dir_inicio',
        panturrilha_dir_meio = '$panturrilha_dir_meio',
        panturrilha_dir_fim = '$panturrilha_dir_fim',
        imc_inicio = '$imc_inicio',
        imc_meio = '$imc_meio',
        imc_fim = '$imc_fim',
        biotipo_corporal = '$biotipo_corporal',
        distribuicao_gordura = '$distribuicao_gordura',
        presenca_diastase = '$presenca_diastase',
        tipo_gordura = '$tipo_gordura',
        regiao_gordura = '$regiao_gordura',
        observacoes_gordura = '$observacoes_gordura',
        tipo_flacidez = '$tipo_flacidez',
        regiao_flacidez = '$regiao_flacidez',
        observacoes_flacidez = '$observacoes_flacidez',
        grau_hldg = '$grau_hldg',
        tipo_hldg = '$tipo_hldg',
        regiao_hldg = '$regiao_hldg',
        observacoes_hldg = '$observacoes_hldg',
        tipo_estrias = '$tipo_estrias',
        largura_estria = '$largura_estria',
        observacoes_estrias = '$observacoes_estrias',
        experiencia = '$experiencia', 
        assinatura = '$assinatura', 
        assinatura_paciente = '$assinatura_paciente', 
        data_assinatura_paciente = '$data_assinatura_paciente', 
        nome_profissional = '$nome_profissional', 
        data_assinatura_profissional = '$data_assinatura_profissional' 
        WHERE id = '$id'";



    // Executa a atualização no banco de dados
    if ($conexao->query($sql) === TRUE) {
        // Redireciona para a página de listagem com uma mensagem de sucesso
        header("Location: listar.anamnese.corporal.php?message=Registro atualizado com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar o registro: " . $conexao->error;
    }

    // Fecha a conexão
    $conexao->close();
} else {
    echo "Método de requisição inválido.";
}
