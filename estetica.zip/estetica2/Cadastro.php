<?php
    include("conexao.php");    

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $endereco = $_POST['endereco'];
    $data_nascimento = $_POST['data_nascimento'];
    $senha = $_POST['senha'];
    }



    $sql = "INSERT INTO login (nome, email, endereco, data_nascimento, senha) VALUES ('$nome','$email', '$endereco', '$data_nascimento', '$senha')";

    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        // Usuario cadastrado com sucesso, sera redirecionado para a pagina inicial
        header("Location: pagina_inicial/Inicio");
        exit();
    } else {
        echo 'Erro de conexão/query.';
    }

    mysqli_close($conexao);
?>