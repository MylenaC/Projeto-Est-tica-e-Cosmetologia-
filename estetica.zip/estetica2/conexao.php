    <?php

    $servidor="localhost";
    $usuario="root";
    $senha="";
    $dtname="banco";



    $conexao=mysqli_connect($servidor,$usuario, $senha, $dtname);
    if(!$conexao) {
        die ("Houve um erro: " .mysqli_connect_error());
    }
    ?>